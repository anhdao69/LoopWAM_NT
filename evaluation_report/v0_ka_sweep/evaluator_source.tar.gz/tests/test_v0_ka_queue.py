import copy
import pytest
from scripts.v0_ka_common import groups, validate_rows, choose_profile


def row(g, ep=0, k=1):
    return dict(id=g['id'], episode=ep, seed=g['seed'], suite=g['suite'], task=g['task'],
                initial_state_index=ep, success=False, action_loops=k, checkpoint_sha256='fixed',
                policy_steps=10, queries=1)


def test_queue_covers_6000_unique_episodes_per_depth():
    gg=groups()
    assert len(gg)==120
    keys={(g['id'],e) for g in gg for e in range(g['episodes'])}
    assert len(keys)==6000
    assert {g['seed'] for g in gg}=={42,43,44}
    assert {g['episodes'] for g in gg}=={50}


def test_resume_rejects_partial_duplicate_wrong_depth_and_wrong_checkpoint():
    g={**groups()[0], 'episodes':2};rr=[row(g,0),row(g,1)]
    assert validate_rows([g],rr,'fixed',1)['episodes']==2
    for broken in [rr[:1],rr+rr[:1],[{**rr[0],'action_loops':2},rr[1]],
                   [{**rr[0],'checkpoint_sha256':'wrong'},rr[1]],
                   [{**rr[0],'queries':2},rr[1]]]:
        with pytest.raises(ValueError):validate_rows([g],broken,'fixed',1)


def test_faster_profile_must_match_complete_action_trace():
    baseline=dict(backend='eager',workers=4,seconds=10,signature='reference')
    bad=dict(backend='cuda-graph',workers=8,seconds=1,signature='changed')
    good=dict(backend='cuda-graph',workers=4,seconds=5,signature='reference')
    assert choose_profile([baseline,bad,good])==good
    with pytest.raises(ValueError):choose_profile([bad])


def test_resumed_partial_calibration_is_not_a_full_workload_speed_measurement():
    baseline=dict(backend='eager',workers=4,seconds=10,signature='reference',recovered_episodes=0)
    partial=dict(backend='cuda-graph',workers=8,seconds=1,signature='reference',recovered_episodes=14)
    assert choose_profile([baseline,partial])==baseline


def test_real_rollout_video_accepts_bounded_encoding_threads(tmp_path):
    import numpy as np
    import imageio.v2 as imageio
    from scripts.v0_ka_common import video_writer
    frames=[dict(image=np.zeros((32,32,3),dtype=np.uint8),wrist_image=np.full((32,32,3),120,dtype=np.uint8)) for _ in range(2)]
    path=video_writer()(tmp_path,frames,'test',False,'audit video',encoding_threads=1)
    reader=imageio.get_reader(path)
    try:
        assert reader.count_frames()==2
        assert reader.get_data(0).shape==(32,64,3)
    finally:reader.close()
