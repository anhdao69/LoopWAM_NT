import pytest
import torch
from test_loop_mot import make_model, inputs


@pytest.mark.parametrize('k', [1, 2, 3, 4, 5, 6])
def test_inference_action_schedule_reuses_native_late_aligned_video_cache(k):
    model = make_model().eval()
    before = {n: p.detach().clone() for n, p in model.state_dict().items()}
    model.set_inference_action_loops(k)
    schedule = model.virtual_schedule()
    slots = model.action_cache_slots()
    assert model.loops == model.trained_max_loops == 4
    assert model.action_loops == k
    expected = [('pre', j) for j in range(3)]
    expected += [('core', max(1, 4-k+r), j) for r in range(1, k+1) for j in range(6)]
    expected += [('coda', 4, j) for j in range(3)]
    assert [schedule[s][0] for s in slots] == expected
    assert [schedule[s][1] for s in slots] == list(range(3)) + list(range(3,9))*k + list(range(9,12))
    for n, p in model.state_dict().items():
        torch.testing.assert_close(p, before[n], rtol=0, atol=0)


def test_k4_override_leaves_numerical_output_identical():
    model, data = make_model().eval(), inputs()
    with torch.no_grad():
        before = model.forward_joint_core(**data)
        model.set_inference_action_loops(4)
        after = model.forward_joint_core(**data)
    for a, b in zip(before, after):
        torch.testing.assert_close(a, b, rtol=0, atol=0)


@pytest.mark.parametrize('k', [0, 7, True, 2.5, None])
def test_invalid_inference_depth_is_rejected(k):
    with pytest.raises(ValueError):
        make_model().eval().set_inference_action_loops(k)


def test_override_rejects_training_mode_and_other_architectures():
    for model in [make_model(), make_model(version='v1').eval(), make_model(loops=3).eval()]:
        with pytest.raises(ValueError):
            model.set_inference_action_loops(5)


def test_constructor_training_depth_guard_is_preserved():
    model = make_model().eval()
    with pytest.raises(ValueError):
        model.action_loops = 5
