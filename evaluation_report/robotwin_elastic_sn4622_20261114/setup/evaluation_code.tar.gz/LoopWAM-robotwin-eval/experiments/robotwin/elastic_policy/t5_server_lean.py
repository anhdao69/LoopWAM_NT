"""Shared T5 server with lean UMT5 loading (t5_lean.py) for hosts where the standard loader's ~34 GB host-RAM peak is unsafe.

python experiments/robotwin/elastic_policy/t5_server_lean.py --address /path/t5.sock

Same socket protocol and request handling (serve() of chronoloop_policy/t5_server.py), same TextEncoder.__call__, the
same UMT5 parameters (see t5_lean.py); only the host-side construction of the encoder differs.
"""
import argparse
import os
import sys
import threading
from multiprocessing.connection import Listener
from pathlib import Path

CODE_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(CODE_ROOT)); sys.path.insert(0, str(CODE_ROOT / 'src'))
from experiments.robotwin.chronoloop_policy.t5_server import serve  # noqa: E402
from experiments.robotwin.chronoloop_policy.deploy_policy import AUTHKEY  # noqa: E402
from experiments.robotwin.elastic_policy.t5_lean import lean_text_encoder  # noqa: E402


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--address', required=True)
    a = p.parse_args()
    encoder = lean_text_encoder('/nonexistent', 'none', 'cuda', stream=False)
    lock = threading.Lock()
    if os.path.exists(a.address):
        os.unlink(a.address)
    with Listener(a.address, family='AF_UNIX', authkey=AUTHKEY) as listener:
        print(f'T5 server (lean UMT5 load) ready at {a.address}', flush=True)
        while True:
            threading.Thread(target=serve, args=(listener.accept(), encoder, lock), daemon=True).start()


if __name__ == '__main__':
    main()
