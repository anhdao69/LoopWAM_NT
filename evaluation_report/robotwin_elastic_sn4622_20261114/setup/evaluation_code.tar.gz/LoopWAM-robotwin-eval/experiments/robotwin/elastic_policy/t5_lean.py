"""Lean UMT5 loading for hosts with limited RAM: the unchanged TextEncoder code with weights identical to the standard loader.

Standard (TextEncoder._load_encoder -> helpers.loader._load_registered_model): WanTextEncoder() is built in FP32 on the CPU
(~23 GB touched), the bf16 .pth state dict is read into RAM (~11 GB), load_state_dict(strict=False), then .to(device, bf16).
Every parameter therefore ends as bf16(fp32(file tensor)) == the file tensor, contiguous. Lean: the module is built on the
meta device and the memory-mapped bf16 file tensors are assigned (strict: no missing or unexpected keys; the module has no
buffers and no tied parameters; every tensor contiguous bf16), then copied to the GPU: the same parameters without an
anonymous host copy. stream=True keeps the blocks on the host and runs them one at a time on the GPU with the same modules
and inputs, for computing gate inputs while 11 GB of GPU memory is not free.

Encoding is unchanged: chronoloop_policy.deploy_policy.TextEncoder.__call__ (tokenizer, mask, zeroed padding, bf16) with
this encoder and the tokenizer constructed exactly as TextEncoder._load_encoder does.
"""
import copy
import hashlib
import os
from pathlib import Path

import torch

from experiments.robotwin.chronoloop_policy.deploy_policy import TextEncoder

T5_FILE = 'models_t5_umt5-xxl-enc-bf16.pth'
T5_SHA256 = '7cace0da2b446bbbbc57d031ab6cf163a3d59b366da94e5afe36745b746fd81d'   # campaign t5_weight_verification.json


def t5_base():
    return Path(os.environ['DIFFSYNTH_MODEL_BASE_PATH']) / 'Wan-AI/Wan2.1-T2V-1.3B'


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''): h.update(b)
    return h.hexdigest()


class StreamedT5(torch.nn.Module):
    """WanTextEncoder.forward with each block (and the final norm) copied to the GPU only while it runs."""

    def __init__(self, host, device):
        super().__init__()
        self.host = host; self.device = torch.device(device)
        if host.shared_pos: raise ValueError('UMT5 uses per-block relative positions')

    @torch.no_grad()
    def forward(self, ids, mask=None):
        m = self.host
        x = m.token_embedding(ids.to('cpu')).to(self.device)      # embedding gather: an exact copy on any device
        x = m.dropout(x)
        for block in m.blocks:
            gpu_block = copy.deepcopy(block).to(self.device)
            x = gpu_block(x, mask, pos_bias=None); del gpu_block
        norm = copy.deepcopy(m.norm).to(self.device)
        return m.dropout(norm(x))


def load_lean_encoder(device='cuda', stream=False, verify_sha=True):
    from fastwam.models.wan22.wan_video_text_encoder import WanTextEncoder
    path = t5_base() / T5_FILE
    if verify_sha and sha256(path) != T5_SHA256: raise ValueError('UMT5 weights differ from the evaluated file')
    state = torch.load(path, map_location='cpu', weights_only=True, mmap=True)
    if len(state) == 1:   # same unwrapping as helpers.io.load_state_dict_from_bin
        state = state.get('state_dict', state.get('module', state.get('model_state', state)))
    bad = [k for k, v in state.items() if v.dtype != torch.bfloat16 or not v.is_contiguous()]
    if bad: raise ValueError(f'Unexpected dtype/layout in {bad[:3]}')
    with torch.device('meta'):
        model = WanTextEncoder()          # registry entry: no extra kwargs
    if list(model.buffers()): raise ValueError('WanTextEncoder has buffers; lean loading would not reproduce them')
    names = {n for n, _ in model.named_parameters(remove_duplicate=False)}
    if len(names) != len(dict(model.named_parameters())) or names != set(state):
        raise ValueError('Parameter set differs from the checkpoint (or tied parameters)')
    model.load_state_dict(state, strict=True, assign=True)
    model.eval().requires_grad_(False)
    if stream: return StreamedT5(model, device).eval()
    model = model.to(device)
    for n, p in model.named_parameters():
        if p.dtype != torch.bfloat16 or not p.is_contiguous() or p.device.type != torch.device(device).type:
            raise ValueError(f'Parameter {n} not contiguous bf16 on {device}')
    return model


def lean_text_encoder(cache_dir='/nonexistent', suffix='none', device='cuda', stream=False):
    from fastwam.models.wan22.wan_video_text_encoder import HuggingfaceTokenizer
    encoder = TextEncoder(cache_dir, suffix, device)
    encoder.encoder = load_lean_encoder(device, stream)
    encoder.tokenizer = HuggingfaceTokenizer(name=str(t5_base() / 'google/umt5-xxl'), seq_len=128, clean='whitespace')
    return encoder
