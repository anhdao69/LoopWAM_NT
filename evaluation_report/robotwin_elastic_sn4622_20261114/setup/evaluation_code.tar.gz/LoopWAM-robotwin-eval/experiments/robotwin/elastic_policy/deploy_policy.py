"""RoboTwin-50 elastic student policy (format loopwam-s-robot-rt-v1, e.g. RT50-ep5-E1) for the local RoboTwin harness.

Everything outside the model call is the evaluated v0 teacher policy (experiments/robotwin/loopwam_policy): released
FastWAM PIL uint8 three-camera packing (`fastwam_image`), the 14-D joint state z-scored with the checkpoint's global
statistics, DEFAULT_PROMPT around the episode instruction through the shared T5 server, CPU noise seeded `seed` on every
query, 32 predicted / 24 executed absolute qpos actions, the same per-query JSON trace lines.

The model call is the export's own deployment path: transport_inference_robot.load_robot_transport (branch
elastic_robotwin, training revision 2c78ff6) and TransportPolicy.rollout(sample, depths, noise) under BF16 autocast.
`model_inputs` builds the sample exactly as the parent's FastWAM.infer_action builds its inputs (CPU noise drawn in FP32
then moved to the model dtype, VAE first-frame latents of the packed image, context/mask, proprio); the training
preflight showed that a teacher rollout on such a sample is bit-equal to the deployed v0 infer_action, and
scripts/elastic_robotwin_gates.py repeats that check on real simulator observations through this file.
The number of denoising steps is the schedule length; `schedule` names a FLAT9/legacy schedule or flat_k<K>_n<N>.
"""
import hashlib
import json
import os
import re
import sys
import time
from collections import deque
from pathlib import Path

import numpy as np
import torch

CODE_ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(CODE_ROOT));sys.path.insert(0,str(CODE_ROOT/'src'))
os.environ.setdefault('DIFFSYNTH_MODEL_BASE_PATH',str(CODE_ROOT/'checkpoints'))
from fastwam.datasets.chronoloop_robot import robot_spec
from fastwam.datasets.loopwam_long import DEFAULT_PROMPT
from fastwam.datasets.lerobot.utils.normalizer import SingleFieldLinearNormalizer
from fastwam.robotwin_pipeline import verify_file_hash
from experiments.robotwin.chronoloop_policy.deploy_policy import TextEncoder
from experiments.robotwin.loopwam_policy.deploy_policy import fastwam_image

EXPORT_FORMAT='loopwam-s-robot-rt-v1'


def parse_schedule(name):
    """Depth per denoising step: a named schedule (FLAT9 / legacy RT names) or flat_k<K>_n<N> (K core loops, N steps)."""
    from fastwam.models.wan22.residual_transport import SCHEDULES
    if name in SCHEDULES:return tuple(int(k) for k in SCHEDULES[name])
    match=re.fullmatch(r'flat_k([1-8])_n([1-9][0-9]?)',str(name))
    if not match:raise ValueError(f'Unknown schedule {name!r}')
    return (int(match[1]),)*int(match[2])


def load_header(checkpoint):
    """Small metadata of an elastic export (memory-mapped; tensors are not read)."""
    payload=torch.load(checkpoint,map_location='cpu',mmap=True,weights_only=False)
    if payload.get('format_version')!=EXPORT_FORMAT:raise ValueError('Not a RoboTwin elastic export')
    state=payload['training_state'];config=payload['transport_config']
    header=dict(step=payload['step'],update=state['update'],epoch=state.get('epoch'),kind=config['kind'],
        schedules=list(config['schedules']),contract=state['contract'],parent_step=state['parent_step'])
    del payload
    return header


class ElasticRoboTwinPolicy:
    def __init__(self,checkpoint,data_dir,vae_path,schedule,seed=42,t5_server=None,expected_step=47462,
                 expected_kind=None,device='cuda'):
        from fastwam.models.wan22.transport_inference_robot import load_robot_transport
        torch.set_num_threads(2)
        header=load_header(checkpoint);contract=header['contract']
        verify_file_hash(vae_path,contract['asset_sha256']['vae'])
        if header['step']!=int(expected_step) or header['update']!=int(expected_step):raise ValueError('Wrong export step')
        if expected_kind and header['kind']!=expected_kind:raise ValueError(f"Export transport {header['kind']} != {expected_kind}")
        stats=json.loads((Path(data_dir)/'dataset_stats.json').read_text())
        if hashlib.sha256(json.dumps(stats,sort_keys=True).encode()).hexdigest()!=contract['normalization_sha256']:
            raise ValueError('Evaluation normalization differs from training')
        self.normalizer={kind:SingleFieldLinearNormalizer({k.removeprefix('global_'):torch.tensor(v,dtype=torch.float32) for k,v in stats[kind]['default'].items() if k.startswith('global_')},mode='z-score') for kind in ('action','state')}
        self.policy,payload=load_robot_transport(checkpoint,vae_path,device=device);del payload
        self.policy.eval();self.parent=self.policy.parent
        if self.parent.action_expert.action_dim!=14 or self.parent.proprio_dim!=14:raise ValueError('Expected 14-D robot model')
        self.schedule=str(schedule);self.depths=parse_schedule(schedule)
        self.trained_schedule=self.schedule in header['schedules']
        self.rollout=self.policy.rollout
        if os.environ.get('LOOPWAM_CUDA_GRAPH')=='1':
            from experiments.robotwin.loopwam_policy.cuda_graph import GraphedCall
            self.rollout=GraphedCall(self.policy.rollout)
        spec=robot_spec('robotwin50');self.text=TextEncoder(spec.text_cache_dir,spec.text_suffix,'cuda',server=t5_server)
        self.seed=int(seed)
        self.pending=deque();self.episode=-1;self.queries=0;self.latency=[]

    def reset(self):
        self.pending.clear();self.queries=0;self.episode+=1

    def should_request_observation(self):return not self.pending

    def observation_inputs(self,observation,instruction):
        image=fastwam_image(observation)[0]
        joint=torch.as_tensor(np.asarray(observation['joint_action']['vector'],dtype=np.float32))
        if joint.shape!=(14,):raise ValueError('Expected14D joint state')
        proprio=self.normalizer['state'].forward(joint[None])[0]
        context,mask=self.text(DEFAULT_PROMPT.format(task=instruction))
        return image,proprio,context,mask

    def model_inputs(self,image,proprio,context,mask):
        """The parent FastWAM.infer_action input path: noise, packed-image VAE latents, context/mask, proprio."""
        parent=self.parent;device,dtype=parent.device,parent.torch_dtype
        generator=torch.Generator(device='cpu').manual_seed(self.seed)
        noise=torch.randn((1,32,parent.action_expert.action_dim),generator=generator,device='cpu',dtype=torch.float32).to(device=device,dtype=dtype)
        latents=parent._encode_input_image_latents_tensor(input_image=image.unsqueeze(0).to(device=device,dtype=dtype))
        sample=dict(first_frame_latents=latents,context=context.unsqueeze(0).to(device=device,dtype=dtype),
            context_mask=mask.unsqueeze(0).to(device=device,dtype=torch.bool),proprio=proprio.reshape(1,1,-1).to(device=device,dtype=dtype))
        return sample,noise

    def infer(self,image,proprio,context,mask):
        with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
            sample,noise=self.model_inputs(image,proprio,context,mask)
            action=self.rollout(sample,self.depths,noise)
        return action[0].detach().float().cpu()

    def _query(self,observation,instruction):
        image,proprio,context,mask=self.observation_inputs(observation,instruction)
        if self.queries==0:print(json.dumps(dict(loopwam_episode=self.episode,instruction=instruction,noise_seed=self.seed,schedule=self.schedule,depths=list(self.depths))),flush=True)
        capture=os.environ.get('LOOPWAM_CAPTURE_INPUTS')
        if capture and self.episode==0 and self.queries<2:
            directory=Path(capture);directory.mkdir(parents=True,exist_ok=True)
            torch.save(dict(input_image=image.cpu(),proprio=proprio.cpu(),context=context.cpu(),context_mask=mask.cpu(),
                instruction=instruction,seed=self.seed),directory/f'{os.getpid()}_q{self.queries}.pt')
        start=time.perf_counter()
        action=self.infer(image,proprio,context,mask)
        torch.cuda.synchronize();self.latency.append(time.perf_counter()-start);self.queries+=1
        if action.shape!=(32,14) or not torch.isfinite(action).all():raise ValueError('Invalid action output')
        denormalized=self.normalizer['action'].backward(action[None])[0].numpy()
        if not np.isfinite(denormalized).all():raise ValueError('Nonfinite denormalized action')
        print(json.dumps(dict(policy_query=self.queries-1,episode=self.episode,seconds=self.latency[-1],action_sha256=hashlib.sha256(denormalized.tobytes()).hexdigest())),flush=True)
        return denormalized

    def step(self,task_env,observation):
        if not self.pending:
            if observation is None:raise ValueError('Missing replanning observation')
            chunk=self._query(observation,task_env.get_instruction())
            self.pending.extend(np.asarray(a,dtype=np.float32) for a in chunk[:24])
        task_env.take_action(self.pending.popleft(),action_type='qpos')


def get_model(args):
    depths=parse_schedule(str(args['schedule']))
    if int(args.get('replan_steps',24))!=24 or int(args.get('num_inference_steps',len(depths)))!=len(depths):
        raise ValueError('Protocol requires 24 replan steps and NFE equal to the schedule length')
    kind=args.get('expected_kind')
    return ElasticRoboTwinPolicy(args['ckpt_setting'],args['data_dir'],
        args.get('vae_path') or str(CODE_ROOT/'checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth'),
        schedule=str(args['schedule']),seed=args.get('seed',42),t5_server=args.get('t5_server'),
        expected_step=args.get('expected_step',47462),expected_kind=None if kind in (None,'None','null','') else str(kind))

def eval(TASK_ENV,model,observation):model.step(TASK_ENV,observation)
def reset_model(model):model.reset()
