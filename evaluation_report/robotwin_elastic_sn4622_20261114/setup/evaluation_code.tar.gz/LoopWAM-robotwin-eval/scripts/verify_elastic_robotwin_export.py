#!/usr/bin/env python3
"""CPU static verification of a RoboTwin-50 elastic export against its frozen teacher, before any evaluation.

Mirrors the static part of elastic_robotwin scripts/verify_rt50_export.py (which needs the training recovery file):
format names; loop/architecture metadata equal to the teacher; every frozen mot tensor (outside mixtures.action.*) and
the proprio encoder bit-equal (keys, dtype, shape, value) to the FP32 teacher; mot["mixtures.action.*"] == student_action;
all student tensors FP32 and trained; step / epoch / windows / parent step; parent training state == the teacher's;
contract hashes (teacher, VAE, normalization) equal the local files. Tensors are memory-mapped, nothing is modified.
"""
import argparse, hashlib, json, time
from pathlib import Path
import torch

ROBOT_METADATA = ("version", "video_loops", "action_loops", "inference_loops", "trained_max_loops", "exit_weight_scale",
                  "memory_tokens", "history_frame", "architecture")   # scripts/train_transport.py @ 2c78ff6
A = "mixtures.action."


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''): h.update(b)
    return h.hexdigest()


def same_tensors(a, b):
    if set(a) != set(b): return False, f"key sets differ ({len(set(a) ^ set(b))} keys)"
    bad = [k for k in a if a[k].dtype != b[k].dtype or a[k].shape != b[k].shape or not torch.equal(a[k], b[k])]
    return not bad, (f"{len(bad)} tensors differ, e.g. {bad[:3]}" if bad else f"{len(a)} tensors bit-equal")


def deep_equal(x, y):
    if torch.is_tensor(x) or torch.is_tensor(y):
        return torch.is_tensor(x) and torch.is_tensor(y) and x.dtype == y.dtype and x.shape == y.shape and torch.equal(x, y)
    if isinstance(x, dict) and isinstance(y, dict): return x.keys() == y.keys() and all(deep_equal(x[k], y[k]) for k in x)
    if isinstance(x, (list, tuple)) and isinstance(y, (list, tuple)):
        return type(x) == type(y) and len(x) == len(y) and all(deep_equal(p, q) for p, q in zip(x, y))
    return x == y


def main():
    p = argparse.ArgumentParser()
    for n in ('export', 'teacher', 'vae', 'stats', 'out'): p.add_argument('--' + n, required=True)
    p.add_argument('--export-sha256'); p.add_argument('--teacher-sha256')
    p.add_argument('--expected-step', type=int, default=47462); p.add_argument('--expected-kind')
    p.add_argument('--expected-epoch', type=int, default=1, help='training epochs of the export (windows seen = epochs x contract windows)')
    a = p.parse_args()
    started = time.time(); c = {}
    hashes = dict(export=sha256(a.export), teacher=sha256(a.teacher), vae=sha256(a.vae), stats=sha256(a.stats))
    stats = json.loads(Path(a.stats).read_text())
    canonical_stats = hashlib.sha256(json.dumps(stats, sort_keys=True).encode()).hexdigest()
    if a.export_sha256: c['export_sha256_matches_release'] = hashes['export'] == a.export_sha256
    if a.teacher_sha256: c['teacher_sha256_matches_release'] = hashes['teacher'] == a.teacher_sha256
    x = torch.load(a.export, map_location='cpu', weights_only=False, mmap=True)
    t = torch.load(a.teacher, map_location='cpu', weights_only=False, mmap=True)
    st, config = x['training_state'], x['transport_config']; contract = st['contract']
    c['format'] = (x.get('format_version') == 'loopwam-s-robot-rt-v1' and x.get('base_format_version') == t.get('format_version') == 'loopwam-s-robot-v1'
                   and x.get('inference_action_format') == 'unmerged-exact')
    c['metadata_equal_teacher'] = all(deep_equal(x[k], t[k]) for k in ROBOT_METADATA)
    frozen = {k: v for k, v in x['mot'].items() if not k.startswith(A)}
    tfrozen = {k: v for k, v in t['mot'].items() if not k.startswith(A)}
    c['frozen_mot_equal_fp32_teacher'], why_frozen = same_tensors(frozen, tfrozen)
    c['proprio_equal_teacher'], why_proprio = same_tensors(dict(x['proprio_encoder']), dict(t['proprio_encoder']))
    c['frozen_all_fp32'] = all(v.dtype == torch.float32 for v in frozen.values() if v.is_floating_point())
    sa = x['student_action']
    action = {k[len(A):]: v for k, v in x['mot'].items() if k.startswith(A)}
    taction = {k[len(A):]: v for k, v in t['mot'].items() if k.startswith(A)}
    c['mot_action_equals_student'], _ = same_tensors(action, sa)
    c['student_keys_equal_teacher_action'] = set(sa) == set(taction)
    c['student_fp32'] = all(v.dtype == torch.float32 for v in sa.values() if v.is_floating_point())
    changed = sum(not torch.equal(sa[k], taction[k]) for k in sa)
    c['student_trained'] = changed == len(sa)
    c['student_finite'] = all(bool(torch.isfinite(v).all()) for v in sa.values() if v.is_floating_point())
    c['step_condition_present'] = x.get('step_condition') is not None and config.get('step_cond') is True
    c['transport_config'] = config.get('dataset') == 'robotwin50' and config.get('scope') == 'pc' and (not a.expected_kind or config.get('kind') == a.expected_kind)
    c['step_and_update'] = x['step'] == st['update'] == a.expected_step
    c['epoch_end'] = st.get('epoch') == a.expected_epoch and st.get('windows_seen') == a.expected_epoch * contract.get('windows')
    c['parent_step'] = st.get('parent_step') == t['step']
    c['parent_training_state_equals_teacher'] = deep_equal(st.get('parent_training_state'), t['training_state'])
    c['contract_teacher_sha256'] = contract['asset_sha256']['teacher'] == hashes['teacher']
    c['contract_vae_sha256'] = contract['asset_sha256']['vae'] == hashes['vae']
    c['contract_normalization'] = contract['normalization_sha256'] == canonical_stats
    c['merged_lora_false'] = st.get('merged_lora') is False
    report = dict(passed=all(c.values()), checks=c, frozen=why_frozen, proprio=why_proprio,
                  student_tensors_changed=f"{changed}/{len(sa)}", hashes=hashes, canonical_stats_sha256=canonical_stats,
                  kind=config.get('kind'), schedules=config.get('schedules'), step=x['step'], epoch=st.get('epoch'),
                  parent=config.get('parent'), trainable_parameters=contract.get('trainable_parameters'),
                  started=started, finished=time.time())
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(report, indent=2, default=str))
    print(json.dumps({k: v for k, v in report.items() if k in ('passed', 'checks', 'frozen', 'student_tensors_changed', 'kind', 'step')}, indent=1, default=str))
    if not report['passed']: raise SystemExit('export verification failed')


if __name__ == '__main__':
    main()
