#!/usr/bin/env python3
"""Independent audit of a finished elastic RoboTwin evaluation directory (scripts/evaluate_elastic_robotwin.py).

For every task/setting cell of the contract it re-verifies the accepted attempt from its own files:
  * COMPLETE.json / manifest.json / result.json agree (checkpoint sha, schedule, coverage, 100 episodes);
  * the records re-derived from eval.log (cumulative counters, seeds, ffprobe-valid videos, per-query action traces,
    one instruction per episode) equal the stored ones;
  * no render/GPU-memory fault string anywhere in the accepted log;
  * every episode ran the contract schedule (depths) with the fixed noise seed 42;
  * the accepted scene seeds walk strictly upward from the harness start 100000*(1+seed) = 4,300,000;
and reports success rates, agreement of the accepted seeds with the v0 campaign, a paired E1-vs-v0 comparison on the
seeds both accepted, and every rejected attempt with its reason.

Seed agreement is reported, not required: the harness accepts a candidate scene only if its scripted expert succeeds, and
for hard-planning tasks that check is not reproducible run to run (CuRobo MotionGen keeps its random state across
candidates and stops a plan after a 10 s wall-clock timeout, so GPU load and history change which plans succeed). On this
host, four expert-only replays of put_object_cabinet/demo_clean accepted four different seed sequences
(verification/curobo_nondeterminism.json). The campaign's v0 run had the same property. Each accepted scene itself is
fully determined by its seed, and the policy never uses the planner.

    robotwin_eval_audit.py OUT CAMPAIGN_EPISODES_CSV REPORT_JSON
"""
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from evaluate_loopwam_robotwin import completed_records  # noqa: E402
from evaluate_elastic_robotwin import render_faults, RENDER_FAULTS  # noqa: E402


def main():
    out, campaign_csv, report = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
    manifest = json.loads((out / 'manifest.json').read_text())
    complete = json.loads((out / 'COMPLETE.json').read_text())
    sha, schedule, depths, episodes = manifest['checkpoint_sha256'], manifest['schedule'], manifest['depths'], manifest['episodes']
    campaign = {}
    for r in csv.DictReader(open(campaign_csv)):
        campaign.setdefault((r['task'], r['setting']), {})[int(r['seed'])] = r['success'] == 'True'
    expected = {f'{t}/{c}' for t in manifest['tasks'] for c in manifest['settings']}
    problems = []
    if complete['checkpoint_sha256'] != sha: problems.append('COMPLETE checkpoint sha differs from manifest')
    if complete.get('schedule') != schedule: problems.append('COMPLETE schedule differs from manifest')
    if set(complete['finished']) != expected: problems.append('COMPLETE coverage differs from the contract')
    cells, rejected = [], []
    for key in sorted(expected):
        task, setting = key.split('/')
        cell_dir = out / f'{task}__{setting}'
        result = json.loads((cell_dir / 'result.json').read_text())
        accepted = Path(result['directory'])
        p = []
        if result != complete['finished'].get(key): p.append('result.json differs from COMPLETE')
        if result['checkpoint_sha256'] != sha or result.get('schedule') != schedule: p.append('result sha/schedule')
        if accepted.parent != cell_dir: p.append('accepted attempt outside its cell')
        records = completed_records(accepted, setting, episodes, verify=True)
        if records != result['episodes']: p.append('re-derived records differ')
        faults = render_faults(accepted)
        if faults: p.append(f'render faults {faults}')
        log = (accepted / 'eval.log').read_text(errors='replace')
        starts = [json.loads(line) for line in log.splitlines() if line.startswith('{"loopwam_episode"')]
        bad = [s for s in starts if s.get('schedule') != schedule or s.get('depths') != depths or s.get('noise_seed') != 42]
        if len(starts) != episodes or bad: p.append(f'episode headers: {len(starts)} found, {len(bad)} with wrong schedule/seed')
        seeds = [r['seed'] for r in records]
        ref = campaign[(task, setting)]
        if seeds != sorted(seeds) or len(set(seeds)) != len(seeds) or seeds[0] < 100000 * (1 + manifest['seed']):
            p.append('accepted seeds do not walk upward from the harness start')
        common = [r for r in records if r['seed'] in ref]
        for attempt in sorted(cell_dir.glob('attempt_*')):
            if attempt == accepted: continue
            failure = attempt / 'failure.json'
            rejected.append(dict(cell=key, attempt=attempt.name,
                                 failure=json.loads(failure.read_text()) if failure.exists() else 'no failure.json (interrupted run)'))
        cells.append(dict(cell=key, attempt=accepted.name, successes=result['successes'],
                          v0_campaign_successes=sum(ref.values()), v0_campaign_episodes=len(ref), seeds_identical_to_campaign=seeds == sorted(ref)[:episodes],
                          seeds_in_campaign_set=len(common), paired_e1_successes=sum(r['success'] for r in common),
                          paired_v0_successes=sum(ref[r['seed']] for r in common),
                          queries=sum(r['queries'] for r in records), seconds=result['seconds'], gpu=result.get('gpu'), problems=p))
        problems += [f'{key}: {x}' for x in p]
    def total(rows):
        n = len(rows) * episodes; paired = sum(c['seeds_in_campaign_set'] for c in rows)
        return dict(successes=sum(c['successes'] for c in rows), episodes=n, sr_percent=round(100 * sum(c['successes'] for c in rows) / n, 2),
                    v0_campaign_sr_percent=round(100 * sum(c['v0_campaign_successes'] for c in rows) / sum(c['v0_campaign_episodes'] for c in rows), 2),
                    cells_with_identical_seeds=sum(c['seeds_identical_to_campaign'] for c in rows), cells=len(rows),
                    paired_episodes=paired,
                    paired_e1_sr_percent=round(100 * sum(c['paired_e1_successes'] for c in rows) / paired, 2) if paired else None,
                    paired_v0_sr_percent=round(100 * sum(c['paired_v0_successes'] for c in rows) / paired, 2) if paired else None)
    totals = {setting: total([c for c in cells if c['cell'].endswith('/' + setting)]) for setting in manifest['settings']}
    totals['combined'] = total(cells)
    record = dict(passed=not problems, problems=problems, schedule=schedule, depths=depths, nfe=len(depths),
                  checkpoint_sha256=sha, t5_loader=manifest.get('t5_loader'), cuda_graph=manifest.get('cuda_graph'),
                  render_fault_strings=list(RENDER_FAULTS), totals=totals, rejected_attempts=rejected, cells=cells)
    report.write_text(json.dumps(record, indent=2))
    print(json.dumps(dict(passed=record['passed'], problems=problems[:20], schedule=schedule, totals=totals,
                          rejected_attempts=len(rejected)), indent=1))
    if problems: raise SystemExit('audit failed')


if __name__ == '__main__':
    main()
