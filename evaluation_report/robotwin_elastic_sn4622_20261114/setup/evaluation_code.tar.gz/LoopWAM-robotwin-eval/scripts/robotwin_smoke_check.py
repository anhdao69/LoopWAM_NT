#!/usr/bin/env python3
"""Check a finished elastic RoboTwin evaluation against the campaign: complete validated records (videos, per-query action
traces), accepted seeds walking upward from the harness start, and, reported (not required), whether the accepted seeds
equal the campaign's (the expert-gated scene acceptance is not reproducible for hard-planning tasks; see
scripts/robotwin_eval_audit.py) with the campaign v0 outcome on the seeds both runs accepted."""
import csv, json, sys
from pathlib import Path


def main():
    out, campaign_csv, report = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
    complete = json.loads((out / 'COMPLETE.json').read_text()); manifest = json.loads((out / 'manifest.json').read_text())
    campaign = {}
    for r in csv.DictReader(open(campaign_csv)):
        campaign.setdefault((r['task'], r['setting']), {})[int(r['seed'])] = r
    cells = []
    for key, cell in sorted(complete['finished'].items()):
        task, setting = key.split('/'); episodes = cell['episodes']; ref = campaign[(task, setting)]
        first = sorted(ref)[:len(episodes)]
        cells.append(dict(cell=key, seeds=[e['seed'] for e in episodes], campaign_seeds=first,
                          seeds_match=[e['seed'] for e in episodes] == first,
                          e1_success=[e['success'] for e in episodes],
                          v0_campaign_success=[ref[e['seed']]['success'] == 'True' if e['seed'] in ref else None for e in episodes],
                          seeds_increasing=[e['seed'] for e in episodes] == sorted({e['seed'] for e in episodes})
                              and episodes[0]['seed'] >= 100000 * (1 + manifest['seed']),
                          queries=[e['queries'] for e in episodes], videos_verified=all(e['video_verified'] for e in episodes),
                          seconds=cell['seconds']))
    record = dict(passed=all(c['seeds_increasing'] and c['videos_verified'] for c in cells),
                  cells_with_campaign_seeds=sum(c['seeds_match'] for c in cells), cells_total=len(cells), schedule=manifest['schedule'],
                  depths=manifest['depths'], t5_loader=manifest.get('t5_loader'), checkpoint_sha256=manifest['checkpoint_sha256'],
                  episodes=sum(len(c['seeds']) for c in cells), e1_successes=sum(sum(c['e1_success']) for c in cells),
                  v0_campaign_successes_same_seeds=sum(sum(x for x in c['v0_campaign_success'] if x) for c in cells), cells=cells)
    report.write_text(json.dumps(record, indent=2)); print(json.dumps(record, indent=1))
    if not record['passed']: raise SystemExit('check failed')


if __name__ == '__main__':
    main()
