#!/bin/bash
# GPU gates for the E1 RoboTwin deployment (scripts/elastic_robotwin_gates.py), phases in sequence on GPU0, memory-gated.
set -euo pipefail
B=/data/anh/robotwin_eval; source $B/environment.sh; unset PYTHONPATH      # each phase imports only from --tree
M=/data/anh/code/LoopWAM-robotwin-eval; C=/data/anh/code/LoopWAM-robotwin-campaign-9cdceaa; P=/data/anh/code/LoopWAM-elastic-robotwin-2c78ff6
OUT=$B/verification/gates; mkdir -p $OUT
# captures only from replay cells that passed (seeds == campaign, exit 0, videos, no render/GPU-memory fault in the log)
CAPS=$(python - <<PY
import json, re
from pathlib import Path
out = []
for f in sorted(Path('$B/verification').glob('scene_replay*/scene_replay.json')):
    for c in json.loads(f.read_text())['cells']:
        log = (f.parent / f"{c['task']}__{c['setting']}" / 'eval.log').read_text(errors='replace')
        faults = [m for m in ('OIDN Error', 'cannot create buffer', 'OutOfMemoryError', 'out of memory') if m in log]
        if c['passed'] and not faults: out.append(str(f.parent / f"{c['task']}__{c['setting']}" / 'captured_observations'))
print(' '.join(out))
PY
)
echo "captures: $CAPS"
wait_mem() { while [ "$(nvidia-smi -i 0 --query-gpu=memory.free --format=csv,noheader,nounits)" -lt "$1" ]; do echo "$(date +%T) waiting for $1 MiB free on GPU0"; sleep 30; done; }
export CUDA_VISIBLE_DEVICES=0 GATE_MODEL_BASE=$M/checkpoints
G="python $M/scripts/elastic_robotwin_gates.py"
common="--out $OUT --captures $CAPS --teacher $B/checkpoints/v0-video4-action4/policy.pt --teacher-data-dir $B/checkpoints/v0-video4-action4 --e1 $B/checkpoints/E1/epoch_01.pt --e1-data-dir $B/checkpoints/E1 --vae $M/checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth"
run() { local need=$1 phase=$2 tree=$3; if [ -f $OUT/$phase.json ]; then echo "$phase already done"; return; fi
         wait_mem $need; $G --phase $phase --tree $tree $common; }
# thresholds from measured peaks (v0 phases: 3.7 GiB allocated) plus CUDA context and allocator slack
run 3000 contexts    $M
run 6000 v0_campaign $C
run 6000 v0_merged   $M
run 6500 e1_merged   $M
run 6000 e1_pure     $P
$G --phase summary --out $OUT
echo GATES_DONE
