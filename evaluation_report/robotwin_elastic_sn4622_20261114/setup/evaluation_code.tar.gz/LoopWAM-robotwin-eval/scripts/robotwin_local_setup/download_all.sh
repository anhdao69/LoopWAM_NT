#!/usr/bin/env bash
# Resumable, hash-verified downloads for the local RoboTwin evaluation (assets + E1 + v0 teacher).
set -euo pipefail
B=/data/anh/robotwin_eval
fetch() {  # url dest expected_sha256(optional) expected_size(optional)
  local url=$1 dest=$2 sha=${3:-} size=${4:-}
  mkdir -p "$(dirname "$dest")"
  if [ -f "$dest" ] && [ -n "$sha" ] && [ -f "$dest.verified" ] && [ "$(cat "$dest.verified")" = "$sha" ]; then echo "already verified $dest"; return; fi
  for i in $(seq 1 20); do
    if curl -L --fail --silent --show-error --retry 5 --retry-delay 10 -C - -o "$dest.part" "$url"; then break; fi
    echo "retry $i for $url"; sleep 15
  done
  if [ -n "$size" ] && [ "$(stat -c %s "$dest.part")" != "$size" ]; then echo "SIZE MISMATCH $dest"; exit 1; fi
  if [ -n "$sha" ]; then
    got=$(sha256sum "$dest.part" | cut -d' ' -f1)
    if [ "$got" != "$sha" ]; then echo "SHA MISMATCH $dest got $got want $sha"; exit 1; fi
    echo "$sha" > "$dest.verified"
  fi
  mv "$dest.part" "$dest"; echo "ok $dest"
}
HF=https://huggingface.co
E1REV=87d8a52bcd7d1b1f29055e35223c4836f0203c50
V0REV=4544aebb8c72b41af043efd97373dd0803e80a76
ASSETREV=3dc3b798668feb99ac61cc9086d84cbcc3d79186
# E1 (sha256 of the checkpoint from the HF LFS pointer / release SHA256SUMS)
for f in README.md SHA256SUMS data_manifest.json dataset_stats.json export_verification.json launches.jsonl schedule_sequence.json teacher_provenance.json training_config.json training_metrics.jsonl.gz training_status.json epoch_01.pt.uploaded.json; do
  fetch $HF/anhdao69/LoopWAM_NT/resolve/$E1REV/robotwin/Elastic/E1/$f $B/checkpoints/E1/$f
done
fetch $HF/anhdao69/LoopWAM_NT/resolve/$E1REV/robotwin/Elastic/E1/epoch_01.pt $B/checkpoints/E1/epoch_01.pt 9eba3aade1417b4425be5593c88e81441cf71bb4b6f16a8d81012ad6146e1bcb 2340331629
# v0 teacher at the revision the campaign evaluated
for f in README.md SHA256SUMS checkpoint_provenance.json config.json data_provenance.json dataset_stats.json evaluation_protocol.json training_timing.json; do
  fetch $HF/anhdao69/LoopWAM_NT/resolve/$V0REV/robotwin/v0-video4-action4/$f $B/checkpoints/v0-video4-action4/$f
done
fetch $HF/anhdao69/LoopWAM_NT/resolve/$V0REV/robotwin/v0-video4-action4/policy.pt $B/checkpoints/v0-video4-action4/policy.pt 38975220e9441303878d2dfb9956d57e6416c6a906c99c43d9bca015b092fc51 2338751333
# RoboTwin 2.0 assets at the campaign's pinned revision
fetch $HF/datasets/TianxingChen/RoboTwin2.0/resolve/$ASSETREV/embodiments.zip $B/downloads/embodiments.zip 85ffeff55a5066def5931224a85cfa3f8abaa1fbf779bd17789a7fb3f85bc789 219847741
fetch $HF/datasets/TianxingChen/RoboTwin2.0/resolve/$ASSETREV/objects.zip $B/downloads/objects.zip 6aa56b3cf1e1064f7c809308144da36b00815f8b137fef2d7e4de856f8becf27 3737778549
fetch $HF/datasets/TianxingChen/RoboTwin2.0/resolve/$ASSETREV/background_texture.zip $B/downloads/background_texture.zip 54ede0fb5b783e0faa2bc98720d3affd6ca3bb9280b225b48c1aafaf31473070 10970687027
echo ALL_DOWNLOADS_DONE
