#!/bin/bash
set -euo pipefail
source /data/anh/robotwin_eval/environment.sh
cd /data/anh/code/LoopWAM-robotwin-eval
exec python scripts/robotwin_scene_replay.py --cells click_bell/demo_clean:5,lift_pot/demo_randomized:10,beat_block_hammer/demo_randomized:10,adjust_bottle/demo_randomized:10 --gpu 0 --need-mib 7000 \
  --output-dir /data/anh/robotwin_eval/verification/scene_replay_2 --campaign-episodes /data/anh/code/LoopWAM_NT/evaluation_report/robotwin_v0/episodes.csv
