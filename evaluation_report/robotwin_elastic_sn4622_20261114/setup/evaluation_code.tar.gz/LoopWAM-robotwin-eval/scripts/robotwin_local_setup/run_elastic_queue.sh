#!/bin/bash
# RoboTwin evaluations of one elastic RT student export (format loopwam-s-robot-rt-v1) under the local RTX v0 protocol,
# several schedules in the given order from ONE orchestrator (scripts/evaluate_elastic_robotwin.py): one shared lean T5
# server; every cell of evaluation 1 starts before any cell of evaluation 2; within an evaluation, cells start longest-first;
# a worker starts only while its GPU and the host have room (never preempting anyone). Scheduling never changes how a cell
# is evaluated. Generalizes run_e1_queue.sh (E1, unchanged) to any export; it refuses to start unless a passed gate record
# for THIS checkpoint (sha256), kind and step covers every requested schedule.
# Parameters via systemd-run -E NAME=value:
#   NAME=e0ep10  CKPT=<export.pt>  DATA_DIR=<dir with dataset_stats.json>  KIND=T0  STEP=237310  GATES=<dir with gates.json>
#   REF=<reference report dir with episodes.csv> (paired comparison only)  ORDER_CSV=<task,setting,attempt_seconds csv>
#   SCHEDULES=a,b,c  OUTS=<dir1>,<dir2>,... (default $B/results/<NAME>_<schedule>)
#   TASKS=all EPISODES=100 GPUS=0,1 PER_GPU=6 ADMIT_GPU=11000 GPU_FLOOR=1500 ADMIT_RAM=6000 RAM_FLOOR=6000 HOLD=300 MAX_ATTEMPTS=8
set -uo pipefail
B=/data/anh/robotwin_eval; source $B/environment.sh
M=/data/anh/code/LoopWAM-robotwin-eval
NAME=${NAME:?}; CKPT=${CKPT:?}; DATA_DIR=${DATA_DIR:?}; KIND=${KIND:?}; STEP=${STEP:?}; GATES=${GATES:?}; REF=${REF:?}; ORDER_CSV=${ORDER_CSV:?}
SCHEDULES=${SCHEDULES:?}; TASKS=${TASKS:-all}; EPISODES=${EPISODES:-100}; GPUS=${GPUS:-0,1}; PER_GPU=${PER_GPU:-6}
ADMIT_GPU=${ADMIT_GPU:-11000}; GPU_FLOOR=${GPU_FLOOR:-1500}; ADMIT_RAM=${ADMIT_RAM:-6000}; RAM_FLOOR=${RAM_FLOOR:-6000}; HOLD=${HOLD:-300}
MAX_ATTEMPTS=${MAX_ATTEMPTS:-8}; NEED_T5=${NEED_T5:-12500}; NEED_T5_RAM=${NEED_T5_RAM:-14000}; RELAUNCHES=${RELAUNCHES:-3}
IFS=, read -ra S <<< "$SCHEDULES"
if [ -n "${OUTS:-}" ]; then IFS=, read -ra O <<< "$OUTS"; else O=(); for s in "${S[@]}"; do O+=("$B/results/${NAME}_$s"); done; fi
[ ${#S[@]} -eq ${#O[@]} ] || { echo "SCHEDULES/OUTS length mismatch"; exit 2; }
[ -f "$REF/episodes.csv" ] || { echo "missing $REF/episodes.csv"; exit 2; }
# a passed gate record of this exact checkpoint, kind and step must cover every schedule
python - "$GATES/gates.json" "$CKPT" "$KIND" "$STEP" "${S[@]}" <<'PY' || exit 2
import hashlib, json, sys
gates, ckpt, kind, step, schedules = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5:]
g = json.load(open(gates)); h = hashlib.sha256()
with open(ckpt, 'rb') as f:
    for block in iter(lambda: f.read(8 << 20), b''): h.update(block)
problems = [x for x, ok in [('gates not passed', g['passed']), ('checkpoint sha differs', g.get('checkpoint_sha256') == h.hexdigest()),
                             ('kind differs', g.get('kind') == kind), ('step differs', g.get('step') == step)] if not ok]
missing = [s for s in schedules if s not in g['schedules']]
print('gates:', gates, 'checkpoint', h.hexdigest()[:16], 'schedules', g['schedules'])
sys.exit(f'gate check failed: {problems} missing {missing}' if problems or missing else 0)
PY
export LOOPWAM_VULKAN_DEVICE_SELECT=1 LOOPWAM_CUDA_GRAPH=0 LOOPWAM_RUNTIME_MANIFEST=$B/runtime_manifest.json
args=(); for i in "${!S[@]}"; do args+=(--schedule "${S[$i]}" --output-dir "${O[$i]}"); done
[ "$TASKS" != all ] && args+=(--tasks "$TASKS")
check() {   # reference seed check + independent audit of one finished evaluation
  local s=$1 out=$2
  python $M/scripts/robotwin_smoke_check.py "$out" $REF/episodes.csv "$out/campaign_seed_check.json" > "$out/campaign_seed_check.log" 2>&1 \
    && echo "$s: reference seed check passed" || { echo "$s: reference seed check FAILED"; return 1; }
  python $M/scripts/robotwin_eval_audit.py "$out" $REF/episodes.csv "$out/audit.json" > "$out/audit.log" 2>&1 \
    && echo "$s: audit passed" || { echo "$s: audit FAILED (see $out/audit.log)"; return 1; }
}
for i in "${!S[@]}"; do   # check each evaluation as soon as it completes, while later ones still run
  ( until [ -f "${O[$i]}/COMPLETE.json" ]; do sleep 300; done; check "${S[$i]}" "${O[$i]}" ) &
done
rc=1
for launch in $(seq 1 $((RELAUNCHES+1))); do
  while true; do      # the T5 server goes on the GPU with the most free memory
    read T free < <(nvidia-smi --query-gpu=index,memory.free --format=csv,noheader,nounits | tr -d ' ' | tr , ' ' | sort -k2 -n -r | head -1)
    ram=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo)
    [ "$free" -ge "$NEED_T5" ] && [ "$ram" -ge "$NEED_T5_RAM" ] && break
    echo "$(date +%T) waiting for T5 room: best GPU$T free ${free} MiB, RAM ${ram} MiB"; sleep 60
  done
  echo "$(date +%T) launch $launch: T5 on GPU$T; $NAME schedules ${S[*]}"
  python $M/scripts/evaluate_elastic_robotwin.py --checkpoint "$CKPT" \
    --robotwin-root $M/third_party/RoboTwin --data-dir "$DATA_DIR" --episodes "$EPISODES" \
    --gpus "$GPUS" --per-gpu "$PER_GPU" --expected-kind "$KIND" --expected-step "$STEP" --t5-loader lean --t5-gpu "$T" \
    --max-attempts "$MAX_ATTEMPTS" --order campaign-longest-first --campaign-results "$ORDER_CSV" \
    --admit-gpu-mib "$ADMIT_GPU" --gpu-floor-mib "$GPU_FLOOR" --admit-ram-mib "$ADMIT_RAM" --ram-floor-mib "$RAM_FLOOR" --admit-hold "$HOLD" "${args[@]}"
  rc=$?; echo "$(date +%T) orchestrator exit $rc"
  [ $rc -eq 0 ] && break
  sleep 60
done
status=$rc
kill $(jobs -p) 2>/dev/null; wait 2>/dev/null   # stop the per-evaluation checkers; the final checks below cover all
for i in "${!S[@]}"; do
  out=${O[$i]}
  if [ ! -f "$out/COMPLETE.json" ]; then echo "${S[$i]}: not complete"; status=1; continue; fi
  check "${S[$i]}" "$out" || status=1
done
[ $status -eq 0 ] && echo ${NAME^^}_QUEUE_DONE || echo ${NAME^^}_QUEUE_INCOMPLETE
exit $status
