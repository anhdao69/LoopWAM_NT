#!/usr/bin/env bash
# Resumable, hash-verified downloads for the E0 elastic export trained from the v0 epoch-10 teacher (5 epochs), and that
# teacher itself (for the GPU gates), pinned to the HF revision listed on 2026-11-11. Same fetch() as download_all.sh.
set -euo pipefail
B=/data/anh/robotwin_eval
fetch() {  # url dest expected_sha256(optional) expected_size(optional)
  local url=$1 dest=$2 sha=${3:-} size=${4:-}
  mkdir -p "$(dirname "$dest")"
  if [ -f "$dest" ] && [ -n "$sha" ] && [ -f "$dest.verified" ] && [ "$(cat "$dest.verified")" = "$sha" ]; then echo "already verified $dest"; return; fi
  for i in $(seq 1 20); do
    if curl -L --fail --silent --show-error --retry 5 --retry-delay 10 -C - -o "$dest.part" "$url"; then break; fi
    echo "retry $i for $url"; sleep 15
  done
  if [ -n "$size" ] && [ "$(stat -c %s "$dest.part")" != "$size" ]; then echo "SIZE MISMATCH $dest"; exit 1; fi
  if [ -n "$sha" ]; then
    got=$(sha256sum "$dest.part" | cut -d' ' -f1)
    if [ "$got" != "$sha" ]; then echo "SHA MISMATCH $dest got $got want $sha"; exit 1; fi
    echo "$sha" > "$dest.verified"
  fi
  mv "$dest.part" "$dest"; echo "ok $dest"
}
HF=https://huggingface.co
REV=b72f355505d98c473fb91e45d10e16d4cc7ce536
D=$B/checkpoints/E0-epoch10-teacher-5ep
for f in README.md SHA256SUMS data_manifest.json dataset_stats.json export_verification.json launches.jsonl schedule_sequence.json teacher_provenance.json training_config.json training_status.json epoch_05.pt.uploaded.json; do
  fetch $HF/anhdao69/LoopWAM_NT/resolve/$REV/robotwin/Elastic/E0-epoch10-teacher-5ep/$f $D/$f
done
fetch $HF/anhdao69/LoopWAM_NT/resolve/$REV/robotwin/Elastic/E0-epoch10-teacher-5ep/training_metrics.jsonl.gz $D/training_metrics.jsonl.gz f44ec7de00fef0d800ba6855a77471aa008f6374f1542075bbceaba85fb9a8e4 31598811
fetch $HF/anhdao69/LoopWAM_NT/resolve/$REV/robotwin/Elastic/E0-epoch10-teacher-5ep/epoch_05.pt $D/epoch_05.pt 07d24ff77410e516ac90d24d76d651e2102b09b0458d9d5d86ea18dff39e823e 2340331885
T=$B/checkpoints/v0-video4-action4-epoch10
for f in README.md SHA256SUMS checkpoint_provenance.json config.json data_provenance.json dataset_stats.json training_state.json; do
  fetch $HF/anhdao69/LoopWAM_NT/resolve/$REV/robotwin/v0-video4-action4/epoch_10/$f $T/$f
done
fetch $HF/anhdao69/LoopWAM_NT/resolve/$REV/robotwin/v0-video4-action4/epoch_10/policy.pt $T/policy.pt 70cf5af73db5fe582c50c5f9fb68296d5271a9c0fea51509b3cdb5f9696be1ea 2338751589
# every file listed in each release's SHA256SUMS must match
(cd $D && sha256sum -c SHA256SUMS) && (cd $T && sha256sum -c SHA256SUMS) && echo DOWNLOAD_E0_EP10_DONE
