#!/bin/bash
# Pre-evaluation verification of RoboTwin elastic export E0-epoch10-teacher-5ep (RT50-E0 x5: T0, 5 epochs, teacher =
# v0 4/4 epoch 10, step 474,620, sha 70cf5af7...). Every phase is run fresh against the epoch-10 teacher (nothing is
# copied from the E1 gates, whose v0 reference is the epoch-5 teacher):
#   1. static CPU verification of the export (scripts/verify_elastic_robotwin_export.py)  -> verification/e0ep10_static.json
#   2. GPU gates (scripts/elastic_robotwin_gates.py) on the same pinned harness captures as the E1 gates, for the six
#      schedules to evaluate (flat_k4_n10 is also the CUDA-graph check schedule)          -> verification/gates_e0ep10
# Each phase waits for GPU memory on the GPU with the most free memory and for host RAM (evaluation workers share the host).
set -euo pipefail
B=/data/anh/robotwin_eval; source $B/environment.sh; unset PYTHONPATH      # each gate phase imports only from --tree
M=/data/anh/code/LoopWAM-robotwin-eval; C=/data/anh/code/LoopWAM-robotwin-campaign-9cdceaa; P=/data/anh/code/LoopWAM-elastic-robotwin-2c78ff6
X=$B/checkpoints/E0-epoch10-teacher-5ep; T=$B/checkpoints/v0-video4-action4-epoch10
VAE=$M/checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth
OUT=$B/verification/gates_e0ep10; mkdir -p $OUT
until [ -f $X/epoch_05.pt.verified ] && [ -f $T/policy.pt.verified ] && [ ! -f $X/epoch_05.pt.part ] && [ ! -f $T/policy.pt.part ]; do
  echo "$(date +%T) waiting for verified downloads"; sleep 30; done
[ "$(cat $X/epoch_05.pt.verified)" = 07d24ff77410e516ac90d24d76d651e2102b09b0458d9d5d86ea18dff39e823e ]
[ "$(cat $T/policy.pt.verified)" = 70cf5af73db5fe582c50c5f9fb68296d5271a9c0fea51509b3cdb5f9696be1ea ]
cmp $X/dataset_stats.json $T/dataset_stats.json && echo "student and teacher dataset_stats.json identical"
wait_ram() { while [ "$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo)" -lt "$1" ]; do echo "$(date +%T) waiting for $1 MiB host RAM"; sleep 30; done; }
# 1. static verification (CPU, memory-mapped)
if [ ! -f $B/verification/e0ep10_static.json ]; then
  wait_ram 9000
  python $M/scripts/verify_elastic_robotwin_export.py --export $X/epoch_05.pt --teacher $T/policy.pt --vae $VAE \
    --stats $X/dataset_stats.json --out $B/verification/e0ep10_static.json \
    --export-sha256 07d24ff77410e516ac90d24d76d651e2102b09b0458d9d5d86ea18dff39e823e \
    --teacher-sha256 70cf5af73db5fe582c50c5f9fb68296d5271a9c0fea51509b3cdb5f9696be1ea \
    --expected-step 237310 --expected-kind T0 --expected-epoch 5
fi
# 2. GPU gates: exactly the captures of the passed E1 gates
CAPS="$B/verification/scene_replay/adjust_bottle__demo_clean/captured_observations $B/verification/scene_replay_diag/adjust_bottle__demo_randomized/captured_observations"
python - $CAPS <<PY
import json, sys
from pathlib import Path
ids = sorted(f"{Path(d).parent.name}/ep{json.loads(j.read_text())['episode']}" for d in sys.argv[1:] for j in Path(d).glob('episode*.json'))
want = json.loads(Path('$B/verification/gates/gates.json').read_text())['captures']
print('capture ids', ids); sys.exit(0 if ids == sorted(want) else f'capture ids differ from the E1 gates: {want}')
PY
export GATE_SCHEDULES=flat_k1_n5,flat_k1_n10,flat_k2_n5,flat_k2_n10,flat_k4_n5,flat_k4_n10 GATE_MODEL_BASE=$M/checkpoints
G="python $M/scripts/elastic_robotwin_gates.py"
common="--out $OUT --captures $CAPS --teacher $T/policy.pt --teacher-data-dir $T --teacher-step 474620 --e1 $X/epoch_05.pt --e1-data-dir $X --e1-step 237310 --e1-kind T0 --vae $VAE"
run() { local need=$1 phase=$2 tree=$3
  if [ -f $OUT/$phase.json ]; then echo "$phase already done"; return; fi
  wait_ram 12000
  while true; do
    read GPU free < <(nvidia-smi --query-gpu=index,memory.free --format=csv,noheader,nounits | tr -d ' ' | tr , ' ' | sort -k2 -n -r | head -1)
    [ "$free" -ge "$need" ] && break; echo "$(date +%T) waiting for $need MiB on a GPU (best GPU$GPU $free)"; sleep 30; done
  echo "$(date +%T) $phase on GPU$GPU"; CUDA_VISIBLE_DEVICES=$GPU $G --phase $phase --tree $tree $common; }
# thresholds: measured E1 gate peaks (3.4-3.7 GiB allocated, ~5 GB with CUDA context) plus allocator slack and a margin
# for evaluation workers on the same GPU
run 8000  contexts    $M
run 10000 v0_campaign $C
run 10000 v0_merged   $M
run 10000 e1_merged   $M
run 10000 e1_pure     $P
$G --phase summary --out $OUT
python - <<PY
import json; g = json.load(open('$OUT/gates.json'))
assert g['passed'] and g['checkpoint_sha256'] == '07d24ff77410e516ac90d24d76d651e2102b09b0458d9d5d86ea18dff39e823e'
assert g['teacher_sha256'] == '70cf5af73db5fe582c50c5f9fb68296d5271a9c0fea51509b3cdb5f9696be1ea' and g['kind'] == 'T0' and g['step'] == 237310
print('gates record checkpoint/teacher/kind/step verified')
PY
echo GATES_E0EP10_DONE
