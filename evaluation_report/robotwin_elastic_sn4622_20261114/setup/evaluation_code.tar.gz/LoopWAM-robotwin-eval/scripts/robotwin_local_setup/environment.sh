# Local RoboTwin evaluation runtime (host sn4622128794), modeled on the campaign's environment.sh.
export PYTHONPATH=/data/anh/code/LoopWAM-robotwin-eval/src:/data/anh/code/LoopWAM-robotwin-eval:/data/anh/code/LoopWAM-robotwin-eval/scripts
export DIFFSYNTH_MODEL_BASE_PATH=/data/anh/code/LoopWAM-robotwin-eval/checkpoints
export DIFFSYNTH_SKIP_DOWNLOAD=true
export PYTHONUNBUFFERED=1
export PYTHONNOUSERSITE=1
export OMP_NUM_THREADS=2
export MKL_NUM_THREADS=2
export OPENBLAS_NUM_THREADS=1
export TOKENIZERS_PARALLELISM=false
export CUDA_HOME=/data/anh/robotwin_eval/cuda128
export TORCH_CUDA_ARCH_LIST=12.0
export MAX_JOBS=8
export LOOPWAM_ROBOTWIN_SHADER=rt
export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/nvidia_icd.json
export PATH=/data/anh/robotwin_eval/env/bin:/data/anh/robotwin_eval/cuda128/bin:/usr/local/bin:/usr/bin:/bin

export TMPDIR=/data/anh/robotwin_eval/cache/tmp
export XDG_CACHE_HOME=/data/anh/robotwin_eval/cache/xdg
export CUDA_CACHE_PATH=/data/anh/robotwin_eval/cache/cuda
export TRITON_CACHE_DIR=/data/anh/robotwin_eval/cache/triton
export TORCHINDUCTOR_CACHE_DIR=/data/anh/robotwin_eval/cache/inductor
export __GL_SHADER_DISK_CACHE_PATH=/data/anh/robotwin_eval/cache/shader
