"""Read-only progress/SR snapshot of running elastic RoboTwin evaluations (does not touch the runs).
    python partial_sr.py [--ref REFERENCE_EPISODES_CSV] RESULT_DIR [RESULT_DIR ...]
The reference (v0 columns) defaults to the epoch-5 v0 campaign; for E0-epoch10-teacher-5ep pass
--ref /data/anh/code/LoopWAM_NT/evaluation_report/robotwin_v0_epoch10/episodes.csv"""
import csv, json, re, sys
from pathlib import Path
EPISODE = re.compile(r'Success rate: (?:\x1b\[\d+m)?(\d+)/(\d+).*?current seed: (?:\x1b\[\d+m)?(\d+)')
R = '/data/anh/code/LoopWAM_NT/evaluation_report/robotwin_v0/episodes.csv'
if len(sys.argv) > 2 and sys.argv[1] == '--ref': R = sys.argv[2]; del sys.argv[1:3]
print('reference:', R)
camp = {}
for r in csv.DictReader(open(R)):
    camp.setdefault((r['task'], r['setting']), {})[int(r['seed'])] = r['success'] == 'True'
for out in map(Path, sys.argv[1:]):
    summ = json.loads((out / 'summary.json').read_text())
    print(f"== {out.name}: finished {len(summ['finished'])}, running {len(summ['running'])}, pending {summ['pending']}, failed {summ['failed']}, COMPLETE {(out/'COMPLETE.json').exists()}")
    rows = []
    for key, v in list(summ['finished'].items()) + [(k, None) for k in summ['running']]:
        task, setting = key.split('/')
        cell = out / f'{task}__{setting}'
        if v is not None:
            recs = [(e['seed'], e['success']) for e in v['episodes']]; state = 'done'
        else:
            att = sorted(cell.glob('attempt_*'))[-1]
            log = (att / 'eval.log').read_text(errors='replace')
            prev = 0; recs = []
            for i, (s, c, seed) in enumerate(EPISODE.findall(log)):
                s, c = int(s), int(c); assert c == i + 1 and s - prev in (0, 1); recs.append((int(seed), bool(s - prev))); prev = s
            faults = [f for f in ('OIDN Error', 'cannot create buffer', 'OutOfMemoryError', 'out of memory') if f in log]
            state = f'running {att.name}' + (f' FAULTS {faults}' if faults else '')
        ref = camp[(task, setting)]
        n = len(recs); succ = sum(x for _, x in recs)
        common = [(sd, x) for sd, x in recs if sd in ref]
        rows.append((key, state, n, succ, len(common), sum(x for _, x in common), sum(ref[sd] for sd, _ in common), sum(ref[sd] for sd in sorted(ref)[:n]), sum(ref.values())))
    print(f"{'cell':42s} {'state':22s} {'E1':>9s} {'E1 SR':>6s} | {'paired n':>8s} {'E1':>4s} {'v0':>4s} | {'v0 first-n':>10s} {'v0 full':>7s}")
    for done_only in (False, True):
        tot = [0] * 6
        for key, state, n, succ, nc, e1c, v0c, v0n, v0full in rows:
            if done_only and state != 'done': continue
            if not done_only: print(f"{key:42s} {state:22s} {succ:4d}/{n:<4d} {100*succ/max(n,1):5.1f}% | {nc:8d} {e1c:4d} {v0c:4d} | {v0n:4d}/{n:<5d} {v0full:4d}/100")
            for j, x in enumerate((n, succ, nc, e1c, v0c, v0n)): tot[j] += x
        n, succ, nc, e1c, v0c, v0n = tot
        if n: print(f"{'FINISHED CELLS' if done_only else 'ALL EPISODES'} {n}: E1 {succ}/{n} = {100*succ/n:.2f}% | paired on {nc} common seeds: E1 {100*e1c/max(nc,1):.2f}% vs v0 {100*v0c/max(nc,1):.2f}% | v0 same cells {100*v0n/n:.2f}%")
