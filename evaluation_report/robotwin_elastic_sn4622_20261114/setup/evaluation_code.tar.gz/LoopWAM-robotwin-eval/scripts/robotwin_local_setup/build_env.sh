#!/usr/bin/env bash
# Python env for the local RoboTwin evaluation: campaign environment_freeze.txt pins (minus the editable LIBERO,
# Light-WAM and CuRobo installs), PyTorch 2.7.1+cu128, Python 3.10.21 (uv's newest 3.10; campaign 3.10.22).
set -euo pipefail
B=/data/anh/robotwin_eval
export UV_CACHE_DIR=$B/cache/uv TMPDIR=$B/cache/tmp
mkdir -p "$TMPDIR"
/home/anh/.local/bin/uv python install 3.10.21
[ -x $B/env/bin/python ] || /home/anh/.local/bin/uv venv --python 3.10.21 --seed $B/env
/home/anh/.local/bin/uv pip install --python $B/env/bin/python --index-strategy unsafe-best-match \
  --extra-index-url https://download.pytorch.org/whl/cu128 -r $B/setup/requirements_freeze.txt
echo ENV_BUILD_DONE
