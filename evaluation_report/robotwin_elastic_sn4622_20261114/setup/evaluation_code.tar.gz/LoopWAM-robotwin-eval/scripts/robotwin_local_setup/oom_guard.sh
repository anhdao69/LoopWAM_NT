#!/bin/bash
# OOM-victim ordering for the RoboTwin evaluation queue (2026-11-12). Changes nothing about how cells are evaluated: it only
# writes /proc/<pid>/oom_score_adj of our own processes, every 10 s, so that if the shared host runs out of memory the kernel
# kills the evaluation worker with the LEAST progress (cheapest to redo; the orchestrator rejects and retries the attempt),
# never a far-along worker, never our T5 server / orchestrator (which would abort every running cell), and never another
# user's process before ours.
#   worker adj = 1000 - 5 * episodes_done  (1000 .. 500; kernel badness = RSS share + adj, workers stay >= ~560)
#   T5 server, orchestrator, queue script adj = 400 (badness ~405-445: below every worker, above other users' processes,
#   which run at adj 0 or 200 with small RSS)
# The queue unit itself runs with OOMScoreAdjust=500, which every new worker inherits until the next pass.
while true; do
  for p in $(pgrep -u anh -f "evaluate_elastic_robotwin.py|t5_server_lean.py|run_elastic_queue.sh|run_e1_queue.sh"); do
    [ "$(cat /proc/$p/oom_score_adj 2>/dev/null)" = 400 ] || { echo 400 > /proc/$p/oom_score_adj 2>/dev/null && echo "$(date +%T) infra pid $p adj 400 ($(tr '\0' ' ' < /proc/$p/cmdline | cut -c1-80))"; }
  done
  for p in $(pgrep -u anh -f "script/eval_policy.py --config policy/elastic_policy/deploy_policy.yml"); do
    d=$(tr '\0' '\n' < /proc/$p/cmdline 2>/dev/null | grep -A1 -x -- '--eval_output_dir' | tail -1)
    [ -n "$d" ] && [ -f "$d/eval.log" ] || continue
    n=$(grep -c "Success rate:" "$d/eval.log" 2>/dev/null); n=${n:-0}; [ "$n" -gt 100 ] && n=100
    adj=$((1000 - 5 * n)); cur=$(cat /proc/$p/oom_score_adj 2>/dev/null)
    if [ -n "$cur" ] && [ "$cur" != "$adj" ]; then
      echo $adj > /proc/$p/oom_score_adj 2>/dev/null || echo "$(date +%T) FAILED to set adj $adj on $p"
      [ $((n % 20)) -eq 0 ] || [ "$cur" = 500 ] && echo "$(date +%T) worker $p ${d#/data/anh/robotwin_eval/results/} episodes $n adj $cur -> $adj"
    fi
  done
  sleep 10
done
