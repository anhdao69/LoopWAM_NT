#!/bin/bash
set -euo pipefail
source /data/anh/robotwin_eval/environment.sh
cd /data/anh/code/LoopWAM-robotwin-eval
exec python scripts/robotwin_scene_replay.py --cells adjust_bottle/demo_clean:10 --gpu 0 --need-mib 4096 \
  --output-dir /data/anh/robotwin_eval/verification/scene_replay --campaign-episodes /data/anh/code/LoopWAM_NT/evaluation_report/robotwin_v0/episodes.csv
