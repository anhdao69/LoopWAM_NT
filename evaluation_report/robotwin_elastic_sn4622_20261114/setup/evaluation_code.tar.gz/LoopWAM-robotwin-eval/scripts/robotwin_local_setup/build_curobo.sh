#!/usr/bin/env bash
# CuRobo v0.7.8 (verified source) as an editable install in the eval env, CUDA 12.8 (redist 12.8.0), SM 12.0.
set -euo pipefail
B=/data/anh/robotwin_eval
export CUDA_HOME=$B/cuda128 PATH=$B/cuda128/bin:$B/env/bin:/usr/bin:/bin TORCH_CUDA_ARCH_LIST=12.0 MAX_JOBS=8
export UV_CACHE_DIR=$B/cache/uv TMPDIR=$B/cache/tmp SETUPTOOLS_SCM_PRETEND_VERSION=0.0.0  # campaign freeze: nvidia_curobo==0.0.0
cd $B/curobo-0.7.8
/home/anh/.local/bin/uv pip install --python $B/env/bin/python --no-build-isolation --no-deps -e . 
echo CUROBO_BUILD_DONE
