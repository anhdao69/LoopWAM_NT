#!/bin/bash
# E1 smoke evaluation (RT50-ep5-E1, flat_k4_n10) under the local RTX RoboTwin protocol, after the GPU gates passed.
# Waits for GPU memory: lean T5 server (~12 GB) + one worker (RT renderer up to ~5 GB + E1 policy), never preempting anyone.
set -euo pipefail
B=/data/anh/robotwin_eval; source $B/environment.sh
M=/data/anh/code/LoopWAM-robotwin-eval; OUT=$B/results/e1_smoke_flat_k4_n10
TASKS=${TASKS:-adjust_bottle,click_bell}; EPISODES=${EPISODES:-3}; SCHEDULE=${SCHEDULE:-flat_k4_n10}
NEED_T5=${NEED_T5:-13500}; NEED_WORKER=${NEED_WORKER:-12000}
while systemctl --user is-active --quiet rtw-gates; do sleep 60; done
python - <<PY
import json,sys; g=json.load(open('$B/verification/gates/gates.json')); sys.exit(0 if g['passed'] else 'GPU gates did not pass')
PY
free_mib() { nvidia-smi -i "$1" --query-gpu=memory.free --format=csv,noheader,nounits; }
ram_mib() { awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo; }
while true; do
  f0=$(free_mib 0); f1=$(free_mib 1); ram=$(ram_mib); T=; W=
  if   [ "$f0" -ge $((NEED_T5+NEED_WORKER)) ]; then T=0; W=0
  elif [ "$f1" -ge $((NEED_T5+NEED_WORKER)) ]; then T=1; W=1
  elif [ "$f0" -ge "$NEED_T5" ] && [ "$f1" -ge "$NEED_WORKER" ]; then T=0; W=1
  elif [ "$f1" -ge "$NEED_T5" ] && [ "$f0" -ge "$NEED_WORKER" ]; then T=1; W=0; fi
  if [ -n "$T" ] && [ "$ram" -ge 16000 ]; then break; fi
  echo "$(date +%T) waiting: GPU0 free ${f0} MiB, GPU1 free ${f1} MiB, RAM available ${ram} MiB"; sleep 60
done
echo "$(date +%T) T5 on GPU$T, worker on GPU$W"
CUDA_VISIBLE_DEVICES=$T python $M/scripts/check_t5_lean.py $B/verification/gates/contexts.pt $B/verification/t5_lean_full_gpu.json
export LOOPWAM_VULKAN_DEVICE_SELECT=1 LOOPWAM_CUDA_GRAPH=0
python $M/scripts/evaluate_elastic_robotwin.py --checkpoint $B/checkpoints/E1/epoch_01.pt --output-dir $OUT \
  --robotwin-root $M/third_party/RoboTwin --data-dir $B/checkpoints/E1 --schedule $SCHEDULE --tasks $TASKS \
  --settings demo_clean,demo_randomized --episodes $EPISODES --gpus $W --per-gpu 1 --expected-kind T1 \
  --t5-loader lean --t5-gpu $T
python $M/scripts/robotwin_smoke_check.py $OUT /data/anh/code/LoopWAM_NT/evaluation_report/robotwin_v0/episodes.csv $B/verification/e1_smoke_check.json
echo E1_SMOKE_DONE
