#!/bin/bash
# E1 (RT50-ep5-E1) RoboTwin evaluations under the local RTX protocol, several schedules in the given order from ONE
# orchestrator (scripts/evaluate_elastic_robotwin.py): one shared lean T5 server; cells of evaluation 1 all start before
# any cell of evaluation 2; within an evaluation, cells start longest-first (v0 campaign durations); a worker starts
# only while its GPU and the host have room (never preempting anyone). Scheduling never changes how a cell is evaluated.
# Parameters via systemd-run -E NAME=value:
#   SCHEDULES=flat_k1_n2,flat_k4_n2,flat_k4_n5  OUTS=<dir1>,<dir2>,<dir3> (default $B/results/e1_<schedule>)
#   TASKS=all EPISODES=100 GPUS=0,1 PER_GPU=6 ADMIT_GPU=11000 GPU_FLOOR=1500 ADMIT_RAM=6000 RAM_FLOOR=6000 HOLD=300 MAX_ATTEMPTS=8
# Worker peaks measured in the 2026-11-07 smoke: 9.3-10.3 GB GPU, 4.6-5.4 GB RSS; lean T5 server 11.5 GB GPU, 1.8 GB RSS.
set -uo pipefail
B=/data/anh/robotwin_eval; source $B/environment.sh
M=/data/anh/code/LoopWAM-robotwin-eval; R=/data/anh/code/LoopWAM_NT/evaluation_report/robotwin_v0
SCHEDULES=${SCHEDULES:?}; TASKS=${TASKS:-all}; EPISODES=${EPISODES:-100}; GPUS=${GPUS:-0,1}; PER_GPU=${PER_GPU:-6}
ADMIT_GPU=${ADMIT_GPU:-11000}; GPU_FLOOR=${GPU_FLOOR:-1500}; ADMIT_RAM=${ADMIT_RAM:-6000}; RAM_FLOOR=${RAM_FLOOR:-6000}; HOLD=${HOLD:-300}
MAX_ATTEMPTS=${MAX_ATTEMPTS:-8}; NEED_T5=${NEED_T5:-12500}; NEED_T5_RAM=${NEED_T5_RAM:-14000}; RELAUNCHES=${RELAUNCHES:-3}
IFS=, read -ra S <<< "$SCHEDULES"
if [ -n "${OUTS:-}" ]; then IFS=, read -ra O <<< "$OUTS"; else O=(); for s in "${S[@]}"; do O+=("$B/results/e1_$s"); done; fi
[ ${#S[@]} -eq ${#O[@]} ] || { echo "SCHEDULES/OUTS length mismatch"; exit 2; }
# every schedule must be covered by a passed gate record
python - "${S[@]}" <<PY || exit 2
import json, sys
from pathlib import Path
covered = set()
for f in Path('$B/verification').glob('gates*/gates.json'):
    g = json.loads(f.read_text())
    if g['passed']: covered |= set(g['schedules'])
missing = [s for s in sys.argv[1:] if s not in covered]
print('gate-covered schedules:', sorted(covered)); sys.exit(f'no passed GPU gate for {missing}' if missing else 0)
PY
export LOOPWAM_VULKAN_DEVICE_SELECT=1 LOOPWAM_CUDA_GRAPH=0 LOOPWAM_RUNTIME_MANIFEST=$B/runtime_manifest.json
args=(); for i in "${!S[@]}"; do args+=(--schedule "${S[$i]}" --output-dir "${O[$i]}"); done
[ "$TASKS" != all ] && args+=(--tasks "$TASKS")
check() {   # campaign seed check + independent audit of one finished evaluation
  local s=$1 out=$2
  python $M/scripts/robotwin_smoke_check.py "$out" $R/episodes.csv "$out/campaign_seed_check.json" > "$out/campaign_seed_check.log" 2>&1 \
    && echo "$s: campaign seed check passed" || { echo "$s: campaign seed check FAILED"; return 1; }
  python $M/scripts/robotwin_eval_audit.py "$out" $R/episodes.csv "$out/audit.json" > "$out/audit.log" 2>&1 \
    && echo "$s: audit passed" || { echo "$s: audit FAILED (see $out/audit.log)"; return 1; }
}
for i in "${!S[@]}"; do   # check each evaluation as soon as it completes, while later ones still run
  ( until [ -f "${O[$i]}/COMPLETE.json" ]; do sleep 300; done; check "${S[$i]}" "${O[$i]}" ) &
done
rc=1
for launch in $(seq 1 $((RELAUNCHES+1))); do
  while true; do      # the T5 server goes on the GPU with the most free memory
    read T free < <(nvidia-smi --query-gpu=index,memory.free --format=csv,noheader,nounits | tr -d ' ' | tr , ' ' | sort -k2 -n -r | head -1)
    ram=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo)
    [ "$free" -ge "$NEED_T5" ] && [ "$ram" -ge "$NEED_T5_RAM" ] && break
    echo "$(date +%T) waiting for T5 room: best GPU$T free ${free} MiB, RAM ${ram} MiB"; sleep 60
  done
  echo "$(date +%T) launch $launch: T5 on GPU$T; schedules ${S[*]}"
  python $M/scripts/evaluate_elastic_robotwin.py --checkpoint $B/checkpoints/E1/epoch_01.pt \
    --robotwin-root $M/third_party/RoboTwin --data-dir $B/checkpoints/E1 --episodes "$EPISODES" \
    --gpus "$GPUS" --per-gpu "$PER_GPU" --expected-kind T1 --t5-loader lean --t5-gpu "$T" \
    --max-attempts "$MAX_ATTEMPTS" --order campaign-longest-first --campaign-results $R/task_results.csv \
    --admit-gpu-mib "$ADMIT_GPU" --gpu-floor-mib "$GPU_FLOOR" --admit-ram-mib "$ADMIT_RAM" --ram-floor-mib "$RAM_FLOOR" --admit-hold "$HOLD" "${args[@]}"
  rc=$?; echo "$(date +%T) orchestrator exit $rc"
  [ $rc -eq 0 ] && break
  sleep 60
done
status=$rc
kill $(jobs -p) 2>/dev/null; wait 2>/dev/null   # stop the per-evaluation checkers; the final checks below cover all
for i in "${!S[@]}"; do
  out=${O[$i]}
  if [ ! -f "$out/COMPLETE.json" ]; then echo "${S[$i]}: not complete"; status=1; continue; fi
  check "${S[$i]}" "$out" || status=1
done
[ $status -eq 0 ] && echo E1_QUEUE_DONE || echo E1_QUEUE_INCOMPLETE
exit $status
