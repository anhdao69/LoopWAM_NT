#!/bin/bash
# E1 (RT50-ep5-E1) RoboTwin evaluation under the local RTX protocol (seed 42, 50 tasks x clean/randomized x 100 accepted
# episodes by default). Parameters via systemd-run -E NAME=value, e.g.
#   systemd-run --user --unit=rtw-e1-eval -p OOMPolicy=continue -E SCHEDULE=flat_k4_n10 -E GPUS=0,1 -E PER_GPU=1 -E T5_GPU=0 \
#       /data/anh/robotwin_eval/setup/run_e1_eval.sh
# Waits until the T5 GPU has NEED_T5 MiB free and every worker GPU NEED_WORKER MiB per worker (summed where they share).
set -euo pipefail
B=/data/anh/robotwin_eval; source $B/environment.sh
M=/data/anh/code/LoopWAM-robotwin-eval
SCHEDULE=${SCHEDULE:-flat_k4_n10}; TASKS=${TASKS:-all}; EPISODES=${EPISODES:-100}
GPUS=${GPUS:-0}; PER_GPU=${PER_GPU:-1}; T5_GPU=${T5_GPU:-${GPUS%%,*}}
NEED_T5=${NEED_T5:-13500}; NEED_WORKER=${NEED_WORKER:-12000}
OUT=${OUT:-$B/results/e1_${SCHEDULE}}
python - <<PY
import json,sys; g=json.load(open('$B/verification/gates/gates.json')); sys.exit(0 if g['passed'] else 'GPU gates did not pass')
PY
until python - <<PY
import subprocess, sys
need = {}
need['$T5_GPU'] = need.get('$T5_GPU', 0) + $NEED_T5
for g in '$GPUS'.split(','): need[g] = need.get(g, 0) + $NEED_WORKER * $PER_GPU
free = {g: int(subprocess.check_output(['nvidia-smi', '-i', g, '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True)) for g in need}
ram = int(open('/proc/meminfo').read().split('MemAvailable:')[1].split()[0]) // 1024
ok = all(free[g] >= n for g, n in need.items()) and ram >= 10000 + 7000 * $PER_GPU * len('$GPUS'.split(','))
print('need', need, 'free', free, 'RAM MiB', ram, 'ok' if ok else 'waiting', flush=True); sys.exit(0 if ok else 1)
PY
do sleep 60; done
export LOOPWAM_VULKAN_DEVICE_SELECT=1 LOOPWAM_CUDA_GRAPH=${LOOPWAM_CUDA_GRAPH:-0} LOOPWAM_RUNTIME_MANIFEST=$B/runtime_manifest.json
args=(); [ "$TASKS" != all ] && args+=(--tasks "$TASKS")
python $M/scripts/evaluate_elastic_robotwin.py --checkpoint $B/checkpoints/E1/epoch_01.pt --output-dir "$OUT" \
  --robotwin-root $M/third_party/RoboTwin --data-dir $B/checkpoints/E1 --schedule "$SCHEDULE" --episodes "$EPISODES" \
  --gpus "$GPUS" --per-gpu "$PER_GPU" --expected-kind T1 --t5-loader lean --t5-gpu "$T5_GPU" "${args[@]}"
python $M/scripts/robotwin_smoke_check.py "$OUT" /data/anh/code/LoopWAM_NT/evaluation_report/robotwin_v0/episodes.csv "$OUT/campaign_seed_check.json"
echo E1_EVAL_DONE
