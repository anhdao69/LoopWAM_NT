# Diagnostic only (never used by evaluations): log wall time / success / status of every CuRobo MotionGen plan call.
import importlib.abc, importlib.util, json, os, sys, time
TARGET = 'curobo.wrap.reacher.motion_gen'
class _Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target=None):
        if name != TARGET: return None
        sys.meta_path.remove(self)
        spec = importlib.util.find_spec(name)
        original_exec = spec.loader.exec_module
        def exec_module(module):
            original_exec(module)
            for method in ('plan_single', 'plan_batch'):
                orig = getattr(module.MotionGen, method)
                def wrapped(self, *a, _orig=orig, _m=method, **k):
                    if os.environ.get('DIAG_NO_TIMEOUT') == '1':     # diagnostic: keep max_attempts, drop the wall-clock limit
                        for x in list(a) + list(k.values()):
                            if type(x).__name__ == 'MotionGenPlanConfig': x.timeout = 1e9
                    t = time.time(); r = _orig(self, *a, **k)
                    try: ok = [bool(x) for x in r.success.flatten().tolist()]
                    except Exception: ok = None
                    print(json.dumps(dict(curobo_plan=_m, seconds=round(time.time() - t, 3), success=ok, status=str(r.status),
                                          attempts=getattr(r, 'attempts', None), total_time=round(float(getattr(r, 'total_time', 0) or 0), 3))), flush=True)
                    return r
                setattr(module.MotionGen, method, wrapped)
        spec.loader.exec_module = exec_module
        return spec
sys.meta_path.insert(0, _Finder())
