#!/bin/bash
# E1 gate phases (e1_merged on the merged tree, e1_pure on the pristine elastic tree, summary) for the schedules of the
# 2026-11-07 evaluation queue (flat_k1_n2, flat_k4_n2, flat_k4_n5) plus flat_k4_n10 (the CUDA-graph check schedule).
# Text contexts, v0 outputs and v0 inputs are copied unchanged from the passed gates (verification/gates).
set -euo pipefail
B=/data/anh/robotwin_eval; source $B/environment.sh; unset PYTHONPATH
M=/data/anh/code/LoopWAM-robotwin-eval; P=/data/anh/code/LoopWAM-elastic-robotwin-2c78ff6
SRC=$B/verification/gates; OUT=$B/verification/gates_eval3; mkdir -p $OUT
for f in contexts.json contexts.pt v0_campaign.json v0_campaign.pt v0_merged.json v0_inputs.pt; do
  [ -f $OUT/$f ] || cp -p $SRC/$f $OUT/$f; cmp $SRC/$f $OUT/$f; done
# exactly the captures of the passed gates (their T5 contexts are the copied contexts.pt): ids must match gates.json
CAPS="$B/verification/scene_replay/adjust_bottle__demo_clean/captured_observations $B/verification/scene_replay_diag/adjust_bottle__demo_randomized/captured_observations"
python - $CAPS <<PY
import json, sys
from pathlib import Path
ids = sorted(f"{Path(d).parent.name}/ep{json.loads(j.read_text())['episode']}" for d in sys.argv[1:] for j in Path(d).glob('episode*.json'))
want = json.loads(Path('$SRC/gates.json').read_text())['captures']
print('capture ids', ids); sys.exit(0 if ids == sorted(want) else f'capture ids differ from the passed gates: {want}')
PY
echo "captures: $CAPS"
export GATE_SCHEDULES=flat_k1_n2,flat_k4_n2,flat_k4_n5,flat_k4_n10 GATE_MODEL_BASE=$M/checkpoints
GPU=$(nvidia-smi --query-gpu=index,memory.free --format=csv,noheader,nounits | sort -t, -k2 -n -r | head -1 | cut -d, -f1)
while [ "$(nvidia-smi -i $GPU --query-gpu=memory.free --format=csv,noheader,nounits)" -lt 7000 ]; do echo "$(date +%T) waiting for GPU$GPU"; sleep 30; done
export CUDA_VISIBLE_DEVICES=$GPU; echo "gates on GPU$GPU"
G="python $M/scripts/elastic_robotwin_gates.py"
common="--out $OUT --captures $CAPS --teacher $B/checkpoints/v0-video4-action4/policy.pt --teacher-data-dir $B/checkpoints/v0-video4-action4 --e1 $B/checkpoints/E1/epoch_01.pt --e1-data-dir $B/checkpoints/E1 --vae $M/checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth"
[ -f $OUT/e1_merged.json ] || $G --phase e1_merged --tree $M $common
[ -f $OUT/e1_pure.json ] || $G --phase e1_pure --tree $P $common
$G --phase summary --out $OUT
echo GATES_EVAL3_DONE
