#!/usr/bin/env python3
"""Local RoboTwin runtime manifest (sn4622128794): sha256 of every runtime asset/dependency file, compared with the
campaign's runtime_manifest.json (LoopWAM_NT evaluation_report/robotwin_v0) by relative path.

Categories mirror the campaign manifest: assets/, curobo-0.7.8/ sources (+ the 5 locally compiled sm_120 extensions,
which cannot match), env sapien/mplib/OIDN files, Wan VAE/T5/tokenizer files. Writes runtime_manifest.json.
"""
import hashlib, json, os, sys, time
from pathlib import Path

B = Path('/data/anh/robotwin_eval'); M = Path('/data/anh/code/LoopWAM-robotwin-eval')
CAMPAIGN = Path('/data/anh/code/LoopWAM_NT/evaluation_report/robotwin_v0/runtime_manifest.json')
SITE = B / 'env/lib/python3.10/site-packages'


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''): h.update(b)
    return h.hexdigest()


def campaign_key(path):
    """Campaign path -> comparable relative key."""
    for pre, key in (('/data14t/anhdh35/loopwam_robotwin_v0_20261030/assets/', 'assets/'),
                     ('/data14t/anhdh35/loopwam_robotwin_v0_20261030/curobo-0.7.8/', 'curobo/'),
                     ('/storage/anhdh35/LoopWAM-robotwin-eval/checkpoints/', 'checkpoints/')):
        if path.startswith(pre): return key + path[len(pre):]
    if '/site-packages/' in path: return 'site-packages/' + path.split('/site-packages/', 1)[1]
    return None


def main():
    campaign = {}
    for p, v in json.loads(CAMPAIGN.read_text())['files'].items():
        k = campaign_key(p)
        if k: campaign[k] = v['sha256']
    files = {}
    for f in sorted((B / 'assets').rglob('*')):
        if f.is_file(): files['assets/' + str(f.relative_to(B / 'assets'))] = f
    for f in sorted((B / 'curobo-0.7.8').rglob('*')):
        if f.is_file() and '/build/' not in str(f) and '__pycache__' not in str(f) and '.egg-info' not in str(f):
            files['curobo/' + str(f.relative_to(B / 'curobo-0.7.8'))] = f
    for k in campaign:
        if k.startswith('site-packages/') and (SITE / k[len('site-packages/'):]).is_file(): files[k] = SITE / k[len('site-packages/'):]
        if k.startswith('checkpoints/') and (M / k).exists(): files[k] = M / k
    for f in sorted((SITE / 'sapien/oidn_library').glob('*')): files['site-packages/' + str(f.relative_to(SITE))] = f
    started = time.time(); records = {}
    for k, f in files.items():
        h = sha(f); c = campaign.get(k)
        records[k] = dict(path=str(f), real_path=str(Path(f).resolve()), sha256=h,
                          campaign=None if c is None else ('equal' if c == h else 'DIFFERENT'))
    differing = sorted(k for k, r in records.items() if r['campaign'] == 'DIFFERENT')
    local_only = sorted(k for k, r in records.items() if r['campaign'] is None)
    missing = sorted(set(campaign) - set(records))
    out = dict(host=os.uname().nodename, created_unix=time.time(), seconds=time.time() - started, files=records,
               summary=dict(files=len(records), equal=sum(r['campaign'] == 'equal' for r in records.values()),
                            different=differing, local_only=local_only, campaign_only=missing))
    (B / 'runtime_manifest.json').write_text(json.dumps(out, indent=1))
    print(json.dumps(out['summary'], indent=1)[:6000])


if __name__ == '__main__':
    main()
