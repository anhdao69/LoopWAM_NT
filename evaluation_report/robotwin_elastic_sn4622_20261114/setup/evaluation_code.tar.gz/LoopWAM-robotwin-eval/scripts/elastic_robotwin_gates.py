#!/usr/bin/env python3
"""GPU gates for a RoboTwin elastic student deployment (E1, E0-epoch10-teacher-5ep, ...) on real simulator observations, before any evaluation.

Inputs are first observations captured by the unmodified harness (policy/scene_replay_policy) on this host. Each phase is
a separate process on one GPU (run in sequence; ~5 GB each), importing code only from --tree:
  contexts     merged tree: UMT5 contexts of the captured instructions (elastic_policy/t5_lean.py, stream=True), encoded
               twice (determinism); gate inputs only, injected into each policy's TextEncoder memo.
  v0_campaign  campaign-exact tree (evaluator commit 9cdceaa, 777/777 protocol hashes): the deployed v0 teacher policy
               (LoopWAMRoboTwinPolicy._query; raw infer_action output recorded).
  v0_merged    merged tree: the same v0 policy, bit-equal to v0_campaign (the merged loopwam_robot.py only adds payload=);
               and the teacher rollout through the elastic deployment's input path (ElasticRoboTwinPolicy.observation_inputs
               / model_inputs + TransportPolicy.velocity(teacher=True), 10 Euler steps, exactly as elastic_robotwin
               scripts/preflight_rt50.py) bit-equal to the deployed v0 infer_action.
  e1_merged    merged tree: the E1 deployment object (ElasticRoboTwinPolicy): inputs bit-equal to the v0 policy's, eager
               rollouts for several schedules (finite, deterministic, _query == normalizer(infer)), CUDA graph == eager
               (capture, then replay with new observations).
  e1_pure      pristine elastic_robotwin tree (2c78ff6): load_robot_transport + rollout on the saved samples, bit-equal
               to e1_merged.
  summary      all comparisons -> gates.json (passed / failed per check).
"""
import argparse, glob, json, os, sys, time
from pathlib import Path

SCHEDULES = tuple(os.environ.get('GATE_SCHEDULES', 'flat_k4_n10,flat_k1_n2,flat_k2_n5,flat_k4_n5,flat_k1_n10').split(','))
GRAPH_SCHEDULE = 'flat_k4_n10'


def setup_tree(tree):
    tree = Path(tree).resolve()
    for p in (str(tree / 'scripts'), str(tree), str(tree / 'src')): sys.path.insert(0, p)
    os.environ['DIFFSYNTH_MODEL_BASE_PATH'] = str(Path(os.environ.get('GATE_MODEL_BASE', tree / 'checkpoints')))
    import importlib
    for name in ('fastwam', 'experiments'):
        module = importlib.import_module(name)
        where = list(getattr(module, '__path__', [])) or [module.__file__]
        if not all(str(Path(w).resolve()).startswith(str(tree) + '/') for w in where):
            raise RuntimeError(f'{name} imported from {where}, not {tree}')
    return tree


def load_captures(dirs):
    import numpy as np
    out = []
    for d in dirs:
        for npz in sorted(glob.glob(str(Path(d) / 'episode*.npz'))):
            meta = json.loads(Path(npz).with_suffix('.json').read_text()); arrays = np.load(npz)
            cams = {k[len('rgb__'):]: {'rgb': arrays[k]} for k in arrays.files if k.startswith('rgb__')}
            cell = Path(d).parent.name
            out.append(dict(id=f"{cell}/ep{meta['episode']}", instruction=meta['instruction'],
                            observation={'observation': cams, 'joint_action': {'vector': arrays['joint']}}))
    if len(out) < 2: raise ValueError('Need at least two captured observations')
    return out


def prompt_of(instruction):
    from fastwam.datasets.loopwam_long import DEFAULT_PROMPT
    return DEFAULT_PROMPT.format(task=instruction)


def inject(text_encoder, contexts):
    for prompt, (context, mask) in contexts.items(): text_encoder.memo[prompt] = (context.clone(), mask.clone())
    text_encoder.encoder = 'forbidden: gate contexts are injected'        # any cache miss fails loudly


def file_sha256(path):
    import hashlib
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''): h.update(block)
    return h.hexdigest()


def eq(a, b):
    import torch
    a, b = torch.as_tensor(a), torch.as_tensor(b)
    return dict(bit_equal=bool(a.dtype == b.dtype and a.shape == b.shape and torch.equal(a, b)),
                max_abs_diff=float((a.double() - b.double()).abs().max()) if a.shape == b.shape else None)


def phase_contexts(a, captures):
    import torch
    from experiments.robotwin.elastic_policy.t5_lean import lean_text_encoder
    encoder = lean_text_encoder(device='cuda', stream=True)
    contexts, rows = {}, []
    for c in captures:
        prompt = prompt_of(c['instruction'])
        if prompt in contexts: continue
        first = encoder(prompt); encoder.memo.clear(); second = encoder(prompt)
        contexts[prompt] = first
        rows.append(dict(prompt=prompt, deterministic=bool(torch.equal(first[0], second[0]) and torch.equal(first[1], second[1])),
                         tokens=int(first[1].sum()), finite=bool(torch.isfinite(first[0].float()).all()),
                         padding_zero=bool((first[0][~first[1]] == 0).all()), abs_mean=float(first[0].float().abs().mean())))
    torch.save(contexts, a.out / 'contexts.pt')
    return dict(rows=rows, peak_gib=torch.cuda.max_memory_allocated() / 2**30)


def v0_policy(a, contexts):
    from experiments.robotwin.loopwam_policy.deploy_policy import LoopWAMRoboTwinPolicy
    policy = LoopWAMRoboTwinPolicy(a.teacher, a.teacher_data_dir, a.vae, seed=42, t5_server=None, expected_step=a.teacher_step)
    inject(policy.text, contexts)
    raw, original = [], policy.model.infer_action
    def recorder(**kw):
        out = original(**kw); raw.append(out['action'].detach().float().cpu().clone()); return out
    policy.model.infer_action = recorder
    return policy, raw


def run_v0(policy, raw, captures):
    import torch
    out = {}
    for c in captures:
        policy.reset(); denorm = policy._query(c['observation'], c['instruction'])
        out[c['id']] = dict(raw=raw[-1], denormalized=torch.from_numpy(denorm.copy()))
    return out


def phase_v0_campaign(a, captures, contexts):
    import torch
    policy, raw = v0_policy(a, contexts)
    out = run_v0(policy, raw, captures); again = run_v0(policy, raw, captures)
    torch.save(out, a.out / 'v0_campaign.pt')
    return dict(teacher=str(Path(a.teacher).resolve()), teacher_sha256=file_sha256(a.teacher), teacher_step=a.teacher_step,
                deterministic={k: eq(out[k]['raw'], again[k]['raw'])['bit_equal'] for k in out},
                finite={k: bool(torch.isfinite(v['raw']).all()) for k, v in out.items()},
                peak_gib=torch.cuda.max_memory_allocated() / 2**30)


def teacher_rollout(policy, transport, captures, raw_reference):
    """ElasticRoboTwinPolicy input path on the v0 parent + teacher velocities, as elastic_robotwin preflight_rt50.py."""
    import torch
    from experiments.robotwin.elastic_policy.deploy_policy import ElasticRoboTwinPolicy
    shim = object.__new__(ElasticRoboTwinPolicy)
    shim.parent, shim.seed, shim.normalizer, shim.text = policy.model, 42, policy.normalizer, policy.text
    parent = policy.model; rows = {}; inputs = {}
    for c in captures:
        image, proprio, context, mask = ElasticRoboTwinPolicy.observation_inputs(shim, c['observation'], c['instruction'])
        inputs[c['id']] = dict(image=image.cpu(), proprio=proprio.cpu(), context=context.cpu(), mask=mask.cpu())
        with torch.inference_mode(), torch.autocast('cuda', dtype=torch.bfloat16):
            sample, z = ElasticRoboTwinPolicy.model_inputs(shim, image, proprio, context, mask)
            context_, mask_, keys, values, attention = transport.prefill(sample)
            condition = transport.conditioning(parent.action_expert, context_, mask_)
            times, deltas = parent.infer_action_scheduler.build_inference_schedule(10, z.device, z.dtype, shift_override=1.)
            for j in range(10):
                v, _ = transport.velocity(z, (times[j] / 1000).expand(1), condition, (keys, values, attention),
                                          teacher=True, native_timestep=times[j].expand(1))
                z = z + v * deltas[j]
        rows[c['id']] = eq(z[0].float().cpu(), raw_reference[c['id']]['raw'])
    return rows, inputs


def phase_v0_merged(a, captures, contexts):
    import torch
    from fastwam.models.wan22.transport_policy import TransportPolicy
    campaign = torch.load(a.out / 'v0_campaign.pt')
    policy, raw = v0_policy(a, contexts)
    merged = run_v0(policy, raw, captures)
    transport = TransportPolicy(policy.model, kind='T0', scope='pc', step_cond=True, regime='fu', anchor=True,
                                checkpoint_blocks=False).to('cuda')
    teacher, inputs = teacher_rollout(policy, transport, captures, campaign)
    after = run_v0(policy, raw, captures)                       # building the transport wrapper leaves v0 unchanged
    torch.save(inputs, a.out / 'v0_inputs.pt')
    return dict(merged_equals_campaign={k: eq(merged[k]['raw'], campaign[k]['raw']) for k in merged},
                merged_denormalized_equals_campaign={k: eq(merged[k]['denormalized'], campaign[k]['denormalized'])['bit_equal'] for k in merged},
                teacher_rollout_equals_v0_infer_action=teacher,
                v0_unchanged_after_transport={k: eq(after[k]['raw'], campaign[k]['raw'])['bit_equal'] for k in after},
                peak_gib=torch.cuda.max_memory_allocated() / 2**30)


def phase_e1_merged(a, captures, contexts):
    import numpy as np, torch
    from experiments.robotwin.elastic_policy.deploy_policy import ElasticRoboTwinPolicy, parse_schedule, load_header
    from experiments.robotwin.loopwam_policy.cuda_graph import GraphedCall
    if os.environ.get('LOOPWAM_CUDA_GRAPH') == '1': raise RuntimeError('The eager reference needs LOOPWAM_CUDA_GRAPH unset')
    v0_inputs = torch.load(a.out / 'v0_inputs.pt'); header = load_header(a.e1)
    policy = ElasticRoboTwinPolicy(a.e1, a.e1_data_dir, a.vae, schedule=GRAPH_SCHEDULE, seed=42, t5_server=None,
                                   expected_step=a.e1_step, expected_kind=a.e1_kind)
    inject(policy.text, contexts)
    report = dict(trained_schedules=header['schedules'], kind=header['kind'], step=header['step'], inputs_equal_v0={}, schedules={},
                  checkpoint=str(Path(a.e1).resolve()), checkpoint_sha256=file_sha256(a.e1), teacher=str(Path(a.teacher).resolve()))
    saved = {}
    for c in captures:
        image, proprio, context, mask = policy.observation_inputs(c['observation'], c['instruction'])
        ref = v0_inputs[c['id']]
        report['inputs_equal_v0'][c['id']] = all(eq(x.cpu(), ref[k])['bit_equal'] for k, x in
                                                 dict(image=image, proprio=proprio, context=context, mask=mask).items())
        with torch.inference_mode(), torch.autocast('cuda', dtype=torch.bfloat16):
            sample, noise = policy.model_inputs(image, proprio, context, mask)
        saved[c['id']] = dict(sample={k: v.detach().cpu().clone() for k, v in sample.items()}, noise=noise.detach().cpu().clone(),
                              inputs=(image, proprio, context, mask))
    outputs = {}
    for name in SCHEDULES:
        policy.schedule, policy.depths = name, parse_schedule(name)
        rows = {}
        for c in captures:
            image, proprio, context, mask = saved[c['id']]['inputs']
            first = policy.infer(image, proprio, context, mask); second = policy.infer(image, proprio, context, mask)
            policy.reset(); denorm = policy._query(c['observation'], c['instruction'])
            expected = policy.normalizer['action'].backward(first[None])[0].numpy()
            outputs[(name, c['id'])] = first
            rows[c['id']] = dict(finite=bool(torch.isfinite(first).all()), deterministic=eq(first, second)['bit_equal'],
                                 query_equals_normalized_infer=bool(np.array_equal(denorm, expected)),
                                 abs_mean=float(first.abs().mean()))
        report['schedules'][name] = dict(depths=list(policy.depths), trained=name in header['schedules'], rows=rows)
    # CUDA graph == eager on the evaluation schedule: first call captures, the following calls replay with new inputs
    policy.schedule, policy.depths = GRAPH_SCHEDULE, parse_schedule(GRAPH_SCHEDULE)
    graphed = GraphedCall(policy.policy.rollout); graph_rows = {}
    for c in captures + captures[::-1]:
        s = saved[c['id']]
        sample = {k: v.to('cuda') for k, v in s['sample'].items()}; noise = s['noise'].to('cuda')
        with torch.inference_mode(), torch.autocast('cuda', dtype=torch.bfloat16):
            eager = policy.policy.rollout(sample, policy.depths, noise)[0].float().cpu()
            graph = graphed(sample, policy.depths, noise)[0].float().cpu()
        graph_rows.setdefault(c['id'], []).append(dict(graph_equals_eager=eq(graph, eager), eager_equals_infer=eq(eager, outputs[(GRAPH_SCHEDULE, c['id'])])['bit_equal']))
    report['cuda_graph'] = graph_rows
    torch.save(dict(saved={k: dict(sample=v['sample'], noise=v['noise']) for k, v in saved.items()},
                    outputs={f'{n}|{i}': t for (n, i), t in outputs.items()}), a.out / 'e1_merged.pt')
    report['peak_gib'] = torch.cuda.max_memory_allocated() / 2**30
    return report


def phase_e1_pure(a, captures, contexts):
    import torch
    from fastwam.models.wan22.transport_inference_robot import load_robot_transport
    from fastwam.models.wan22 import transport_inference_robot
    ref = torch.load(a.out / 'e1_merged.pt')
    policy, payload = load_robot_transport(a.e1, a.vae, device='cuda'); del payload
    policy.eval()
    rows = {}
    for key, expected in ref['outputs'].items():
        name, cid = key.split('|', 1)
        k, n = (int(x) for x in name[len('flat_k'):].split('_n'))       # SCHEDULES are all flat_k<K>_n<N>
        s = ref['saved'][cid]
        sample = {kk: v.to('cuda') for kk, v in s['sample'].items()}; noise = s['noise'].to('cuda')
        with torch.inference_mode(), torch.autocast('cuda', dtype=torch.bfloat16):
            out = policy.rollout(sample, (k,) * n, noise)[0].detach().float().cpu()
        rows[key] = eq(out, expected)
    return dict(module=transport_inference_robot.__file__, rows=rows, peak_gib=torch.cuda.max_memory_allocated() / 2**30)


def phase_summary(a):
    r = {p: json.loads((a.out / f'{p}.json').read_text()) for p in ('contexts', 'v0_campaign', 'v0_merged', 'e1_merged', 'e1_pure')}
    checks = {
        'contexts_deterministic_finite_padded': all(x['deterministic'] and x['finite'] and x['padding_zero'] for x in r['contexts']['rows']),
        'v0_campaign_deterministic_finite': all(r['v0_campaign']['deterministic'].values()) and all(r['v0_campaign']['finite'].values()),
        'v0_merged_tree_equals_campaign_tree': all(x['bit_equal'] for x in r['v0_merged']['merged_equals_campaign'].values())
            and all(r['v0_merged']['merged_denormalized_equals_campaign'].values()),
        'teacher_rollout_via_elastic_inputs_equals_v0_infer_action': all(x['bit_equal'] for x in r['v0_merged']['teacher_rollout_equals_v0_infer_action'].values()),
        'v0_unchanged_after_transport_wrapper': all(r['v0_merged']['v0_unchanged_after_transport'].values()),
        'e1_inputs_equal_v0_inputs': all(r['e1_merged']['inputs_equal_v0'].values()),
        'e1_rollouts_finite_deterministic_consistent': all(row['finite'] and row['deterministic'] and row['query_equals_normalized_infer']
            for s in r['e1_merged']['schedules'].values() for row in s['rows'].values()),
        'e1_cuda_graph_equals_eager': all(x['graph_equals_eager']['bit_equal'] and x['eager_equals_infer'] for v in r['e1_merged']['cuda_graph'].values() for x in v),
        'e1_pure_elastic_tree_equals_merged': all(x['bit_equal'] for x in r['e1_pure']['rows'].values())
            and '/LoopWAM-elastic-robotwin-2c78ff6/' in r['e1_pure']['module'],
    }
    if r['e1_merged'].get('teacher') and r['v0_campaign'].get('teacher'):    # gates of one student against its own teacher
        checks['student_and_v0_phases_use_the_same_teacher'] = r['e1_merged']['teacher'] == r['v0_campaign']['teacher']
    out = dict(passed=all(checks.values()), checks=checks, captures=sorted(r['v0_merged']['merged_equals_campaign']),
               schedules=list(SCHEDULES), graph_schedule=GRAPH_SCHEDULE,
               checkpoint=r['e1_merged'].get('checkpoint'), checkpoint_sha256=r['e1_merged'].get('checkpoint_sha256'),
               kind=r['e1_merged'].get('kind'), step=r['e1_merged'].get('step'),
               teacher=r['v0_campaign'].get('teacher'), teacher_sha256=r['v0_campaign'].get('teacher_sha256'),
               peak_gib={p: r[p].get('peak_gib') for p in r}, finished=time.time())
    (a.out / 'gates.json').write_text(json.dumps(out, indent=2)); print(json.dumps(out, indent=1))
    if not out['passed']: raise SystemExit('gate failure')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--phase', required=True, choices=['contexts', 'v0_campaign', 'v0_merged', 'e1_merged', 'e1_pure', 'summary'])
    p.add_argument('--tree'); p.add_argument('--merged-tree'); p.add_argument('--out', required=True)
    p.add_argument('--captures', nargs='*', default=[])
    p.add_argument('--teacher'); p.add_argument('--teacher-data-dir'); p.add_argument('--teacher-step', type=int, default=237310)
    p.add_argument('--e1'); p.add_argument('--e1-data-dir'); p.add_argument('--vae')
    p.add_argument('--e1-step', type=int, default=47462, help='export step of the elastic student under test (E1: 47462)')
    p.add_argument('--e1-kind', default='T1', help='transport kind of the elastic student under test (E1: T1)')
    a = p.parse_args(); a.out = Path(a.out); a.out.mkdir(parents=True, exist_ok=True)
    if a.phase == 'summary': return phase_summary(a)
    tree = setup_tree(a.tree)
    import torch
    captures = load_captures(a.captures)
    contexts = None if a.phase == 'contexts' else torch.load(a.out / 'contexts.pt')
    started = time.time()
    result = globals()[f'phase_{a.phase}'](a, captures, contexts) if a.phase != 'contexts' else phase_contexts(a, captures)
    result.update(phase=a.phase, tree=str(tree), seconds=time.time() - started, torch=torch.__version__,
                  gpu=torch.cuda.get_device_name(0), tf32_matmul=torch.backends.cuda.matmul.allow_tf32,
                  cudnn_tf32=torch.backends.cudnn.allow_tf32)
    (a.out / f'{a.phase}.json').write_text(json.dumps(result, indent=2, default=str))
    print(json.dumps({k: v for k, v in result.items() if k not in ('rows',)}, default=str)[:4000])


if __name__ == '__main__':
    main()
