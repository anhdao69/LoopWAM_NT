#!/usr/bin/env python3
"""RoboTwin evaluation of an elastic RT student export (e.g. RT50-ep5-E1) under the local v0 protocol.

Same queue, contract, retry and record verification as scripts/evaluate_loopwam_robotwin.py (whose helpers are
imported unchanged): seed 42, clean+randomized, accepted-scene walking from 100000*(1+seed), unseen instructions,
predict 32 / execute 24, fixed CPU noise per query, shared T5 server, videos + per-query action hashes, only complete
cells resumable. Differences: the deployed policy is experiments/robotwin/elastic_policy, the denoising schedule is
an explicit argument (NFE = schedule length) recorded in the contract, and the expected export step is the student's.
"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'scripts'));sys.path.insert(0,str(ROOT))
from fastwam.robotwin_pipeline import fingerprint_files,render_worker_environment
from evaluate_loopwam_robotwin import EPISODE,write,digest,completed_records,terminate
from experiments.robotwin.elastic_policy.deploy_policy import parse_schedule,load_header

POLICY='elastic_policy'

def validate_summary(summary,sha,tasks,settings,episodes):
    """The checks of fastwam.robotwin_pipeline's summary validator, for the requested settings (it hard-codes both)."""
    expected={f'{t}/{c}' for t in tasks for c in settings}
    if summary.get('checkpoint_sha256')!=sha or set(summary.get('finished',{}))!=expected:
        raise ValueError('Evaluation checkpoint or task coverage mismatch')
    for key,cell in summary['finished'].items():
        records=cell.get('episodes',[])
        if not cell.get('complete') or cell.get('exit_code')!=0 or len(records)!=episodes:
            raise ValueError(f'Incomplete evaluation: {key}')
        if len({r['seed'] for r in records})!=episodes:
            raise ValueError(f'Duplicate evaluation seeds: {key}')
        if any(type(r['success']) is not bool or r.get('video_verified') is not True for r in records):
            raise ValueError(f'Invalid outcome/video: {key}')

# GPU-memory faults in a worker log: OIDN reports OOM and SAPIEN keeps rendering without denoising (silently different
# observations), buffer allocation failures, CUDA OOM. Any of them rejects the attempt (retried), even with exit code 0.
RENDER_FAULTS=('OIDN Error','cannot create buffer','OutOfMemoryError','out of memory')

def render_faults(directory):
    text=(Path(directory)/'eval.log').read_text(errors='replace')
    return {m:text.count(m) for m in RENDER_FAULTS if m in text}

T5_SERVERS=dict(standard='experiments/robotwin/chronoloop_policy/t5_server.py',lean='experiments/robotwin/elastic_policy/t5_server_lean.py')

def campaign_cell_seconds(path):
    """Accepted-attempt seconds per task/setting of the v0 campaign (task_results.csv), used only to order the queue."""
    import csv
    return {f"{r['task']}/{r['setting']}":float(r['attempt_seconds']) for r in csv.DictReader(open(path))}

def gpu_free_mib(gpu):
    return int(subprocess.check_output(['nvidia-smi','-i',gpu,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())

def ram_available_mib():
    for line in open('/proc/meminfo'):
        if line.startswith('MemAvailable:'):return int(line.split()[1])//1024
    raise RuntimeError('MemAvailable missing')

def main():
    p=argparse.ArgumentParser()
    for name in ['checkpoint','robotwin-root','data-dir']:p.add_argument('--'+name,required=True)
    p.add_argument('--schedule',action='append',required=True,help='repeat with --output-dir for several evaluations, run in the given order')
    p.add_argument('--output-dir',action='append',required=True)
    p.add_argument('--gpus',default='0');p.add_argument('--per-gpu',type=int,default=1,help='workers per GPU (maximum when admission is on)')
    p.add_argument('--episodes',type=int,default=100);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--tasks');p.add_argument('--settings',default='demo_clean,demo_randomized')
    p.add_argument('--expected-step',type=int,default=47462);p.add_argument('--expected-kind')
    p.add_argument('--max-attempts',type=int,default=3);p.add_argument('--no-progress-timeout',type=int,default=1800)
    p.add_argument('--t5-loader',choices=['standard','lean'],default='standard',
        help='lean: elastic_policy/t5_server_lean.py (identical UMT5 weights without the ~34 GB host-RAM construction peak)')
    p.add_argument('--t5-gpu',help='GPU of the shared T5 server (default: first of --gpus)')
    # Scheduling only (never part of the evaluation contract; a cell is evaluated identically whatever its slot or order):
    p.add_argument('--order',choices=['given','campaign-longest-first'],default='given',
        help='campaign-longest-first: within each evaluation, start cells in decreasing v0-campaign duration (shorter tail)')
    p.add_argument('--campaign-results',help='v0 campaign task_results.csv (for --order campaign-longest-first)')
    p.add_argument('--admit-gpu-mib',type=int,default=0,help='start a worker only while its GPU has this much free memory, '
        'counting each worker started less than --admit-hold s ago as already using it (0: static slots)')
    p.add_argument('--gpu-floor-mib',type=int,default=0,help='GPU memory always left free (for other users) after admitting a worker')
    p.add_argument('--admit-ram-mib',type=int,default=0,help='same for host MemAvailable, per worker')
    p.add_argument('--ram-floor-mib',type=int,default=0,help='host MemAvailable always left after admitting a worker')
    p.add_argument('--admit-hold',type=int,default=300)
    a=p.parse_args()
    if len(a.schedule)!=len(a.output_dir):raise ValueError('Need one --output-dir per --schedule')
    if len({str(Path(x).resolve()) for x in a.output_dir})!=len(a.output_dir):raise ValueError('Output directories must differ')
    from fastwam.datasets.chronoloop_robot import ROBOTWIN50_TASKS
    tasks=list(ROBOTWIN50_TASKS) if not a.tasks else a.tasks.split(',')
    settings=a.settings.split(',')
    if len(set(tasks))!=len(tasks) or not set(tasks)<=set(ROBOTWIN50_TASKS):raise ValueError('Invalid tasks')
    if len(set(settings))!=len(settings) or not set(settings)<={'demo_clean','demo_randomized'}:raise ValueError('Invalid settings')
    header=load_header(a.checkpoint)
    if header['step']!=a.expected_step:raise ValueError('Wrong export step')
    if a.expected_kind and header['kind']!=a.expected_kind:raise ValueError('Wrong export transport kind')
    schedules=[(name,parse_schedule(name)) for name in a.schedule]
    cell_seconds=campaign_cell_seconds(a.campaign_results) if a.order=='campaign-longest-first' else None
    sha=digest(a.checkpoint)
    gpus=a.gpus.split(',');gpu_pci={}
    if os.environ.get('LOOPWAM_VULKAN_DEVICE_SELECT')=='1':
        for gpu in gpus:
            gpu_pci[gpu]=subprocess.check_output(['nvidia-smi','-i',gpu,'--query-gpu=pci.bus_id','--format=csv,noheader'],text=True).strip()
    robotwin=Path(a.robotwin_root);policy=(robotwin/'policy'/POLICY).resolve()
    if policy!=(ROOT/'experiments/robotwin'/POLICY).resolve():raise ValueError('Wrong deployed policy import target')
    loopwam=ROOT/'experiments/robotwin/loopwam_policy'
    bound=list((robotwin/'envs').rglob('*.py'))+list((robotwin/'task_config').rglob('*.yml'))+list(policy.glob('*.py'))+list(policy.glob('*.yml'))+list((ROOT/'src/fastwam/models/wan22').rglob('*.py'))
    bound += list((ROOT/'src/fastwam').rglob('*.py'))+list((robotwin/'description').rglob('*.py'))+list((robotwin/'description').rglob('*.json'))
    bound += list((ROOT/'experiments/robotwin/chronoloop_policy').glob('*.py'))+list(loopwam.glob('*.py'))+[Path(__file__),ROOT/'scripts/evaluate_loopwam_robotwin.py',robotwin/'script/eval_policy.py']
    bound += list((ROOT/'checkpoints/Wan-AI/Wan2.1-T2V-1.3B/google').rglob('*'))
    bound=[x for x in bound if x.is_file()]
    extra=os.environ.get('LOOPWAM_RUNTIME_MANIFEST')
    if extra:bound.append(Path(extra))
    runtime_hashes=fingerprint_files(bound)
    common=dict(harness_sha256=digest(robotwin/'script/eval_policy.py'),policy=POLICY,
        policy_sha256=digest(ROOT/'experiments/robotwin'/POLICY/'deploy_policy.py'),
        stats_sha256=digest(Path(a.data_dir)/'dataset_stats.json'),runtime_hashes=runtime_hashes,
        vae_sha256=digest(ROOT/'checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth'))
    runs=[];pending=[]
    for index,((schedule,depths),output) in enumerate(zip(schedules,a.output_dir)):
        out=Path(output);out.mkdir(parents=True,exist_ok=True)
        lock=(out/'runner.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        protocol=dict(checkpoint=str(Path(a.checkpoint).resolve()),checkpoint_sha256=sha,expected_step=a.expected_step,
            model_format='loopwam-s-robot-rt-v1',transport_kind=header['kind'],trained_schedules=header['schedules'],
            schedule=schedule,depths=list(depths),schedule_trained=schedule in header['schedules'],
            tasks=tasks,settings=settings,episodes=a.episodes,seed=a.seed,instruction_type='unseen',
            num_inference_steps=len(depths),action_horizon=32,replan_steps=24,noise_seed='fixed seed for every query, FastWAM default',
            image_preprocessing='released_fastwam_pil_uint8_bf16',instruction_rng='released_fastwam_no_explicit_python_seed',
            t5_loader=a.t5_loader,t5_server=T5_SERVERS[a.t5_loader],
            cuda_graph=os.environ.get('LOOPWAM_CUDA_GRAPH','0'),renderer_shader=os.environ.get('LOOPWAM_ROBOTWIN_SHADER','rt'),gpu_pci=gpu_pci,
            **common)
        manifest=out/'manifest.json'
        if manifest.exists() and json.loads(manifest.read_text())!=protocol:raise ValueError(f'Cannot reuse different evaluation contract: {out}')
        write(manifest,protocol)
        write(out/f'launch_{time.time_ns()}.json',dict(argv=sys.argv,pid=os.getpid(),started=time.time(),run_index=index,
            runs=[dict(schedule=n,output_dir=str(o)) for (n,_),o in zip(schedules,a.output_dir)],gpus=gpus,per_gpu=a.per_gpu,
            order=a.order,admit_gpu_mib=a.admit_gpu_mib,gpu_floor_mib=a.gpu_floor_mib,admit_ram_mib=a.admit_ram_mib,ram_floor_mib=a.ram_floor_mib,admit_hold=a.admit_hold,
            max_attempts=a.max_attempts,no_progress_timeout=a.no_progress_timeout))
        run=dict(schedule=schedule,depths=depths,out=out,lock=lock,finished={},attempts={},failed=[],done=False)
        cells=[(task,config) for task in tasks for config in settings]
        if cell_seconds is not None:cells.sort(key=lambda x:-cell_seconds[f'{x[0]}/{x[1]}'])
        for task,config in cells:
            key=f'{task}/{config}';cell=out/f'{task}__{config}';cell.mkdir(exist_ok=True)
            result=cell/'result.json'
            if result.exists():
                old=json.loads(result.read_text());d=Path(old['directory'])
                if old['checkpoint_sha256']!=sha:raise ValueError('Mismatched cell checkpoint')
                if old.get('schedule')!=schedule:raise ValueError(f'Mismatched cell schedule {key}')
                if render_faults(d):raise ValueError(f'Render/GPU-memory fault in accepted cell {key}: {render_faults(d)}')
                records=completed_records(d,config,a.episodes)
                if records!=old['episodes']:raise ValueError('Cell records changed')
                run['finished'][key]=old;continue
            run['attempts'][key]=len(list(cell.glob('attempt_*')));pending.append((index,task,config))
        runs.append(run)
    def run_summary(index,running):
        run=runs[index]
        return dict(checkpoint_sha256=sha,schedule=run['schedule'],finished=run['finished'],
            running={f'{s["task"]}/{s["config"]}':dict(episodes=s['episodes'],started=s['started'],gpu=s['gpu']) for s in running.values() if s['index']==index},
            failed=run['failed'],pending=sum(e[0]==index for e in pending),updated=time.time())
    def finish(index,running):
        """Write COMPLETE.json of an evaluation once none of its cells is pending or running (and none failed)."""
        run=runs[index]
        if run['done'] or any(e[0]==index for e in pending) or any(s['index']==index for s in running.values()):return
        run['done']=True;summary=run_summary(index,running);write(run['out']/'summary.json',summary)
        if run['failed']:return
        validate_summary(summary,sha,tasks,settings,a.episodes)
        summary['success_rates']={c:sum(v['successes'] for v in run['finished'].values() if v['config']==c)/(len(tasks)*a.episodes) for c in settings}
        write(run['out']/'COMPLETE.json',summary)
    for index in range(len(runs)):finish(index,{})
    if not pending:return
    env=dict(os.environ);env.update(PYTHONUNBUFFERED='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
    slots=[g for _ in range(a.per_gpu) for g in gpus]
    sock=f'/tmp/loopwam_t5_{os.getpid()}.sock'
    server_log=(runs[0]['out']/f't5_{time.time_ns()}.log').open('w')
    server=subprocess.Popen([sys.executable,str(ROOT/T5_SERVERS[a.t5_loader]),'--address',sock],env={**env,'CUDA_VISIBLE_DEVICES':a.t5_gpu or gpus[0]},stdout=server_log,stderr=subprocess.STDOUT,start_new_session=True)
    running={}
    def stop_signal(*_):raise KeyboardInterrupt
    signal.signal(signal.SIGTERM,stop_signal)
    def admitted(gpu):
        if not (a.admit_gpu_mib or a.admit_ram_mib):return True
        recent=[s for s in running.values() if time.time()-s['started']<a.admit_hold]
        if a.admit_gpu_mib and gpu_free_mib(gpu)-a.admit_gpu_mib*sum(s['gpu']==gpu for s in recent)<a.admit_gpu_mib+a.gpu_floor_mib:return False
        if a.admit_ram_mib and ram_available_mib()-a.admit_ram_mib*len(recent)<a.admit_ram_mib+a.ram_floor_mib:return False
        return True
    try:
        start=time.time()
        while not Path(sock).exists():
            if server.poll() is not None or time.time()-start>600:raise RuntimeError('T5 startup failed/timed out')
            time.sleep(2)
        while pending or running:
            if server.poll() is not None:raise RuntimeError('Shared T5 server exited')
            for slot,gpu in enumerate(slots):
                if slot in running or not pending or not admitted(gpu):continue
                index,task,config=pending.pop(0);run=runs[index];key=f'{task}/{config}';run['attempts'][key]+=1
                if run['attempts'][key]>a.max_attempts:run['failed'].append(key);finish(index,running);continue
                d=run['out']/f'{task}__{config}'/f'attempt_{run["attempts"][key]:02d}';d.mkdir()
                cmd=[sys.executable,'script/eval_policy.py','--config',f'policy/{POLICY}/deploy_policy.yml','--overrides',
                    '--task_name',task,'--task_config',config,'--ckpt_setting',str(Path(a.checkpoint).resolve()),
                    '--seed',str(a.seed),'--eval_num_episodes',str(a.episodes),'--instruction_pool',str(a.episodes),
                    '--eval_output_dir',str(d),'--data_dir',a.data_dir,'--t5_server',sock,
                    '--expected_step',str(a.expected_step),'--expected_kind',str(a.expected_kind),
                    '--schedule',run['schedule'],'--num_inference_steps',str(len(run['depths']))]
                write(d/'command.json',cmd);log=(d/'eval.log').open('w')
                worker_env=render_worker_environment(env,gpu,gpu_pci[gpu]) if gpu_pci else {**env,'CUDA_VISIBLE_DEVICES':gpu}
                proc=subprocess.Popen(cmd,cwd=a.robotwin_root,env=worker_env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                running[slot]=dict(proc=proc,index=index,task=task,config=config,d=d,log=log,gpu=gpu,started=time.time(),progress=time.time(),episodes=0)
            for slot,s in list(running.items()):
                text=(s['d']/'eval.log').read_text(errors='replace');count=len(EPISODE.findall(text))
                if count>s['episodes']:s['episodes']=count;s['progress']=time.time()
                if time.time()-s['progress']>a.no_progress_timeout:terminate(s['proc'])
                rc=s['proc'].poll()
                if rc is None:continue
                run=runs[s['index']];key=f'{s["task"]}/{s["config"]}';s['log'].close()
                try:
                    if rc!=0:raise RuntimeError(f'Worker exit{rc}')
                    faults=render_faults(s['d'])
                    if faults:raise RuntimeError(f'Render/GPU-memory fault in worker log: {faults}')
                    records=completed_records(s['d'],s['config'],a.episodes)
                    cell=dict(complete=True,exit_code=0,checkpoint_sha256=sha,task=s['task'],config=s['config'],episodes=records,
                        successes=sum(x['success'] for x in records),directory=str(s['d']),seconds=time.time()-s['started'],schedule=run['schedule'],gpu=s['gpu'])
                    write(s['d'].parent/'result.json',cell);run['finished'][key]=cell
                except Exception as e:
                    write(s['d']/'failure.json',dict(error=str(e),exit_code=rc,episodes=count))
                    # retry first among the remaining cells of the same evaluation (evaluations stay in order)
                    pending.insert(sum(x[0]<s['index'] for x in pending),(s['index'],s['task'],s['config']))
                del running[slot]
                finish(s['index'],running)
            for index,run in enumerate(runs):
                if not run['done']:write(run['out']/'summary.json',run_summary(index,running))
            time.sleep(5)
        failed=[f'{run["schedule"]}:{key}' for run in runs for key in run['failed']]
        if failed:raise RuntimeError(f'Failed evaluation cells:{failed}')
    finally:
        for s in running.values():terminate(s['proc']);s['log'].close()
        terminate(server);server_log.close()

if __name__=='__main__':main()
