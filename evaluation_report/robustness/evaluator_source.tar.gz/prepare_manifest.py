"""Build immutable plans using the installed official benchmark APIs."""
import argparse,contextlib,io,json,subprocess,sys,hashlib
from pathlib import Path
from types import SimpleNamespace
from protocol import *

def build(kind):
 import numpy as np,torch
 if kind=='plus':
  from libero.libero import benchmark,get_libero_path
 else:
  from liberopro.liberopro import benchmark,get_libero_path
  from liberopro.liberopro.envs.bddl_utils import get_problem_info
 root=Path(get_libero_path('benchmark_root'))
 if root.resolve()!= (REPOS[kind]/('libero/libero' if kind=='plus' else 'liberopro/liberopro')).resolve():raise ValueError('Wrong benchmark imported')
 categories={}
 if kind=='plus':
  for suite,rows in json.loads((root/'benchmark/task_classification.json').read_text()).items():
   for row in rows:categories[(suite,row['name'])]=row
 captured=[]
 def load(path):
  captured.append(str(Path(path).resolve()));return torch.load(path,weights_only=False)
 benchmark.torch=SimpleNamespace(load=load)
 groups=[];totals={}
 for base in SUITES:
  for dimension in (['plus'] if kind=='plus' else ['swap','task']):
   name=base if kind=='plus' else base+'_'+dimension
   with contextlib.redirect_stdout(io.StringIO()):suite=benchmark.get_benchmark_dict()[name if kind=='plus' else base]()
   count=suite.n_tasks
   if kind=='plus' and count<2000:raise ValueError('Not Plus task catalogue')
   if kind=='pro' and count!=10:raise ValueError('PRO requires 10 tasks/suite/dimension')
   totals[name]=count
   ids=sample_ids(name,count) if kind=='plus' else list(range(count))
   for index in ids:
    t=suite.get_task(index);captured.clear()
    if kind=='plus':states=suite.get_task_init_states(index)
    else:states=load(root/'init_files'/name/t.init_states_file)
    episodes=1 if kind=='plus' else 10
    if len(states)<episodes or not np.isfinite(np.asarray(states)).all():raise ValueError('Invalid states')
    bddl=root/'bddl_files'/(t.problem_folder if kind=='plus' else name)/t.bddl_file
    physical=bddl.with_name(bddl.name.split('_view_')[0]+'.bddl') if '_view_' in bddl.name else bddl
    if not physical.is_file():raise ValueError('Missing BDDL '+str(physical))
    g=dict(id=f'{name}__{index:04d}__seed42',benchmark=kind,suite=name,base_suite=base,task=index,task_name=t.name,description=instruction_for(kind,dimension,t.language,get_problem_info(str(physical))['language_instruction'] if kind=='pro' else t.language),catalogue_language=t.language,
      seed=42,episodes=episodes,max_steps=((700 if base=='libero_10' else 400) if kind=='plus' else {'libero_spatial':220,'libero_object':280,'libero_goal':300,'libero_10':520}[base]),bddl=str(bddl),physical_bddl=str(physical),bddl_sha256=sha(physical),
      initial_states_file=captured[-1],initial_states_sha256=sha(captured[-1]),available_states=len(states),
      selected_state_hashes=[hashlib.sha256(np.asarray(states[i]).tobytes()).hexdigest() for i in range(episodes)],
      category=categories[(base,t.name)]['category'] if kind=='plus' else ('Position' if dimension=='swap' else 'Task'),
      difficulty=categories[(base,t.name)].get('difficulty_level') if kind=='plus' else None)
    groups.append(g)
 meta=dict(benchmark=kind,seed=42,task_sample_ratio=.15 if kind=='plus' else 1,task_sample_seed=42,
  total_catalogue_tasks=totals,selected_tasks=len(groups),planned_episodes=sum(g['episodes'] for g in groups),groups=groups,
  source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPOS[kind],text=True).strip(),
  fasterwam_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=FASTER,text=True).strip(),
  fasterwam_config_sha256=sha(FASTER/'configs/sim_libero_plus.yaml'),fasterwam_sampler_sha256=sha(FASTER/'experiments/libero/run_libero_manager.py'),
  max_steps_basis='Plus: FasterWAM 400/400/400/700. Pro: official README 220/280/300/520 for Spatial/Object/Goal/Long',
  language_basis=('Official benchmark Task.language, exactly as FasterWAM get_libero_env; no stripping or rewriting' if kind=='plus' else 'Position preserves original catalogue instruction (no semantic perturbation); Task uses perturbed BDDL language_instruction for the changed goal'),
  seed_rule='42 once per task group and env.seed(42); query seed42; no episode reseeding',
  perturbation_rule='Official native wrappers, unmodified; Pro separate Position(_swap) and Task(_task)')
 path=ROOT/f'{kind}_tasks.json'
 if path.exists() and json.loads(path.read_text())!=meta:raise ValueError('Refusing to replace differing frozen plan')
 write(path,meta);write(REPORT/path.name,meta)
 print(json.dumps({k:v for k,v in meta.items() if k!='groups'},indent=2))
if __name__=='__main__':build(sys.argv[1])
