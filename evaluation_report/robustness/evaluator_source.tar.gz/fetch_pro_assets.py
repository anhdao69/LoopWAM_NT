import concurrent.futures,hashlib,json,subprocess
from pathlib import Path
from protocol import *
hub=json.load(open('/tmp/libero-pro-hf.json'));revision=hub['sha'];root=REPOS['pro']/'liberopro/liberopro'
files=[x for x in hub['siblings'] if any(f'/{base}_{kind}/' in x['rfilename'] for base in SUITES for kind in ('swap','task'))]
def fetch(item):
 path=root/item['rfilename'];path.parent.mkdir(parents=True,exist_ok=True)
 def valid():
  if not path.exists():return False
  data=path.read_bytes()
  return len(data)==item['size'] and hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==item['blobId']
 if not valid():
  temp=path.with_suffix(path.suffix+'.part')
  subprocess.run(['curl','-q','--fail','--silent','--show-error','--location','--retry','3','--max-time','90',f'https://huggingface.co/datasets/zhouxueyang/LIBERO-Pro/resolve/{revision}/{item["rfilename"]}','-o',str(temp)],check=True)
  temp.replace(path)
 if not valid():raise ValueError('HF git blob identity mismatch: '+str(path))
 return dict(path=str(path),sha256=sha(path),git_blob=item['blobId'],size=item['size'])
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:receipts=list(pool.map(fetch,files))
write(ROOT/'pro_assets_receipt.json',dict(repo='zhouxueyang/LIBERO-Pro',revision=revision,files=receipts));print('Verified',len(receipts),'official assets')
