"""Frozen benchmark planning and strict episode accounting for CL robustness."""
import hashlib,json,math,os,random
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPORT=Path('/storage/anhdh35/LoopWAM_NT/evaluation_report/robustness')
BULK=Path('/data14t/anhdh35/loopwam_robustness')
SUITES=['libero_10','libero_goal','libero_spatial','libero_object']
REPOS={'plus':Path('/storage/anhdh35/LIBERO-plus-eval'),'pro':Path('/storage/anhdh35/LIBERO-PRO-eval')}
FASTER=Path('/storage/anhdh35/FasterWAM-protocol')
CAMPAIGN=Path('/storage/anhdh35/LoopWAM-campaign-eval')
PYTHON='/storage/anhdh35/miniconda3/envs/loopwam-libero-eval/bin/python'
STATS='/storage/anhdh35/LoopWAM_NT-eval/checkpoints/release/libero-all-suites/v0-video4-action4/dataset_stats.json'

def write(path,data):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 temp=path.with_name(path.name+f'.{os.getpid()}.tmp');temp.write_text(json.dumps(data,indent=2)+'\n');temp.replace(path)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
def sample_ids(suite,count):
 return sorted(random.Random(f'42:{suite}').sample(list(range(count)),max(1,math.ceil(count*.15))))
def verify_rows(groups,rows,digest,*,videos=False):
 expected={(g['id'],e):g for g in groups for e in range(g['episodes'])}
 seen=set()
 for row in rows:
  key=(row['id'],row['episode'])
  if key not in expected or key in seen:raise ValueError('Unexpected/duplicate episode '+str(key))
  seen.add(key);g=expected[key]
  if row['seed']!=42 or row['initial_state_index']!=row['episode'] or row['checkpoint_sha256']!=digest:raise ValueError('Episode identity mismatch')
  if type(row['success']) is not bool or not 1<=row['policy_steps']<=g['max_steps'] or row['queries']!=math.ceil(row['policy_steps']/10):raise ValueError('Invalid result/cap/query count')
  if videos and (not Path(row['video']).is_file() or Path(row['video']).stat().st_size==0 or sha(row['video'])!=row['video_sha256']):raise ValueError('Missing/corrupt video')
 if seen!=set(expected):raise ValueError('Missing episodes')
 return dict(episodes=len(rows),successes=sum(r['success'] for r in rows),success_rate=sum(r['success'] for r in rows)/len(rows) if rows else None)
def recover_groups(out,groups,digest):
 recovered={}
 for g in groups:
  path=Path(out)/'groups'/f"{g['id']}.json"
  if path.exists():
   rows=json.loads(path.read_text());verify_rows([g],rows,digest,videos=True);recovered[g['id']]=rows
 return recovered

def environment(kind):
 env=os.environ.copy();repo=REPOS[kind]
 env.update(PYTHONPATH=f'{ROOT}/python_deps:{repo}:/storage/anhdh35/ChronoLoop-eval/src:/storage/anhdh35/ChronoLoop-eval:/storage/anhdh35/Light-WAM/src:/storage/anhdh35/Light-WAM:{CAMPAIGN}:{ROOT}',
 LIBERO_CONFIG_PATH=str(ROOT/'config'/kind),DIFFSYNTH_MODEL_BASE_PATH='/storage/anhdh35/Light-WAM/checkpoints',
 MUJOCO_GL='egl',PYOPENGL_PLATFORM='egl',CUDA_VISIBLE_DEVICES='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',NUMBA_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false',PYTHONNOUSERSITE='1',PYTHONUNBUFFERED='1',TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD='1',TQDM_DISABLE='1',
 LD_LIBRARY_PATH=f'{ROOT}/system_deps/usr/lib/x86_64-linux-gnu:'+env.get('LD_LIBRARY_PATH',''),MAGICK_CODER_MODULE_PATH=str(ROOT/'system_deps/usr/lib/x86_64-linux-gnu/ImageMagick-6.9.11/modules-Q16/coders'),MAGICK_HOME=str(ROOT/'system_deps/usr'),MAGICK_CONFIGURE_PATH=str(ROOT/'system_deps/etc/ImageMagick-6'))
 if kind=='pro':env['PYTHONPATH']+=':/storage/anhdh35/Light-WAM/third_party/LIBERO'
 return env

def instruction_for(benchmark,dimension,catalogue_language,bddl_language):
 if benchmark=='plus' or dimension=='swap':return catalogue_language
 if benchmark=='pro' and dimension=='task':return bddl_language
 raise ValueError('Unsupported instruction routing')
