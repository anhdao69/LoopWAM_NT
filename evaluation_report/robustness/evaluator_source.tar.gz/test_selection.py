import unittest,importlib.util
class SelectionTest(unittest.TestCase):
 def test_faster_mismatching_profile_is_rejected(self):
  self.assertIsNotNone(importlib.util.find_spec('queue_run'),'Queue not implemented')
  from queue_run import choose_profile
  profiles=[dict(workers=4,seconds=20,signature='same'),dict(workers=8,seconds=11,signature='same'),dict(workers=12,seconds=9,signature='different')]
  self.assertEqual(choose_profile(profiles)['workers'],8)
 def test_missing_reference_cannot_launch(self):
  self.assertIsNotNone(importlib.util.find_spec('queue_run'),'Queue not implemented')
  from queue_run import choose_profile
  with self.assertRaises(ValueError):choose_profile([dict(workers=8,seconds=2,signature='x')])
if __name__=='__main__':unittest.main()
