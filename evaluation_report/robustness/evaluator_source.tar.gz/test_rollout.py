import unittest,importlib.util
from types import SimpleNamespace
import numpy as np
from omegaconf import OmegaConf
class RolloutTest(unittest.TestCase):
 def test_uses_official_settling_and_ten_action_execution(self):
  self.assertIsNotNone(importlib.util.find_spec('reference'),'Reference loader missing')
  from reference import load_reference
  ref=load_reference();calls=[]
  ref['get_libero_image']=lambda obs:obs
  def predict(**kw):
   calls.append(kw['obs']['step']);return np.zeros((32,7)),kw['obs'],None
  ref['_predict_action_chunk']=predict
  class Env:
   def reset(self):self.steps=0
   def set_init_state(self,state):return dict(step=self.steps)
   def step(self,a):
    self.steps+=1
    if self.steps<=30:np.testing.assert_array_equal(a,[0,0,0,0,0,0,-1])
    return dict(step=self.steps),0,self.steps==41,{}
  cfg=OmegaConf.create(dict(data=dict(train=dict(action_video_freq_ratio=4)),EVALUATION=dict(task_suite_name='libero_spatial',num_steps_wait=30,replan_steps=10,use_action_ensembler=False,visualize_future_video=False)))
  ok,frames,_,_=ref['run_single_episode'](Env(),None,'test',None,None,cfg,0,action_horizon=32,input_w=448,input_h=224,model_device='cuda:0')
  self.assertTrue(ok);self.assertEqual(len(frames),11);self.assertEqual(calls,[30,40])
if __name__=='__main__':unittest.main()
