"""Persistent serial CL robustness queue; native worker-count parity gates."""
import argparse,fcntl,hashlib,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
from protocol import *

def choose_profile(profiles):
 baseline=next((p for p in profiles if p['workers']==4 and 'signature' in p),None)
 if baseline is None:raise ValueError('A complete four-worker native reference is required')
 eligible=[p for p in profiles if p.get('signature')==baseline['signature'] and p.get('seconds',0)>0]
 if not eligible:raise ValueError('No validated profile')
 return min(eligible,key=lambda p:p['seconds'])

def profile(out):
 manifest=json.loads((out/'manifest.json').read_text());summary=json.loads((out/'summary.json').read_text())
 rows=[r for p in sorted((out/'groups').glob('*.json')) for r in json.loads(p.read_text())]
 verify_rows(manifest['protocol']['groups'],rows,summary['checkpoint_sha256'],videos=True)
 sig=[]
 for r in sorted(rows,key=lambda x:(x['id'],x['episode'])):
  queries=json.loads(Path(r['query_log']).read_text())
  if sha(r['query_log'])!=r['query_log_sha256']:raise ValueError('Query audit mismatch')
  sig.append((r['id'],r['episode'],r['success'],r['policy_steps'],r['queries'],[q['action_sha256'] for q in queries]))
 resources=json.loads((out/'runtime_resources.json').read_text()) if (out/'runtime_resources.json').exists() else {}
 return dict(resources=resources,workers=summary['workers'],seconds=summary['scored_wall_seconds'],signature=hashlib.sha256(json.dumps(sig).encode()).hexdigest(),output=str(out),summary=summary)

def refresh(state):
 state['updated_unix']=time.time();write(ROOT/'queue_state.json',state);write(REPORT/'queue_status.json',state)
 from report import generate
 generate(state)

def execute(job,output,workers,calibration,state):
 output=Path(output);output.mkdir(parents=True,exist_ok=True)
 if (output/'summary.json').exists():return profile(output)
 cmd=[PYTHON,str(ROOT/'runner.py'),'--benchmark',job['benchmark'],'--checkpoint',job['checkpoint'],'--checkpoint-sha256',job['checkpoint_sha256'],'--output',str(output),'--workers',str(workers)]
 if calibration:cmd.append('--calibration')
 with (output/'run.log').open('a') as f:
  child=subprocess.Popen(cmd,env=environment(job['benchmark']),stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 state['active']=dict(job=job['id'],stage='calibration' if calibration else 'scored',workers=workers,pid=child.pid,output=str(output),started_unix=time.time())
 refresh(state)
 resources=dict(max_worker_gpu_mib=0,max_total_gpu_mib=0)
 try:
  while child.poll() is None:
   try:
    gpu=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader,nounits'],text=True)
    total=0
    for line in gpu.splitlines():
     pid,mem=map(int,line.split(','));total+=mem
     try:
      if os.getsid(pid)==child.pid:resources['max_worker_gpu_mib']=max(resources['max_worker_gpu_mib'],mem)
     except ProcessLookupError:pass
    resources['max_total_gpu_mib']=max(resources['max_total_gpu_mib'],total)
    write(output/'runtime_resources.json',resources)
   except (subprocess.SubprocessError,ValueError):pass
   progress=output/'progress.json'
   if progress.exists():state['active']['progress']=json.loads(progress.read_text())
   refresh(state);time.sleep(10)
  if child.returncode:raise RuntimeError(f'Runner exit {child.returncode}; see {output}/error.json and run.log')
  return profile(output)
 except BaseException:
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  if child.poll() is None:child.wait(timeout=60)
  raise

def main():
 lock=(ROOT/'queue.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=json.loads((ROOT/'queue_state.json').read_text()) if (ROOT/'queue_state.json').exists() else dict(jobs=json.loads((ROOT/'queue_plan.json').read_text())['jobs'],active=None,started_unix=time.time())
 # Prevent duplicate workers after a controller crash. Fail closed; operator can reconcile.
 for proc in Path('/proc').iterdir():
  try:
   if str(ROOT/'runner.py').encode() in (proc/'cmdline').read_bytes().split(b'\0'):raise RuntimeError('An unmanaged robustness runner is already alive')
  except (FileNotFoundError,PermissionError,NotADirectoryError):pass
 for kind in ['plus','pro']:
  audit=json.loads((ROOT/f'{kind}_simulator_audit.json').read_text())
  if not audit['passed'] or audit['plan_sha256']!=sha(ROOT/f'{kind}_tasks.json'):raise ValueError('Simulator audit must pass before queue launch')
 for job in state['jobs']:
  if job['status']=='complete':
   p=profile(Path(job['output']))
   if p['summary']['episodes']!=job['expected_episodes']:raise ValueError('Incomplete completed job')
   continue
  job['status']='calibrating';job['started_unix']=time.time();refresh(state)
  try:
   profiles=[]
   for workers in [4,8,12]:
    if workers>4 and profiles:
     peak=max((x.get('resources',{}).get('max_worker_gpu_mib',0) for x in profiles),default=0)
     free=int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
     if peak and workers*peak*1.12+2048>free:
      profiles.append(dict(workers=workers,skipped='Insufficient free VRAM with 12% worker headroom and2GiB reserve',free_mib=free,observed_worker_peak_mib=peak));continue
    out=BULK/'calibration'/job['benchmark']/job['model'].replace('@','-at')/f'workers{workers}'
    try:profiles.append(execute(job,out,workers,True,state))
    except Exception:
     profiles.append(dict(workers=workers,error=traceback.format_exc()))
     if workers==4:raise
    job['calibration_profiles']=profiles;refresh(state)
   selected=choose_profile(profiles);job['selected_workers']=selected['workers'];job['status']='running'
   write(Path(job['output'])/'speed_selection.json',dict(profiles=profiles,selected=selected,rule='Fastest scored wall time among profiles with identical outcome, steps, query counts, and every action hash to native four-worker reference',limits='Finite calibration; no precision, inference algorithm, or denoising changes'))
   result=execute(job,job['output'],selected['workers'],False,state)
   if result['summary']['episodes']!=job['expected_episodes']:raise ValueError('Scored total differs from plan')
   job.update(status='complete',summary=result['summary'],finished_unix=time.time())
  except Exception:job.update(status='error',error=traceback.format_exc(),finished_unix=time.time())
  state['active']=None;refresh(state)
 state['finished_unix']=time.time();refresh(state)
 # Resume prior idle discovery controller if this campaign suspended it.
 if (ROOT/'prior_controller_suspended.json').exists():
  if subprocess.run(['tmux','has-session','-t','loopwam_campaign'],capture_output=True).returncode:
   subprocess.run(['tmux','new-session','-d','-s','loopwam_campaign','-c',str(CAMPAIGN),f'exec {PYTHON} -u campaign_watch.py >> campaign_watch.log 2>&1'],check=True)
  write(ROOT/'prior_controller_restored.json',dict(time=time.time()))
if __name__=='__main__':main()
