"""Exercise every selected task's native environment and official initial state."""
import concurrent.futures,contextlib,hashlib,io,json,multiprocessing,sys,time,traceback
from protocol import *
def audit(g):
 import numpy as np,torch,random
 if g['benchmark']=='plus':
  from libero.libero.envs import OffScreenRenderEnv
 else:
  from liberopro.liberopro.envs import OffScreenRenderEnv
 torch.set_num_threads(1);random.seed(42);np.random.seed(42)
 try:
  with contextlib.redirect_stdout(io.StringIO()):
   env=OffScreenRenderEnv(bddl_file_name=g['bddl'],camera_heights=256,camera_widths=256);env.seed(42)
   try:
    states=torch.load(g['initial_states_file'],weights_only=False)
    if g['available_states']==1 and np.asarray(states).ndim==1:states=np.asarray(states).reshape(1,-1)
    env.reset();obs=env.set_init_state(states[0])
    obs,_,_,_=env.step([0,0,0,0,0,0,-1])
    for key in ['agentview_image','robot0_eye_in_hand_image']:
     if obs[key].shape!=(256,256,3) or not np.isfinite(obs[key]).all():raise ValueError('Bad observation '+key)
    return dict(id=g['id'],ok=True,category=g['category'],render_shape=list(obs['agentview_image'].shape))
   finally:env.close()
 except BaseException:return dict(id=g['id'],ok=False,error=traceback.format_exc())
if __name__=='__main__':
 kind=sys.argv[1];plan=json.loads((ROOT/f'{kind}_tasks.json').read_text());groups=plan['groups'];started=time.time()
 # Exhaustive environment construction validates selected assets before GPU scoring.
 with concurrent.futures.ProcessPoolExecutor(max_workers=8,mp_context=multiprocessing.get_context('spawn')) as pool:
  rows=[]
  for row in pool.map(audit,groups):
   rows.append(row)
   if not row['ok']:print(json.dumps(row),flush=True)
   if len(rows)%50==0:print('Audited',len(rows),'/',len(groups),flush=True)
 result=dict(benchmark=kind,plan_sha256=sha(ROOT/f'{kind}_tasks.json'),rows=rows,passed=all(r['ok'] for r in rows),elapsed_seconds=time.time()-started)
 write(ROOT/f'{kind}_simulator_audit.json',result);write(REPORT/f'{kind}_simulator_audit.json',result)
 if not result['passed']:sys.exit(1)
