"""Final Pro smoke, then persistent queue; isolate from prior idle campaign."""
import json,os,signal,subprocess,time,traceback
from protocol import *
from queue_run import profile
from report import generate
try:
 for kind in ['plus','pro']:
  until=time.time()+300
  while True:
   p=ROOT/f'{kind}_simulator_audit.json'
   audit=json.loads(p.read_text()) if p.exists() else {}
   if audit.get('passed') and audit.get('plan_sha256')==sha(ROOT/f'{kind}_tasks.json'):break
   if time.time()>until:raise RuntimeError('Simulator audit incomplete/mismatched: '+kind)
   time.sleep(5)
 state=json.loads((ROOT/'queue_state.json').read_text())
 job=state['jobs'][7];out=BULK/'smoke/pro_CL-0_final';out.mkdir(parents=True,exist_ok=True)
 state['active']=dict(stage='final_pro_smoke',output=str(out));write(ROOT/'queue_state.json',state);write(REPORT/'queue_status.json',state);generate(state)
 cmd=[PYTHON,str(ROOT/'runner.py'),'--benchmark','pro','--checkpoint',job['checkpoint'],'--checkpoint-sha256',job['checkpoint_sha256'],'--output',str(out),'--workers','2','--calibration']
 if not (out/'summary.json').exists():
  with (out/'run.log').open('a') as f:subprocess.run(cmd,env=environment('pro'),stdout=f,stderr=subprocess.STDOUT,check=True)
 result=profile(out)
 if result['summary']['episodes']!=8:raise RuntimeError('Final Pro smoke incomplete')
 write(REPORT/'final_pro_smoke.json',result)
 # All existing available standard LIBERO jobs are done. Suspend only its idle controller.
 prior=json.loads((CAMPAIGN/'queue_state.json').read_text())
 if prior.get('active') is not None:raise RuntimeError('Prior campaign has an active job; defer robustness launch')
 watcher=prior.get('watcher',{});pid=watcher.get('pid')
 if pid and Path(f'/proc/{pid}/cmdline').exists():
  argv=Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
  if not any(x.endswith(b'campaign_watch.py') for x in argv):raise RuntimeError('Prior watcher PID identity mismatch')
  import sys
  sys.path.insert(0,str(CAMPAIGN))
  from queue_state import process_matches
  if not process_matches(pid,watcher['identity']):raise RuntimeError('Prior watcher PID reused')
  write(ROOT/'prior_controller_suspended.json',dict(watcher=watcher,time=time.time(),reason='Serialize GPU campaigns for requested CL Plus/Pro queue; resume after queue completes',original_queue_enabled=prior.get('queue_enabled'),original_discovery_enabled=prior.get('discovery_enabled')))
  os.kill(pid,signal.SIGTERM)
  for _ in range(30):
   if not process_matches(pid,watcher['identity']):break
   time.sleep(1)
  else:raise RuntimeError('Prior idle watcher did not exit')
 state['active']=None;write(ROOT/'queue_state.json',state)
 os.execv(PYTHON,[PYTHON,'-u',str(ROOT/'queue_run.py')])
except BaseException:
 write(ROOT/'launch_error.json',dict(error=traceback.format_exc(),time=time.time()));raise
