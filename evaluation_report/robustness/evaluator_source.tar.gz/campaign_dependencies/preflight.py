"""Unscored native inference smoke and RT eager/graph parity on real LIBERO observations."""
import argparse, hashlib, json, time
from pathlib import Path
import numpy as np
import torch
from policy_adapter import PolicyAdapter

BASE=Path('/storage/anhdh35/Light-WAM')
VAE=BASE/'checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth'
TEXT=Path('/storage/anhdh35/LoopWAM_NT-eval/data/matched_text')
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''): h.update(block)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser(); p.add_argument('--family',required=True,choices=['chrono','residual_trans'])
    p.add_argument('--checkpoint',required=True); p.add_argument('--stats',required=True)
    p.add_argument('--chrono-graph',action='store_true'); p.add_argument('--schedule',default='S1'); p.add_argument('--output',required=True)
    args=p.parse_args(); ckpt=Path(args.checkpoint)
    receipt=json.loads(ckpt.with_name(ckpt.name+'.download.json').read_text())
    digest=sha(ckpt)
    if digest!=receipt['hub_lfs_sha256']: raise ValueError('Checkpoint LFS hash mismatch')
    if sha(VAE)!='38071ab59bd94681c686fa51d75a1968f64e470262043be31f7a094e442fd981': raise ValueError('VAE mismatch')
    if sha(args.stats)!='d5ad351eb3272f416d34082e8af5483ba1118ceca355a37d9f268fdb269fb3e4': raise ValueError('Stats mismatch')
    provenance=json.loads((TEXT/'provenance.json').read_text())
    for name,item in provenance['files'].items():
        if sha(TEXT/name)!=item['sha256']: raise ValueError('Text cache mismatch')
    from scripts.evaluate_loopwam_libero import ObservationAdapter
    payload=torch.load(ckpt,map_location='cpu',mmap=True,weights_only=False)
    if args.family=='chrono':
        from fastwam.models.wan22.chronoloop import ChronoConfig,create_chronoloop
        config=json.loads((ckpt.parent/'config.json').read_text())
        manifest=json.loads((ckpt.parent.parent/'manifest.json').read_text())
        if config['epoch']!=10 or payload['step']!=config['epoch_complete_update'] or payload['chrono']!=config['chrono'] or payload['chrono']!=manifest['contract']['chrono']: raise ValueError('Chrono epoch/config mismatch')
        cfg=ChronoConfig(**payload['chrono']); model,_=create_chronoloop(cfg,str(VAE),checkpoint_path=str(ckpt),device='cuda:0')
        extra={'history_frame':bool(cfg.history_frame)}
    else:
        from fastwam.models.wan22.transport_inference import TransportInference
        from fastwam.models.wan22.residual_transport import SCHEDULES
        from scripts.evaluate_loopwam_libero import validate_transport_checkpoint
        data=json.loads((ckpt.parent/'data/data_manifest.json').read_text())
        validate_transport_checkpoint(payload,data,sha(args.stats))
        if payload['training_state']['epoch']!=10: raise ValueError('Epoch 10 required')
        model=TransportInference(str(ckpt),str(VAE),schedule=args.schedule).eval()
        extra={'schedule':args.schedule,'depths':SCHEDULES[args.schedule]}
    del payload
    observation=ObservationAdapter(json.loads(Path(args.stats).read_text()),TEXT)
    adapter=PolicyAdapter(args.family,model,observation,**extra)
    graphs=None
    if args.family=='chrono' and args.chrono_graph:
        from chrono_graph import ChronoGraphs
        graphs=ChronoGraphs(model)
    from libero.libero import benchmark
    from experiments.libero.libero_utils import get_libero_env
    results=[]
    for suite_name,task_id,seed in [('libero_spatial',0,42),('libero_goal',1,43),('libero_10',2,44)]:
        suite=benchmark.get_benchmark_dict()[suite_name](); task=suite.get_task(task_id)
        context,mask=observation.text(task.language)
        context=context.to('cuda',dtype=torch.float32); mask=mask.to('cuda')
        env,_=get_libero_env(task,256,seed)
        try:
            env.reset(); obs=env.set_init_state(suite.get_task_init_states(task_id)[0])
            for _ in range(30): obs,_,_,_=env.step([0,0,0,0,0,0,-1])
            adapter.reset_episode(); eager_state=None; graph_state=None; segment=0
            from collections import deque
            history=deque(maxlen=4)
            for query in range(5):
                image,proprio=observation.observation(obs)
                with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
                    t=time.perf_counter(); action=adapter.predict(obs,context,mask,seed); torch.cuda.synchronize(); elapsed=time.perf_counter()-t
                    record={'suite':suite_name,'seed':seed,'query':query,'eager_seconds':elapsed}
                    if args.family=='residual_trans':
                        kw=dict(input_image=image,proprio=proprio,context=context,context_mask=mask,seed=seed,schedule=args.schedule)
                        native=model.infer_action(**kw,compile_action_infer=False)['action']
                        t=time.perf_counter(); graph=model.infer_action(**kw,compile_action_infer=True)['action']; torch.cuda.synchronize()
                        record.update(graph_seconds=time.perf_counter()-t,bit_exact=torch.equal(native,graph),max_abs_difference=float((native-graph).abs().max()))
                    if graphs is not None:
                        history.append(image)
                        kw=dict(input_image=image,proprio=proprio,context=context,context_mask=mask,seed=seed,
                            history_image=history[0] if cfg.history_frame else None)
                        graphs.enable(False)
                        eager=model.chrono_infer_action(**kw,state=eager_state)
                        graphs.enable(True)
                        t=time.perf_counter(); fast=model.chrono_infer_action(**kw,state=graph_state); torch.cuda.synchronize()
                        graph_seconds=time.perf_counter()-t
                        graphs.enable(False)
                        eager_state=eager['state']; graph_state=fast['state']
                        state_equal=(eager_state is None and graph_state is None) or (eager_state is not None and graph_state is not None and torch.equal(eager_state,graph_state))
                        record.update(graph_seconds=graph_seconds,bit_exact=torch.equal(eager['action'],fast['action']) and state_equal,
                            state_bit_exact=state_equal,max_abs_difference=float((eager['action']-fast['action']).abs().max()))
                    results.append(record); print(json.dumps(record),flush=True)
                for a in action[:10]:
                    obs,_,done,_=env.step(a)
                    if done: break
                if done:
                    segment+=1
                    env.reset(); obs=env.set_init_state(suite.get_task_init_states(task_id)[segment])
                    for _ in range(30): obs,_,_,_=env.step([0,0,0,0,0,0,-1])
                    adapter.reset_episode(); eager_state=None; graph_state=None; history.clear()
        finally: env.close()
    out={'mode':'unscored_preflight','family':args.family,'checkpoint_sha256':digest,'schedule':args.schedule if args.family=='residual_trans' else None,'queries':results,'graph_passed':len(results)==15 and (args.family=='residual_trans' or graphs is not None) and all(r['bit_exact'] for r in results)}
    from gate_provenance import fingerprint
    out['provenance']=fingerprint(args.family,torch)
    out.update(torch_version=torch.__version__,gpu=torch.cuda.get_device_name(0),preflight_sha256=sha(__file__),chrono_graph_sha256=sha(Path(__file__).with_name('chrono_graph.py')))
    Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__': main()
