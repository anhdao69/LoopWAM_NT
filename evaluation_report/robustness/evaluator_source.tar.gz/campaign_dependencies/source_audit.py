"""Compare a published training revision with the pinned native inference source."""
import ast,hashlib,json,re,subprocess
from pathlib import Path
ROOTS={'chrono':Path('/storage/anhdh35/ChronoLoop-eval'),'residual_trans':Path('/storage/anhdh35/ResidualTrans-eval')}

def adapter_signature(source):
    matches=[node for node in ast.parse(source).body if isinstance(node,ast.ClassDef) and node.name=='ObservationAdapter']
    if len(matches)!=1: raise ValueError('ObservationAdapter definition is missing or ambiguous')
    return ast.dump(matches[0],include_attributes=False)

def audit_source(family,checkpoint):
    checkpoint=Path(checkpoint); root=ROOTS[family]
    metadata=checkpoint.parent.parent/'manifest.json' if family=='chrono' else checkpoint.parent/'config.json'
    revision=json.loads(metadata.read_text())['git_revision']
    if not re.fullmatch('[0-9a-f]{40}',revision): raise ValueError('Invalid published Git revision')
    def git(*args): return subprocess.check_output(['git',*args],cwd=root,text=True,stderr=subprocess.STDOUT)
    try: git('cat-file','-e',revision+'^{commit}')
    except subprocess.CalledProcessError:
        git('fetch','origin',family); git('cat-file','-e',revision+'^{commit}')
    # This file is used only by training/precomputation, never the native inference or observation adapter.
    training_only='src/fastwam/datasets/chronoloop_data.py'
    paths=['src/fastwam','experiments/libero/libero_utils.py',':(exclude)'+training_only]
    diff=git('diff',revision,'HEAD','--',*paths)
    if diff: raise ValueError('Native model/dataset/observation source changed; review before evaluation:\n'+diff[:12000])
    if git('diff','HEAD','--',*paths,'scripts/evaluate_loopwam_libero.py'):
        raise ValueError('Pinned inference checkout has uncommitted source modifications')
    adapter_path='scripts/evaluate_loopwam_libero.py'
    published=git('show',revision+':'+adapter_path)
    current=(root/adapter_path).read_text()
    if adapter_signature(published)!=adapter_signature(current): raise ValueError('Published observation/action adapter differs')
    return dict(published_revision=revision,evaluation_revision=git('rev-parse','HEAD').strip(),native_source_diff_empty=True,
        adapter_ast_equal=True,training_only_diff=git('diff',revision,'HEAD','--',training_only),metadata_sha256=hashlib.sha256(metadata.read_bytes()).hexdigest(),
        evaluator_diff=git('diff',revision,'HEAD','--',adapter_path))
