#!/usr/bin/env python3
"""Matched LIBERO evaluation of native ChronoLoop/ResidualTrans epoch-10 releases."""
import argparse, importlib.util, json, multiprocessing as mp, os, queue, subprocess, sys, time, traceback
from pathlib import Path
from campaign_state import completed_groups
from policy_adapter import PolicyAdapter
from preflight import sha, VAE, TEXT, BASE

HERE=Path(__file__).resolve().parent
OLD=Path('/storage/anhdh35/LoopWAM_NT-eval')
FAMILY_ROOT={'chrono':Path('/storage/anhdh35/ChronoLoop-eval'),'residual_trans':Path('/storage/anhdh35/ResidualTrans-eval')}

def load_module(name,path):
    if name in sys.modules: return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec); sys.modules[name]=module
    try: spec.loader.exec_module(module)
    except BaseException: sys.modules.pop(name,None); raise
    return module

legacy=load_module('campaign_matched_utilities',OLD/'scripts/evaluate_matched_fullmix.py')
write=legacy.write

def validate(args):
    import torch
    ckpt=Path(args.checkpoint); receipt=json.loads(ckpt.with_name(ckpt.name+'.download.json').read_text())
    digest=sha(ckpt)
    if digest!=receipt['hub_lfs_sha256'] or ckpt.stat().st_size!=receipt['size']: raise ValueError('Checkpoint integrity mismatch')
    stats_hash=sha(args.stats)
    if stats_hash!='d5ad351eb3272f416d34082e8af5483ba1118ceca355a37d9f268fdb269fb3e4': raise ValueError('Unrecognized normalization')
    vae_hash=sha(VAE)
    if vae_hash!='38071ab59bd94681c686fa51d75a1968f64e470262043be31f7a094e442fd981': raise ValueError('VAE mismatch')
    text=json.loads((TEXT/'provenance.json').read_text())
    for name,item in text['files'].items():
        if sha(TEXT/name)!=item['sha256']: raise ValueError('Text cache hash mismatch')
    payload=torch.load(ckpt,map_location='cpu',mmap=True,weights_only=False)
    if args.family=='chrono':
        from fastwam.models.wan22.chronoloop import ChronoConfig
        config=json.loads((ckpt.parent/'config.json').read_text())
        training=json.loads((ckpt.parent.parent/'manifest.json').read_text())
        timing=json.loads((ckpt.parent.parent/'timing.json').read_text())
        contract=training['contract']; cfg=ChronoConfig(**payload['chrono'])
        if (payload['format_version']!='chronoloop-v1' or config['epoch']!=10 or
            payload['step']!=config['epoch_complete_update'] or payload['step']!=contract['planned_updates'] or
            payload['chrono']!=config['chrono'] or payload['chrono']!=contract['chrono'] or
            payload['chrono_flags_sha256']!=cfg.flags_hash() or payload['parent_sha256']!=config['parent_sha256'] or
            config['parent_sha256']!=training['parent_sha256'] or contract['normalization_sha256']!=stats_hash or
            config['schedule_sha256']!=contract['schedule_sha256'] or timing['status']!='complete' or timing['update']!=payload['step']):
            raise ValueError('Chrono publication/training contract mismatch')
        architecture=payload['chrono']; data=None
    else:
        from scripts.evaluate_loopwam_libero import validate_transport_checkpoint
        from fastwam.models.wan22.residual_transport import SCHEDULES
        training=json.loads((ckpt.parent/'config.json').read_text())
        data=json.loads((ckpt.parent/'data/data_manifest.json').read_text())
        contract=validate_transport_checkpoint(payload,data,stats_hash)
        if payload['training_state']['epoch']!=10 or contract['config']!=training['config'] or training['normalization_sha256']!=stats_hash:
            raise ValueError('Epoch/config mismatch')
        if args.schedule not in SCHEDULES: raise ValueError('Invalid schedule')
        architecture=dict(transport=payload['transport_config'],schedule=args.schedule,depths=SCHEDULES[args.schedule])
    if data:
        for name,item in data['text_cache_files'].items():
            if text['files'][name]['valid_tokens']!=item['valid_tokens']: raise ValueError('Text token-mask mismatch')
    gate=None
    if args.backend=='cuda-graph':
        if not args.gate: raise ValueError('Graph gate required')
        gate=json.loads(Path(args.gate).read_text())
        from gate_provenance import fingerprint,validate_gate
        validate_gate(gate,digest,args.schedule if args.family=='residual_trans' else None,fingerprint(args.family,torch),args.family=='chrono')
    return dict(checkpoint_sha256=digest,receipt=receipt,normalization_sha256=stats_hash,vae_sha256=vae_hash,
                architecture=architecture,training=training,text_provenance=text,graph_gate=gate)

def worker(index,args,jobs,results,verified):
    try:
        import torch
        from omegaconf import OmegaConf
        from scripts.evaluate_loopwam_libero import ObservationAdapter
        from libero.libero import benchmark
        from experiments.libero.libero_utils import get_libero_env,get_libero_image
        torch.set_num_threads(args.threads); torch.cuda.set_device(0)
        reference=load_module('lightwam_matched_reference',BASE/'experiments/libero/eval_libero_single.py')
        # Only suppress progress rendering; policy stepping remains the unchanged reference function.
        from functools import partial
        reference.tqdm=partial(reference.tqdm,disable=True)
        video_helper=load_module('campaign_video_helper',OLD/'experiments/libero/libero_utils.py')
        if args.family=='chrono':
            from fastwam.models.wan22.chronoloop import ChronoConfig,create_chronoloop
            cfg=ChronoConfig(**verified['architecture'])
            model,_=create_chronoloop(cfg,str(VAE),checkpoint_path=args.checkpoint,device='cuda:0')
            extra={'history_frame':bool(cfg.history_frame)}
            if args.backend=='cuda-graph':
                from chrono_graph import ChronoGraphs
                graph_controller=ChronoGraphs(model); graph_controller.enable()
        else:
            from fastwam.models.wan22.transport_inference import TransportInference
            model=TransportInference(args.checkpoint,str(VAE),schedule=args.schedule).eval()
            extra={'schedule':args.schedule,'depths':verified['architecture']['depths'],'use_graph':args.backend=='cuda-graph'}
        observation=ObservationAdapter(json.loads(Path(args.stats).read_text()),TEXT)
        adapter=PolicyAdapter(args.family,model,observation,**extra)
        query_times=[]
        def predict(**kw):
            started=time.perf_counter()
            with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
                action=adapter.predict(kw['obs'],kw['cached_prompt_context'],kw['cached_prompt_context_mask'],int(kw['cfg'].seed))
            query_times.append(time.perf_counter()-started)
            return action,get_libero_image(kw['obs']),None
        reference._predict_action_chunk=predict
        results.put({'event':'ready','worker':index})
        while True:
            group=jobs.get()
            if group is None: break
            reference.set_global_seed(group['seed'],get_worker_init_fn=False)
            suite=benchmark.get_benchmark_dict()[group['suite']]()
            task=suite.get_task(group['task']); states=suite.get_task_init_states(group['task'])
            if len(states)<group['episodes']: raise ValueError('Insufficient official initial states')
            context,mask=observation.text(task.language)
            context=context.to('cuda',dtype=torch.float32); mask=mask.to('cuda')
            cfg=OmegaConf.create({'seed':group['seed'],'data':{'train':{'num_frames':33,'action_video_freq_ratio':4}},
                'EVALUATION':{'task_suite_name':group['suite'],'task_id':group['task'],'num_steps_wait':30,'replan_steps':10,'visualize_future_video':False}})
            env,description=get_libero_env(task,256,group['seed']); group_rows=[]
            try:
                for ep in range(group['episodes']):
                    adapter.reset_episode(); query_times.clear(); started=time.perf_counter()
                    success,frames,_,_=reference.run_single_episode(env,states[ep],description,model,None,cfg,ep,
                        action_horizon=32,input_w=448,input_h=224,model_device='cuda:0',cached_prompt_context=context,cached_prompt_context_mask=mask)
                    rollout_seconds=time.perf_counter()-started
                    vdir=Path(args.output)/'videos'/group['id']; vdir.mkdir(parents=True,exist_ok=True)
                    video=video_helper.save_rollout_video(vdir,frames,f'trial{ep}',success,description,encoding_threads=1)
                    row=dict(group,episode=ep,initial_state_index=ep,success=bool(success),worker=index,
                        checkpoint_sha256=verified['checkpoint_sha256'],task_description=description,
                        policy_steps=len(frames),queries=len(query_times),query_seconds=sum(query_times),
                        rollout_seconds=rollout_seconds,total_seconds=time.perf_counter()-started,video=video)
                    write(Path(args.output)/'episodes'/f"{group['id']}_episode{ep}.json",row)
                    group_rows.append(row); results.put({'event':'episode','row':row})
                write(Path(args.output)/'groups'/f"{group['id']}.json",group_rows)
                results.put({'event':'group','id':group['id']})
            finally: env.close()
        results.put({'event':'done','worker':index})
    except BaseException:
        results.put({'event':'error','worker':index,'error':traceback.format_exc()}); raise

def run(args):
    out=Path(args.output); out.mkdir(parents=True,exist_ok=True)
    import fcntl
    lock=(out/'run.lock').open('a'); fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    verified=validate(args)
    groups=legacy.make_groups(args.suites,args.seeds,args.tasks,args.episodes)
    protocol=dict(family=args.family,checkpoint_sha256=verified['checkpoint_sha256'],schedule=args.schedule if args.family=='residual_trans' else None,
        groups=groups,backend=args.backend,seed_rule='base seed once per task; same base seed every query; no episode reseeding',
        reference_sha256=sha(BASE/'experiments/libero/eval_libero_single.py'),runner_sha256=sha(__file__),adapter_sha256=sha(HERE/'policy_adapter.py'),
        helper_sha256={name:sha(HERE/name) for name in ['chrono_graph.py','campaign_state.py','preflight.py','run_family.sh']},
        source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=FAMILY_ROOT[args.family],text=True).strip(),
        settling_steps=30,replan_steps=10,action_horizon=32,max_policy_steps={s:700 if s=='libero_10' else 400 for s in args.suites},
        videos=True,query_timing='observation preprocessing + native inference + action denormalization',precision='FP32 model, BF16 autocast and VAE')
    path=out/'manifest.json'
    if path.exists():
        if json.loads(path.read_text())['protocol']!=protocol: raise ValueError('Resume protocol/code mismatch')
    else:
        write(path,dict(protocol=protocol,verified=verified,arguments=vars(args),created_at=time.time(),
            mode='final_rollout' if args.episodes==50 and args.tasks==list(range(10)) and args.seeds==[42,43,44] and args.suites==list(legacy.SUITES) else 'benchmark'))
    recovered=completed_groups(out,groups,verified['checkpoint_sha256'])
    rows=[r for rs in recovered.values() for r in rs]; pending=[g for g in groups if g['id'] not in recovered]
    context=mp.get_context('spawn'); jobs=context.Queue(); results=context.Queue()
    count=min(args.workers,len(pending)); children=[]; done=set(); ready=set(); started=time.perf_counter()
    for group in pending: jobs.put(group)
    for _ in range(count): jobs.put(None)
    try:
        for i in range(count):
            process=context.Process(target=worker,args=(i,args,jobs,results,verified)); process.start(); children.append(process)
        while len(done)<count:
            try: message=results.get(timeout=5)
            except queue.Empty:
                if any(p.exitcode not in (None,0) for p in children): raise RuntimeError('Worker failed')
                if all(p.exitcode is not None for p in children): raise RuntimeError('Missing worker completion event')
                continue
            event=message['event']
            if event=='error': raise RuntimeError(message['error'])
            if event=='ready': ready.add(message['worker'])
            if event=='done': done.add(message['worker'])
            if event=='episode':
                rows.append(message['row']); print(json.dumps(message),flush=True)
            write(out/'progress.json',dict(completed=len(rows),planned=len(groups)*args.episodes,successes=sum(r['success'] for r in rows),
                ready_workers=len(ready),workers=count,elapsed_seconds=time.perf_counter()-started,recovered_episodes=sum(map(len,recovered.values()))))
        for process in children:
            process.join(30)
            if process.exitcode!=0: raise RuntimeError('Worker teardown failure')
        summary=legacy.verify_rows(groups,rows,verified['checkpoint_sha256'])
        summary.update(elapsed_seconds=time.perf_counter()-started,recovered_episodes=sum(map(len,recovered.values())),
            total_queries=sum(r['queries'] for r in rows),total_query_seconds=sum(r['query_seconds'] for r in rows),
            checkpoint_sha256=verified['checkpoint_sha256'],backend=args.backend,workers=args.workers)
        write(out/'summary.json',summary)
    except BaseException:
        write(out/'error.json',dict(error=traceback.format_exc(),completed=len(rows))); raise
    finally:
        for process in children:
            if process.is_alive(): process.terminate()
        for process in children: process.join(30)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--family',required=True,choices=list(FAMILY_ROOT))
    p.add_argument('--checkpoint',required=True); p.add_argument('--stats',required=True); p.add_argument('--output',required=True)
    p.add_argument('--schedule',default='S1'); p.add_argument('--backend',choices=['eager','cuda-graph'],default='eager'); p.add_argument('--gate')
    p.add_argument('--workers',type=int,default=4); p.add_argument('--threads',type=int,default=4)
    p.add_argument('--suites',nargs='+',default=list(legacy.SUITES)); p.add_argument('--seeds',nargs='+',type=int,default=[42,43,44])
    p.add_argument('--tasks',nargs='+',type=int,default=list(range(10))); p.add_argument('--episodes',type=int,default=50)
    args=p.parse_args()
    if not 1<=args.workers<=16 or args.threads<1: p.error('Invalid workers/threads')
    run(args)
if __name__=='__main__': main()
