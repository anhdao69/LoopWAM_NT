"""Native family query adapters. Caller owns autocast and the unchanged episode loop."""
from collections import deque
import numpy as np

def matched_actions(observation_adapter, action):
    action=observation_adapter.dataset.denormalize_action(action.detach().float().cpu()).numpy().copy()
    if action.shape!=(32,7) or not np.isfinite(action).all():
        raise ValueError('Expected finite 32x7 actions')
    action[:,-1]=np.sign(-(2*action[:,-1]-1))
    return action

class PolicyAdapter:
    def __init__(self,family,model,observation_adapter,*,history_frame=False,schedule=None,depths=None,use_graph=False):
        if family not in ('chrono','residual_trans'): raise ValueError('Unknown family')
        if family=='chrono' and use_graph: raise ValueError('Chrono graphs are not validated')
        if family=='residual_trans' and (schedule is None or not depths): raise ValueError('RT schedule required')
        self.family=family; self.model=model; self.observation_adapter=observation_adapter
        self.history_frame=history_frame; self.schedule=schedule; self.depths=depths; self.use_graph=use_graph
        self.reset_episode()
    def reset_episode(self):
        self.state=None; self.images=deque(maxlen=4)
    def predict(self,obs,context,mask,seed):
        image,proprio=self.observation_adapter.observation(obs)
        if self.family=='chrono':
            if self.history_frame: self.images.append(image)
            result=self.model.chrono_infer_action(image,proprio,context,mask,state=self.state,
                history_image=self.images[0] if self.history_frame else None,
                num_inference_steps=10,seed=int(seed))
            self.state=result['state']
        else:
            result=self.model.infer_action(input_image=image,proprio=proprio,context=context,
                context_mask=mask,action_horizon=32,num_inference_steps=len(self.depths),
                text_cfg_scale=1.,seed=int(seed),rand_device='cpu',schedule=self.schedule,
                compile_action_infer=self.use_graph)
        return matched_actions(self.observation_adapter,result['action'])
