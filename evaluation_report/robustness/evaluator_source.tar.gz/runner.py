"""Resumable task-sharded native CL evaluation on frozen Plus/Pro plans."""
import argparse,contextlib,io,json,multiprocessing as mp,os,queue,subprocess,sys,time,traceback,hashlib
from pathlib import Path
from types import SimpleNamespace
from protocol import *

def worker(index,args,jobs,results,verified,plan,start_event):
 try:
  import torch,numpy as np,random
  from omegaconf import OmegaConf
  from fastwam.models.wan22.chronoloop import ChronoConfig,create_chronoloop
  from scripts.evaluate_loopwam_libero import ObservationAdapter
  if args.benchmark=='plus':
   from libero.libero import benchmark,get_libero_path
   from libero.libero.envs import OffScreenRenderEnv
  else:
   from liberopro.liberopro import benchmark,get_libero_path
   from liberopro.liberopro.envs import OffScreenRenderEnv
   from liberopro.liberopro.envs.bddl_utils import get_problem_info
  from experiments.libero.libero_utils import get_libero_image
  from policy_adapter import PolicyAdapter
  from reference import load_reference
  from campaign_runner_fast import load_module
  from preflight import VAE
  torch.set_num_threads(args.threads);torch.cuda.set_device(0)
  cfg_model=ChronoConfig(**verified['architecture'])
  model,_=create_chronoloop(cfg_model,str(VAE),checkpoint_path=args.checkpoint,device='cuda:0');model.eval()
  text_provenance=json.loads((BULK/'text/provenance.json').read_text())
  observation=ObservationAdapter(json.loads(Path(STATS).read_text()),BULK/'text',text_files=text_provenance['files'])
  adapter=PolicyAdapter('chrono',model,observation,history_frame=bool(cfg_model.history_frame))
  ref=load_reference();ref['get_libero_image']=get_libero_image
  video_helper=load_module('robustness_video_helper',Path('/storage/anhdh35/LoopWAM_NT-eval/experiments/libero/libero_utils.py'))
  suites={};query_log=[];current={}
  def predict(**kw):
   started=time.perf_counter()
   with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
    action=adapter.predict(kw['obs'],current['context'],current['mask'],42)
   query_log.append(dict(query=len(query_log),seconds=time.perf_counter()-started,action_sha256=hashlib.sha256(action.tobytes()).hexdigest()))
   return action,get_libero_image(kw['obs']),None
  ref['_predict_action_chunk']=predict
  results.put(dict(event='ready',worker=index));start_event.wait()
  while True:
   group=jobs.get()
   if group is None:break
   # Fixed groups, separate RNG states per process; no episode reseeding.
   random.seed(42);np.random.seed(42);torch.manual_seed(42);torch.cuda.manual_seed_all(42)
   if group['suite'] not in suites:
    with contextlib.redirect_stdout(io.StringIO()):suites[group['suite']]=benchmark.get_benchmark_dict()[group['suite'] if args.benchmark=='plus' else group['base_suite']]()
   suite=suites[group['suite']];task=suite.get_task(group['task'])
   description=instruction_for(args.benchmark,'plus' if args.benchmark=='plus' else ('swap' if group['category']=='Position' else 'task'),task.language,get_problem_info(group['physical_bddl'])['language_instruction'] if args.benchmark=='pro' else task.language)
   if task.name!=group['task_name'] or description!=group['description']:raise ValueError('Task catalogue/instruction changed')
   states=suite.get_task_init_states(group['task']) if args.benchmark=='plus' else torch.load(group['initial_states_file'],weights_only=False)
   if args.benchmark=='pro':ref['_get_max_steps']=lambda suite_name:group['max_steps']
   for ep in range(group['episodes']):
    if hashlib.sha256(np.asarray(states[ep]).tobytes()).hexdigest()!=group['selected_state_hashes'][ep]:raise ValueError('State content mismatch')
   context,mask=observation.text(group['description']);current.update(context=context.to('cuda',dtype=torch.float32),mask=mask.to('cuda'))
   cfg=OmegaConf.create(dict(seed=42,data=dict(train=dict(num_frames=33,action_video_freq_ratio=4)),EVALUATION=dict(task_suite_name=group['base_suite'],num_steps_wait=30,replan_steps=10,use_action_ensembler=False,visualize_future_video=False)))
   env=OffScreenRenderEnv(bddl_file_name=group['bddl'],camera_heights=256,camera_widths=256);env.seed(42)
   group_rows=[]
   try:
    for ep in range(group['episodes']):
     adapter.reset_episode();query_log.clear();started=time.perf_counter()
     success,frames,_,_=ref['run_single_episode'](env,states[ep],group['description'],model,None,cfg,ep,action_horizon=32,input_w=448,input_h=224,model_device='cuda:0')
     rollout=time.perf_counter()-started
     vdir=Path(args.output)/'videos'/group['id'];vdir.mkdir(parents=True,exist_ok=True)
     video=video_helper.save_rollout_video(vdir,frames,f'trial{ep}',success,group['description'],encoding_threads=1)
     query_path=Path(args.output)/'queries'/f"{group['id']}_{ep}.json";write(query_path,query_log)
     row=dict(id=group['id'],benchmark=args.benchmark,suite=group['suite'],base_suite=group['base_suite'],task=group['task'],task_name=group['task_name'],category=group['category'],difficulty=group['difficulty'],description=group['description'],seed=42,episode=ep,initial_state_index=ep,initial_state_sha256=group['selected_state_hashes'][ep],success=bool(success),policy_steps=len(frames),queries=len(query_log),query_seconds=sum(q['seconds'] for q in query_log),rollout_seconds=rollout,total_seconds=time.perf_counter()-started,worker=index,checkpoint_sha256=verified['checkpoint_sha256'],video=str(video),video_sha256=sha(video),query_log=str(query_path),query_log_sha256=sha(query_path))
     write(Path(args.output)/'episodes'/f"{group['id']}_{ep}.json",row);group_rows.append(row);results.put(dict(event='episode',row=row))
    verify_rows([group],group_rows,verified['checkpoint_sha256'],videos=True)
    write(Path(args.output)/'groups'/f"{group['id']}.json",group_rows)
   finally:env.close()
  results.put(dict(event='done',worker=index))
 except BaseException:
  results.put(dict(event='error',error=traceback.format_exc(),worker=index));raise

def run(args):
 import fcntl
 out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
 lock=(out/'run.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 from campaign_runner_fast import validate
 verified=validate(SimpleNamespace(checkpoint=args.checkpoint,stats=STATS,family='chrono',backend='eager',schedule='S1',gate=None))
 from source_audit import audit_source
 verified['source_audit']=audit_source('chrono',args.checkpoint)
 if verified['checkpoint_sha256']!=args.checkpoint_sha256:raise ValueError('Wrong checkpoint')
 plan=json.loads((ROOT/f'{args.benchmark}_tasks.json').read_text());groups=plan['groups']
 if args.calibration:
  selected=[];counts={}
  for g in groups:
   cat=g['category']
   if counts.get(cat,0)<2:selected.append(dict(g,episodes=1));counts[cat]=counts.get(cat,0)+1
  # Also cover every suite for Pro (eight groups), preserving original state 0.
  if args.benchmark=='pro':
   selected=[];seen=set()
   for g in groups:
    if g['suite'] not in seen:selected.append(dict(g,episodes=1));seen.add(g['suite'])
  if args.benchmark=='plus':
   covered={g['base_suite'] for g in selected}
   for g in groups:
    if g['base_suite'] not in covered:selected.append(dict(g,episodes=1));covered.add(g['base_suite'])
  groups=selected
 for g in groups:
  if sha(g['physical_bddl'])!=g['bddl_sha256'] or sha(g['initial_states_file'])!=g['initial_states_sha256']:raise ValueError('Benchmark asset changed')
 source_files=[ROOT/n for n in ['runner.py','protocol.py','reference.py']]+[CAMPAIGN/n for n in ['policy_adapter.py','campaign_runner_fast.py','preflight.py']]+[FASTER/'experiments/libero/eval_libero_single.py',Path('/storage/anhdh35/ChronoLoop-eval/scripts/evaluate_loopwam_libero.py'),Path('/storage/anhdh35/ChronoLoop-eval/experiments/libero/libero_utils.py'),Path('/storage/anhdh35/LoopWAM_NT-eval/experiments/libero/libero_utils.py')]
 source_files+=list(Path('/storage/anhdh35/ChronoLoop-eval/src/fastwam').rglob('*.py'))
 source_files+=list((REPOS[args.benchmark]/('libero/libero' if args.benchmark=='plus' else 'liberopro/liberopro')).rglob('*.py'))
 code={str(p):sha(p) for p in source_files}
 protocol=dict(checkpoint_sha256=verified['checkpoint_sha256'],groups=groups,plan_sha256=sha(ROOT/f'{args.benchmark}_tasks.json'),backend='eager',workers=args.workers,threads=args.threads,precision='FP32 model, BF16 autocast/VAE',code=code,settling_steps=30,replan_steps=10,action_horizon=32,denoising_steps=10,model_reset='Chrono state and CL-FRAME history reset before every episode',text_sha256=sha(BULK/'text/provenance.json'),source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/storage/anhdh35/ChronoLoop-eval',text=True).strip(),benchmark_revision=plan['source_revision'],fasterwam_revision=plan['fasterwam_revision'],mode='unscored_speed_calibration' if args.calibration else 'scored',videos=True)
 manifest=out/'manifest.json'
 if manifest.exists():
  if json.loads(manifest.read_text())['protocol']!=protocol:raise ValueError('Resume protocol/code mismatch')
 else:write(manifest,dict(protocol=protocol,verified=verified,arguments=vars(args),created_unix=time.time()))
 recovered=recover_groups(out,groups,args.checkpoint_sha256);rows=[r for rs in recovered.values() for r in rs]
 pending=[g for g in groups if g['id'] not in recovered]
 ctx=mp.get_context('spawn');jobs=ctx.Queue();results=ctx.Queue();start_event=ctx.Event();scored_started=None;count=min(len(pending),args.workers);children=[];done=set();ready=set();started=time.perf_counter()
 for g in pending:jobs.put(g)
 for _ in range(count):jobs.put(None)
 write(out/'progress.json',dict(completed=len(rows),planned=sum(g['episodes'] for g in groups),successes=sum(r['success'] for r in rows),stage='loading',workers=count))
 try:
  for i in range(count):
   p=ctx.Process(target=worker,args=(i,args,jobs,results,verified,plan,start_event));p.start();children.append(p)
  while len(done)<count:
   try:message=results.get(timeout=10)
   except queue.Empty:
    if any(p.exitcode not in (None,0) for p in children) or all(p.exitcode is not None for p in children):raise RuntimeError('Worker exited without completion')
    continue
   event=message['event']
   if event=='error':raise RuntimeError(message['error'])
   if event=='ready':
    ready.add(message['worker'])
    if len(ready)==count:scored_started=time.perf_counter();start_event.set()
   if event=='done':done.add(message['worker'])
   if event=='episode':rows.append(message['row']);print(json.dumps(message),flush=True)
   write(out/'progress.json',dict(completed=len(rows),planned=sum(g['episodes'] for g in groups),successes=sum(r['success'] for r in rows),elapsed_seconds=time.perf_counter()-started,ready_workers=len(ready),workers=count,stage='rollout'))
  for p in children:
   p.join(30)
   if p.exitcode!=0:raise RuntimeError('Worker teardown failed')
  complete=recover_groups(out,groups,args.checkpoint_sha256)
  rows=[r for rs in complete.values() for r in rs];summary=verify_rows(groups,rows,args.checkpoint_sha256,videos=True)
  summary.update(scored_wall_seconds=time.perf_counter()-scored_started if scored_started else 0,elapsed_seconds=time.perf_counter()-started,checkpoint_sha256=args.checkpoint_sha256,workers=args.workers,mode=protocol['mode'],completed_unix=time.time(),total_queries=sum(r['queries'] for r in rows),query_seconds=sum(r['query_seconds'] for r in rows))
  write(out/'summary.json',summary)
 except BaseException:
  write(out/'error.json',dict(error=traceback.format_exc(),completed=len(rows),time=time.time()));raise
 finally:
  for p in children:
   if p.is_alive():p.terminate()
  for p in children:p.join(30)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--benchmark',required=True,choices=['plus','pro']);p.add_argument('--checkpoint',required=True);p.add_argument('--checkpoint-sha256',required=True);p.add_argument('--output',required=True);p.add_argument('--workers',type=int,default=4);p.add_argument('--threads',type=int,default=2);p.add_argument('--calibration',action='store_true')
 args=p.parse_args()
 if not 1<=args.workers<=12:p.error('Workers must be 1..12')
 run(args)
