"""Execute unchanged published FasterWAM rollout AST with a CL policy callback.

Annotations are postponed to avoid loading the FasterWAM model dependencies.
Only display progress is suppressed. No statements in the rollout are edited.
"""
import ast
from functools import partial
import numpy as np
from tqdm import tqdm
from protocol import FASTER,sha
EXPECTED_FASTER_COMMIT='83667817df0d4f823f39d90700e61ea2f432ac45'
def load_reference():
 path=FASTER/'experiments/libero/eval_libero_single.py'
 names={'run_single_episode','_get_max_steps','_get_future_frame_capture_steps'}
 tree=ast.parse('from __future__ import annotations\n')
 tree.body.extend(node for node in ast.parse(path.read_text()).body if isinstance(node,ast.FunctionDef) and node.name in names)
 ns=dict(np=np,tqdm=partial(tqdm,disable=True),get_libero_dummy_action=lambda:[0,0,0,0,0,0,-1])
 exec(compile(tree,str(path),'exec'),ns)
 return ns
