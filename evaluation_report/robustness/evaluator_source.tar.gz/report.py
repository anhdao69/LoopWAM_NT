"""Live scores, full per-episode exports, and protocol/provenance links."""
import csv,html,json,time
from collections import defaultdict
from pathlib import Path
from protocol import *
def generate(state):
 jobs=[];all_rows=[];by_category=[];by_suite=[]
 for job in state['jobs']:
  out=Path(job['output']);rows=[]
  # Only task groups committed atomically count toward the official score.
  for p in sorted((out/'groups').glob('*.json')):rows.extend(json.loads(p.read_text()))
  successes=sum(r['success'] for r in rows)
  record=dict(model=job['model'],benchmark=job['benchmark'],status=job['status'],episodes=len(rows),planned=job['expected_episodes'],successes=successes,success_rate=successes/len(rows) if rows else None,workers=job.get('selected_workers'),summary=job.get('summary'),output=str(out))
  jobs.append(record)
  for row in rows:all_rows.append(dict(model=job['model'],**row))
  for field,target in [('category',by_category),('base_suite',by_suite)]:
   groups=defaultdict(list)
   for r in rows:groups[r[field]].append(r)
   for name,values in groups.items():target.append(dict(model=job['model'],benchmark=job['benchmark'],group=name,episodes=len(values),successes=sum(r['success'] for r in values),success_rate=sum(r['success'] for r in values)/len(values)))
 result=dict(updated_unix=time.time(),seed=42,planned_episodes=16142,jobs=jobs,categories=by_category,suites=by_suite,active=state.get('active'))
 write(REPORT/'results.json',result)
 for name,rows in [('run_summary.csv',jobs),('category_results.csv',by_category),('suite_results.csv',by_suite),('episode_details.csv',all_rows)]:
  p=REPORT/name;temp=p.with_suffix('.tmp')
  with temp.open('w') as f:
   if rows:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
  temp.replace(p)
 table=''.join('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in [j['model'],j['benchmark'],j['status'],f"{j['episodes']}/{j['planned']}",f"{100*j['success_rate']:.2f}%" if j['success_rate'] is not None else '—',j['workers'] or '—'])+'</tr>' for j in jobs)
 cats=''.join(f"<tr><td>{r['model']}</td><td>{r['benchmark']}</td><td>{r['group']}</td><td>{r['episodes']}</td><td>{100*r['success_rate']:.2f}%</td></tr>" for r in by_category)
 details=''
 if (REPORT/'protocol_audit.json').exists():details=html.escape((REPORT/'protocol_audit.json').read_text())
 content=f'''<!doctype html><meta charset="utf-8"><title>CL LIBERO-Plus / Pro evaluation</title><style>body{{font:16px system-ui;max-width:1300px;margin:32px auto;padding:0 20px}}table{{border-collapse:collapse;width:100%;margin:20px 0}}td,th{{border:1px solid #ccc;padding:8px;text-align:left}}pre{{white-space:pre-wrap;overflow-wrap:anywhere}}small{{color:#555}}</style><h1>ChronoLoop robustness evaluation</h1><p>Updated {time.strftime('%Y-%m-%d %H:%M:%S %Z')}. Seed 42 only. Seven epoch-10 checkpoints, 14 scored jobs, 16,142 planned episodes.</p><p>Plus: exact FasterWAM released 15% subset, sampling seed 42, one official initial state per task: 1,506/model. Pro: separate Position and Task, four suites, ten tasks/suite, ten official initial states/task: 800/model. All task groups use seed42. Overall SR is episode-weighted; category averages are separate. Partial results are provisional. Calibration episodes are excluded.</p><p><a href="plus_tasks.json">Frozen Plus manifest</a> · <a href="pro_tasks.json">Frozen Pro manifest</a> · <a href="protocol_audit.json">Protocol and source audit</a> · <a href="queue_status.json">Live queue</a> · <a href="episode_details.csv">Every scored episode</a> · <a href="results.json">Machine-readable results</a></p><table><tr><th>Model</th><th>Benchmark</th><th>Status</th><th>Episodes</th><th>SR</th><th>Workers</th></tr>{table}</table><h2>Perturbation results</h2><table><tr><th>Model</th><th>Benchmark</th><th>Category</th><th>Episodes</th><th>SR</th></tr>{cats}</table><h2>Active stage</h2><pre>{html.escape(json.dumps(state.get('active'),indent=2))}</pre><h2>Protocol audit</h2><pre>{details}</pre>'''
 p=REPORT/'report.html';temp=p.with_suffix('.tmp');temp.write_text(content);temp.replace(p)
if __name__=='__main__':generate(json.loads((ROOT/'queue_state.json').read_text()))
