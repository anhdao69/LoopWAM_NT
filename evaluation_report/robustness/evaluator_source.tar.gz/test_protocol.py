import unittest, importlib.util, tempfile
from pathlib import Path
SPEC=importlib.util.find_spec('protocol')
class ProtocolTests(unittest.TestCase):
 def test_official_subset_not_full_or_global_sampling(self):
  self.assertIsNotNone(SPEC,'Protocol builder is not implemented')
  from protocol import sample_ids
  import ast, math, random, json, contextlib, io
  # Execute the published manager's real sampler with in-memory benchmark metadata.
  p=Path('/storage/anhdh35/FasterWAM-protocol/experiments/libero/run_libero_manager.py')
  names={'create_task_file','_instantiate_suite','_validate_benchmark_suite'}
  tree=ast.parse('from __future__ import annotations\n'); tree.body.extend(n for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names)
  counts={'libero_10':2519,'libero_goal':2591,'libero_spatial':2402,'libero_object':2518}
  from types import SimpleNamespace
  registry={k:lambda count=v:SimpleNamespace(n_tasks=count) for k,v in counts.items()}
  ns=dict(Path=Path,math=math,random=random,json=json,contextlib=contextlib,io=io,benchmark=SimpleNamespace(get_benchmark_dict=lambda:registry))
  exec(compile(tree,str(p),'exec'),ns)
  with tempfile.TemporaryDirectory() as t,contextlib.redirect_stdout(io.StringIO()):
   dest=Path(t)/'tasks.csv';ns['create_task_file'](dest,list(counts),benchmark_name='libero-plus',sample_ratio=.15,sample_seed=42)
   expected=[(s,int(i)) for s,i in (line.split(',') for line in dest.read_text().splitlines())]
  actual=[(s,i) for s,n in counts.items() for i in sample_ids(s,n)]
  self.assertEqual(actual,expected);self.assertEqual(len(actual),1506)
 def test_completion_rejects_duplicates_missing_and_wrong_initial_state(self):
  self.assertIsNotNone(SPEC,'Protocol validator is not implemented')
  from protocol import verify_rows
  groups=[dict(id='x',episodes=2,max_steps=400)]
  rows=[dict(id='x',episode=i,initial_state_index=i,seed=42,success=True,policy_steps=11,queries=2,checkpoint_sha256='abc') for i in range(2)]
  self.assertEqual(verify_rows(groups,rows,'abc')['episodes'],2)
  for invalid in [rows[:1],[rows[0],rows[0]],[rows[0],dict(rows[1],initial_state_index=0)],[rows[0],dict(rows[1],checkpoint_sha256='bad')],[rows[0],dict(rows[1],policy_steps=401)]]:
   with self.assertRaises(ValueError):verify_rows(groups,invalid,'abc')
 def test_position_does_not_introduce_language_shift_and_task_uses_new_goal(self):
  import protocol
  self.assertTrue(hasattr(protocol,'instruction_for'),'Instruction routing missing')
  self.assertEqual(protocol.instruction_for('plus','plus','task view 1','task'),'task view 1')
  self.assertEqual(protocol.instruction_for('pro','swap','open the middle drawer','open the middle layer of the drawer'),'open the middle drawer')
  self.assertEqual(protocol.instruction_for('pro','task','open the middle drawer','open the bottom drawer'),'open the bottom drawer')
 def test_resume_only_recovers_complete_groups(self):
  self.assertIsNotNone(SPEC,'Recovery is not implemented')
  from protocol import recover_groups,write
  groups=[dict(id='x',episodes=2,max_steps=400)]
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);write(root/'episodes/x_0.json',dict(id='x',episode=0))
   self.assertEqual(recover_groups(root,groups,'abc'),{})
if __name__=='__main__':unittest.main()
