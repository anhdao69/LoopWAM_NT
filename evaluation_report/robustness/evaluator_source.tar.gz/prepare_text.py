"""Cache actual perturbed instructions with the verified batch-one T5 path."""
import hashlib,json,sys,time
from pathlib import Path
from protocol import *
import torch
from fastwam.datasets.loopwam_long import DEFAULT_PROMPT
from lightwam.models.wan22.helpers.loader import _load_registered_model
from lightwam.models.wan22.wan_video_text_encoder import HuggingfaceTokenizer

def main():
 cache=BULK/'text';cache.mkdir(parents=True,exist_ok=True)
 original=Path('/storage/anhdh35/LoopWAM_NT-eval/data/matched_text')
 original_meta=json.loads((original/'provenance.json').read_text())
 tasks=[g for kind in ['plus','pro'] if (ROOT/f'{kind}_tasks.json').exists() for g in json.loads((ROOT/f'{kind}_tasks.json').read_text())['groups']]
 prompts=sorted({DEFAULT_PROMPT.format(task=g['description']) for g in tasks});pending=[];files={}
 for prompt in prompts:
  name=hashlib.sha256(prompt.encode()).hexdigest()+'.t5_len128.wan22ti2v5b.pt'
  if name in original_meta['files']:
   if sha(original/name)!=original_meta['files'][name]['sha256']:raise ValueError('Original cache mismatch')
   if not (cache/name).exists():(cache/name).symlink_to(original/name)
  if not (cache/name).exists():pending.append((prompt,name))
 wan=Path('/storage/anhdh35/Light-WAM/checkpoints/Wan-AI/Wan2.1-T2V-1.3B');encoder_path=wan/'models_t5_umt5-xxl-enc-bf16.pth'
 if sha(encoder_path)!=original_meta['encoder_sha256']:raise ValueError('T5 checkpoint mismatch')
 torch.set_num_threads(4)
 if pending:
  encoder=_load_registered_model(str(encoder_path),'wan_video_text_encoder',torch_dtype=torch.bfloat16,device='cuda').eval()
  tokenizer=HuggingfaceTokenizer(name=str(wan/'google/umt5-xxl'),seq_len=128,clean='whitespace')
  with torch.inference_mode():
   for i,(prompt,name) in enumerate(pending):
    ids,mask=tokenizer(prompt,return_mask=True,add_special_tokens=True);mask=mask.cuda().bool()
    context=encoder(ids.cuda(),mask)[0].cpu().contiguous();mask=mask[0].cpu().contiguous()
    tmp=cache/(name+'.tmp');torch.save(dict(context=context,mask=mask),tmp);tmp.replace(cache/name)
    if i%25==0:print(json.dumps(dict(encoded=i+1,pending=len(pending))),flush=True)
 for prompt in prompts:
  name=hashlib.sha256(prompt.encode()).hexdigest()+'.t5_len128.wan22ti2v5b.pt';d=torch.load(cache/name,weights_only=False,map_location='cpu')
  if d['context'].shape!=(128,4096) or d['mask'].shape!=(128,) or not torch.isfinite(d['context']).all():raise ValueError('Bad text cache')
  files[name]=dict(sha256=sha(cache/name),valid_tokens=int(d['mask'].sum()),prompt=prompt)
 write(cache/'provenance.json',dict(source='Exact prior CL/Light-WAM batch-one BF16 UMT5 encoder path; actual official perturbed Task.language',encoder_sha256=original_meta['encoder_sha256'],tokenizer_sha256={p.name:sha(p) for p in (wan/'google/umt5-xxl').iterdir() if p.is_file()},files=files))
 print('Prepared',len(files),'prompts',flush=True)
if __name__=='__main__':main()
