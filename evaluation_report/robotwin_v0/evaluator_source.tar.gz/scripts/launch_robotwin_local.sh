#!/usr/bin/env bash
set -euo pipefail
source /data14t/anhdh35/loopwam_robotwin_v0_20261030/environment.sh
cd /storage/anhdh35/LoopWAM-robotwin-eval
exec python scripts/robotwin_local_queue.py
