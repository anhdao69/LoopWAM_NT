import hashlib,json
from pathlib import Path
import pytest
from prerequisites import validate_run_contract
from queue_safety import publish_runtime,reuse_completed
from fastwam.datasets.chronoloop_robot import ROBOTWIN50_TASKS

def contract(tmp_path):
 b=tmp_path
 config={'host':'137','schedules':['flat_k2_n2'],'checkpoint_sha256':'release-sha'}
 (b/'host_config.json').write_text(json.dumps(config))
 for name in ['checkpoint/dataset_stats.json','repo/experiments/robotwin/loopwam_policy/deploy_policy.py','repo/third_party/RoboTwin/script/eval_policy.py','runtime_manifest.json']:
  p=b/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('{}')
 h=hashlib.sha256(b'{}').hexdigest()
 p=dict(checkpoint=str(b/'checkpoint/epoch_05.pt'),checkpoint_sha256='release-sha',expected_step=237310,tasks=list(ROBOTWIN50_TASKS),settings=['demo_clean','demo_randomized'],episodes=100,seed=42,instruction_type='unseen',elastic_schedule='flat_k2_n2',action_depths=[2,2],video_loops=4,step_condition=.5,num_inference_steps=2,action_horizon=32,replan_steps=24,noise_seed='fixed seed for every query, FastWAM default',image_preprocessing='released_fastwam_pil_uint8_bf16',instruction_rng='released_fastwam_no_explicit_python_seed',cuda_graph='1',compile_action_infer=False,renderer_shader='rt',stats_sha256=h,policy_sha256=h,harness_sha256=h,vae_sha256='38071ab59bd94681c686fa51d75a1968f64e470262043be31f7a094e442fd981',runtime_hashes={str(b/'runtime_manifest.json'):h})
 return p

def test_flat22_full_run_contract_accepted(tmp_path):
 validate_run_contract(tmp_path,'flat_k2_n2',contract(tmp_path))

@pytest.mark.parametrize('field,value',[('action_depths',[4,4]),('num_inference_steps',5),('step_condition',.2),('replan_steps',12),('seed',43),('expected_step',47462),('checkpoint_sha256','other-checkpoint'),('tasks',['adjust_bottle']),('runtime_hashes',{})])
def test_wrong_schedule_or_scoring_evidence_rejected(tmp_path,field,value):
 p=contract(tmp_path);p[field]=value
 with pytest.raises(ValueError):validate_run_contract(tmp_path,'flat_k2_n2',p)

def test_other_host_schedule_rejected(tmp_path):
 p=contract(tmp_path)
 with pytest.raises(ValueError):validate_run_contract(tmp_path,'flat_k1_n2',p)

def test_frozen_manifest_cannot_be_rebound(tmp_path):
 p=tmp_path/'runtime.json';publish_runtime(p,{'files':{'code.py':{'sha256':'a'}},'created_unix':1});publish_runtime(p,{'files':{'code.py':{'sha256':'a'}},'created_unix':2})
 with pytest.raises(ValueError):publish_runtime(p,{'files':{'code.py':{'sha256':'b'}},'created_unix':3})
 assert json.loads(p.read_text())['files']['code.py']['sha256']=='a'

def test_incomplete_attempt_never_reused_as_complete(tmp_path):
 (tmp_path/'results').mkdir();(tmp_path/'results/COMPLETE.json').write_text(json.dumps({'failed':['task/setting'],'running':{}}));(tmp_path/'results/manifest.json').write_text('{}')
 with pytest.raises(ValueError):reuse_completed(tmp_path,lambda *_:None)
