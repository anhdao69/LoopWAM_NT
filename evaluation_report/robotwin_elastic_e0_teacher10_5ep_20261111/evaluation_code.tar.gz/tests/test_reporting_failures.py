import json
import pytest
import report

@pytest.mark.parametrize('queue_stage,launch_status,audit,expected',[
 ('error','running',{},'error'),
 ('error','complete',{},'error'),
 ('finalizing','complete',{},'finalizing'),
 ('evaluation','complete',{},'awaiting final audit'),
 ('complete','complete',{'status':'passed'},'complete; audited'),
])
def test_user_report_never_hides_failed_or_unaudited_work(tmp_path,monkeypatch,queue_stage,launch_status,audit,expected):
 monkeypatch.setattr(report,'B',tmp_path);monkeypatch.setattr(report,'R',tmp_path/'report')
 (tmp_path/'host_config.json').write_text(json.dumps({'host':'local','schedules':['flat_k1_n2']}))
 (tmp_path/'queue_status.json').write_text(json.dumps({'stage':queue_stage,'schedule':'flat_k1_n2'}))
 run=tmp_path/'runs/flat_k1_n2';run.mkdir(parents=True);(run/'launch.json').write_text(json.dumps({'status':launch_status}))
 if audit:(run/'final_audit.json').write_text(json.dumps(audit))
 report.update()
 actual=json.loads((tmp_path/'report/current_results.json').read_text())['runs'][0]['status']
 assert actual==expected
