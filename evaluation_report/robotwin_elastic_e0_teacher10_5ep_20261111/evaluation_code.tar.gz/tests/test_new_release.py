import copy
import pytest
from experiments.robotwin.loopwam_policy import elastic_inference as adapter

def payload():
 return dict(format_version='loopwam-s-robot-rt-v1',step=237310,transport_config=dict(kind='T0',dataset='robotwin50',scope='pc',step_cond=True),training_state=dict(epoch=5,parent_step=474620,contract=dict(asset_sha256=dict(teacher='70cf5af73db5fe582c50c5f9fb68296d5271a9c0fea51509b3cdb5f9696be1ea'))))
def guard():
 fn=getattr(adapter,'validate_elastic_release',None)
 assert callable(fn),'New release identity guard missing'
 return fn

def test_new_release_is_accepted():
 guard()(payload(),237310)

@pytest.mark.parametrize('field,value',[('step',47462),('epoch',1),('parent_step',237310),('kind','T4'),('teacher','wrong')])
def test_old_or_mislabelled_release_rejected(field,value):
 p=payload()
 if field=='step':p[field]=value
 elif field in ('epoch','parent_step'):p['training_state'][field]=value
 elif field=='kind':p['transport_config'][field]=value
 else:p['training_state']['contract']['asset_sha256'][field]=value
 with pytest.raises(ValueError):guard()(p,237310)

def test_caller_cannot_override_update_guard():
 p=payload();p['step']=47462
 with pytest.raises(ValueError):guard()(p,47462)

@pytest.mark.parametrize('host,schedules',[('local',['flat_k1_n2']),('137',['flat_k2_n2'])])
def test_each_host_accepts_only_assigned_schedule(host,schedules):
 from queue_pipeline import validate_host_assignment
 config=dict(host=host,schedules=schedules,workers=4,seed=42)
 assert validate_host_assignment(config)
 config['schedules']=['flat_k4_n2']
 with pytest.raises(ValueError):validate_host_assignment(config)

@pytest.mark.parametrize('field,value',[('workers',8),('seed',43),('host','189')])
def test_assignment_protocol_change_is_rejected(field,value):
 from queue_pipeline import validate_host_assignment
 c=dict(host='local',schedules=['flat_k1_n2'],workers=4,seed=42);c[field]=value
 with pytest.raises(ValueError):validate_host_assignment(c)
