from types import SimpleNamespace
import torch
import pytest
from experiments.robotwin.loopwam_policy.elastic_inference import RobotElasticInference, schedule_depths

@pytest.mark.parametrize('name,depths',[('flat_k1_n2',(1,1)),('flat_k2_n2',(2,2)),('flat_k4_n2',(4,4)),('flat_k4_n5',(4,)*5)])
def test_robot_dimensions_noise_and_native_rollout(name,depths):
    seen=[]
    class Policy:
        parent=SimpleNamespace(_encode_input_image_latents_tensor=lambda image:image[:, :1, None])
        def rollout(self,sample,schedule,noise):
            seen.append((sample,schedule,noise.clone()))
            return noise+1
    model=RobotElasticInference.__new__(RobotElasticInference)
    model.policy=Policy();model.device=torch.device('cpu');model.schedule=name;model.graph=None
    kw=dict(input_image=torch.zeros(3,384,320),proprio=torch.arange(14.),context=torch.zeros(2,4096),context_mask=torch.ones(2,dtype=torch.bool),seed=42,num_inference_steps=len(depths))
    a=model.infer_action(**kw)['action'];b=model.infer_action(**kw)['action']
    assert torch.equal(a,b) and a.shape==(32,14)
    sample,schedule,noise=seen[0]
    assert tuple(schedule)==depths and sample['proprio'].shape==(1,1,14)
    assert sample['context'].shape==(1,2,4096) and sample['context_mask'].dtype==torch.bool
    assert torch.equal(noise,torch.randn((1,32,14),generator=torch.Generator().manual_seed(42)))
    with pytest.raises(ValueError,match='NFE'):model.infer_action(**{**kw,'num_inference_steps':10})
    with pytest.raises(ValueError,match='14'):model.infer_action(**{**kw,'proprio':torch.zeros(8)})
    with pytest.raises(ValueError,match='32'):model.infer_action(**kw,action_horizon=24)
    with pytest.raises(ValueError,match='CFG'):model.infer_action(**kw,text_cfg_scale=2.)

def test_unknown_schedule_rejected():
    with pytest.raises(ValueError):schedule_depths('flat_k3_n2')

def test_resource_failures_never_score(tmp_path):
    from scripts.evaluate_loopwam_robotwin import completed_records
    for marker in ['OIDN error:', 'CUDA out of memory', 'cudaErrorMemoryAllocation', 'Cannot create buffer', 'ErrorDeviceLost', 'vk::DeviceLostError']:
        (tmp_path/'eval.log').write_text(marker)
        with pytest.raises(ValueError,match='renderer/resource'):completed_records(tmp_path,'demo_clean',0)
