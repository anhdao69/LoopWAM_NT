import ast
from pathlib import Path
import numpy as np
import torch
from PIL import Image

def test_image_exactly_matches_released_fastwam():
 from experiments.robotwin.loopwam_policy.deploy_policy import fastwam_image
 ref=Path(__file__).parent/'fixtures/released_fastwam_deploy_policy.py'
 tree=ast.parse(ref.read_text());resize=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_resize_rgb')
 cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='WorldActionRobotWinPolicy')
 method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_build_robotwin_image_tensor')
 ns=dict(np=np,torch=torch,Image=Image,Dict=dict,Any=object)
 exec(compile(ast.Module(body=[resize,method],type_ignores=[]),'reference','exec'),ns)
 from types import SimpleNamespace
 instance=SimpleNamespace(model=SimpleNamespace(device='cpu',torch_dtype=torch.bfloat16))
 rng=np.random.default_rng(42)
 for h,w in [(240,320),(480,640)]:
  obs={'observation':{k:{'rgb':rng.integers(0,256,(h,w,3),dtype=np.uint8)} for k in ['head_camera','left_camera','right_camera']}}
  actual=fastwam_image(obs,'cpu');expected=ns['_build_robotwin_image_tensor'](instance,obs)
  assert torch.equal(actual,expected) and actual.dtype==torch.bfloat16
