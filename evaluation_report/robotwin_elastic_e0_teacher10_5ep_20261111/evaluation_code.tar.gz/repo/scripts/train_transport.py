#!/usr/bin/env python3
"""Full-LIBERO RT training: explicit one/two/four GPU layout and exact recovery."""
from __future__ import annotations
import argparse
import contextlib
import copy
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import random
import signal
import subprocess
import time
import numpy as np
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG",":4096:8")
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader
from train_loopwam import ExactDistributedBatches,lr_factor
from transport_experiments import EXPERIMENTS,ELASTIC
from elastic_schedules import schedule_sequence,sequence_sha256,legacy_choice,block_calls
from fastwam.datasets.transport_cached import TransportCachedDataset
from fastwam.models.wan22.loopwam import create_loopwam
from fastwam.models.wan22.transport_policy import TransportPolicy
from fastwam.models.wan22.residual_transport import SCHEDULES,merge_lora

ROOT=Path(__file__).resolve().parents[1]
ASSETS=Path("/mnt/data/vmo-ai-task/anhdh35/FastWAM")
PARENT_RUN=ASSETS/"runs/loopwam_nt/v0_full_libero_job4659_20261006"

def sample_noise(indices,epoch,seed,dim=7):
    # dim: action dimension (LIBERO 7, RoboTwin 14); the per-window generator stream is otherwise unchanged.
    noise=[]; anchor=[]; times=[]
    for index in indices:
        g=torch.Generator().manual_seed(seed+1000003*epoch+97*(max(int(index),0)+1))
        noise.append(torch.randn(32,dim,generator=g))
        anchor.append(torch.randn(32,dim,generator=g))
        times.append(torch.rand(1,generator=g))
    return torch.stack(noise),torch.stack(anchor),torch.cat(times)

def atomic_save(value,path):
    path=Path(path); temp=path.with_suffix(path.suffix+".tmp")
    torch.save(value,temp); os.replace(temp,path)

def rng_state():
    return dict(cpu=torch.get_rng_state(),cuda=torch.cuda.get_rng_state(),
                python=random.getstate(),numpy=np.random.get_state())

def save_recovery(model,opt,ema,out,state,rank,world):
    states=[None]*world
    dist.all_gather_object(states,rng_state()) if world>1 else states.__setitem__(0,rng_state())
    if rank==0:
        weights={n:p.detach().cpu() for n,p in model.named_parameters() if p.requires_grad}
        atomic_save(dict(format="rt-recovery-v1",weights=weights,optimizer=opt.state_dict(),
                         ema=ema,rng=states,**state),out/"latest.pt")
        (out/"status.json").write_text(json.dumps({k:v for k,v in state.items() if k!="contract"},indent=2))
    if world>1: dist.barrier()

def load_elastic_init(model,config,path,teacher_sha256):
    """Copy the hashed common (or legacy-reconstructed) initial tensors and verify equality."""
    artifact=torch.load(path,map_location="cpu",weights_only=False)
    if artifact.get("format")!="elastic-init-v1" or artifact.get("recipe")!=config["init"]:
        raise ValueError(f"Run needs initialization recipe {config['init']}")
    if artifact["teacher_sha256"]!=teacher_sha256:
        raise ValueError("Initialization artifact was built from a different parent")
    state=dict(student_action=artifact["student_action"],step_condition=artifact["step_condition"])
    parts=["student_action","step_condition"]
    if any(p.requires_grad for p in model.transport.parameters()):
        state["transport"]=artifact["transport"][config["kind"]]; parts.append("transport")
    model.load_initial_state(state,parts)
    return parts

def export_epochs(robot,epochs):
    """Epoch ends that write epoch_EE.pt: LIBERO keeps its 8/9/10 protocol; RoboTwin-50 runs export every epoch."""
    return set(range(1,epochs+1)) if robot else {8,9,10}

ROBOT_EXPORT_FORMAT="loopwam-s-robot-rt-v1"
ROBOT_METADATA=("version","video_loops","action_loops","inference_loops","trained_max_loops","exit_weight_scale",
                "memory_tokens","history_frame","architecture")

def export_robot(model,out,epoch,config,update,contract,early=False):
    """RoboTwin-50 export: the teacher's FP32 loopwam-s-robot-v1 payload, read back from the verified teacher file (so
    the in-memory --bf16-frozen copy cannot leak), with the trained student in mot["mixtures.action.*"] plus the
    elastic fields (loaded by fastwam.models.wan22.transport_inference_robot.load_robot_transport)."""
    from fastwam.models.wan22.loopwam_init import sha256_file
    from fastwam.models.wan22.loopwam_robot import FORMAT
    from fastwam.models.wan22.residual_transport import LoRALinear
    action_module=model.student.mixtures["action"]
    if config["scope"]!="pc" or any(isinstance(m,LoRALinear) for m in action_module.modules()):
        raise ValueError("RoboTwin exports cover the full action-expert (P-c) recipes only")
    if sha256_file(contract["teacher"])!=contract["asset_sha256"]["teacher"]:
        raise ValueError("Teacher file changed since training started")
    base=torch.load(contract["teacher"],map_location="cpu",weights_only=False,mmap=True)
    if base.get("format_version")!=FORMAT: raise ValueError("Teacher is not a loopwam-s-robot-v1 checkpoint")
    student={k:v.detach().cpu().clone() for k,v in action_module.state_dict().items()}
    prefix="mixtures.action."
    mot=dict(base["mot"])
    if {k[len(prefix):] for k in mot if k.startswith(prefix)}!=set(student):
        raise ValueError("Student action expert keys differ from the teacher's")
    for k,v in student.items():
        if (v.dtype,v.shape)!=(mot[prefix+k].dtype,mot[prefix+k].shape): raise ValueError(f"Student tensor {k} changed type")
        mot[prefix+k]=v
    payload={k:base[k] for k in ROBOT_METADATA}
    payload.update(format_version=ROBOT_EXPORT_FORMAT,base_format_version=FORMAT,mot=mot,
        proprio_encoder=dict(base["proprio_encoder"]),step=update,transport_config=config,student_action=student,
        inference_action_format="unmerged-exact",transport={k:v.detach().cpu().clone() for k,v in model.transport.state_dict().items()},
        step_condition=None if model.step_condition is None else {k:v.detach().cpu().clone() for k,v in model.step_condition.state_dict().items()},
        training_state=dict(epoch=epoch,update=update,merged_lora=False,contract=contract,
            windows_seen=update*contract["global_batch"] if early else epoch*contract["windows"],
            parent_step=base.get("step"),parent_training_state=base.get("training_state")))
    path=out/("step_00002000.pt" if early else f"epoch_{epoch:02d}.pt")
    atomic_save(payload,path)
    return path

def export_epoch(model,out,epoch,config,update,contract,early=False):
    if contract.get("dataset")=="robotwin50":
        # No upload marker: RoboTwin elastic exports are not published.
        return export_robot(model,out,epoch,config,update,contract,early)
    parent=model.parent
    # A native parent-compatible backbone with merged LoRA plus RT-specific metadata.
    action=merge_lora(copy.deepcopy(model.student.mixtures["action"]).cpu())
    fp32=getattr(model,"parent_export_state",None)
    mot=dict(fp32["mot"]) if fp32 else {k:v.detach().cpu() for k,v in parent.mot.state_dict().items()}
    for k,v in action.state_dict().items(): mot["mixtures.action."+k]=v
    payload=dict(format_version="loopwam-s-v1",version="v0",architecture=parent.architecture_metadata,
        video_loops=4,action_loops=4,loop_alignment="late",trained_max_loops=4,inference_loops=4,
        exit_weight_scale=parent.exit_weight_scale,mot=mot,
        proprio_encoder=dict(fp32["proprio_encoder"]) if fp32 else {k:v.cpu() for k,v in parent.proprio_encoder.state_dict().items()},
        step=update,transport_config=config,
        student_action={k:v.detach().cpu() for k,v in model.student.mixtures["action"].state_dict().items()},
        inference_action_format="unmerged-exact",transport={k:v.detach().cpu() for k,v in model.transport.state_dict().items()},
        step_condition=None if model.step_condition is None else {k:v.detach().cpu() for k,v in model.step_condition.state_dict().items()},
        training_state=dict(epoch=epoch,update=update,merged_lora=True,contract=contract,
                            windows_seen=update*contract["global_batch"] if early else epoch*contract["windows"]))
    path=out/("step_00002000.pt" if early else f"epoch_{epoch:02d}.pt")
    atomic_save(payload,path)
    # Durable pending files are discovered/retried by uploader and job wrapper.
    (out/(path.name+".upload_pending")).touch()

def bf16_frozen(model):
    """Cast the frozen parent's FP32 nn.Linear weights (teacher action expert, video expert, proprio encoder) to BF16.

    Every parent Linear runs under BF16 autocast, which casts a frozen FP32 weight to BF16 (round to nearest even)
    on every call, because the autocast cache only keeps casts of leaves that require grad. Storing the cast once
    feeds the same BF16 operands to the same kernels. Student modules (the trainable action copy, step condition,
    transport) and every non-Linear tensor (norms, modulation tables, convolutions) stay FP32.
    """
    owners=[o for o in (model.student.mixtures["action"],model.transport,model.step_condition) if o is not None]
    student={id(m) for o in owners for m in o.modules()}
    converted=0
    for m in model.parent.modules():
        if isinstance(m,torch.nn.Linear) and id(m) not in student and m.weight.dtype==torch.float32:
            if m.weight.requires_grad or (m.bias is not None and m.bias.requires_grad):
                raise ValueError("Only frozen Linear layers may be cast")
            m.to(torch.bfloat16); converted+=1
    return converted

def validate_stacked_checkpoint(payload):
    config=payload.get("transport_config",{})
    expected=EXPERIMENTS["RT-B2a"]
    keys=("kind","scope","regime","schedules","step_cond","anchor")
    if payload.get("training_state",{}).get("epoch")!=10 or any(config.get(k)!=expected[k] for k in keys):
        raise ValueError("RT+B2 must initialize from the final RT-B2a checkpoint")

def initialize_stacked(model,initial,device):
    validate_stacked_checkpoint(initial)
    # Load merged full action weights before installing the new RT LoRA adapters.
    from fastwam.models.wan22.residual_transport import LoRALinear
    action_state=initial["mot"]
    target=model.student.mixtures["action"]
    plain=copy.deepcopy(model.parent.action_expert)
    plain.load_state_dict({k.removeprefix("mixtures.action."):v for k,v in action_state.items()
                           if k.startswith("mixtures.action.")},strict=True)
    from fastwam.models.wan22.residual_transport import install_core_lora
    plain.requires_grad_(False); install_core_lora(plain)
    model.student.mixtures["action"]=plain.to(device)
    model.step_condition.load_state_dict(initial["step_condition"])

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--run-name",choices=[*EXPERIMENTS,*ELASTIC],required=True)
    p.add_argument("--init-artifact",help="Hashed elastic initialization (scripts/elastic_init.py)")
    p.add_argument("--checkpoint-min-blocks",type=int,
        help="Checkpoint student blocks only on updates whose schedule has at least this many block calls")
    p.add_argument("--hf-folder",default=None)
    p.add_argument("--output-dir",required=True)
    p.add_argument("--teacher",default=str(PARENT_RUN/"train/latest.pt"))
    p.add_argument("--vae-path",default=str(ASSETS/"checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth"))
    p.add_argument("--manifest",default=str(PARENT_RUN/"train/data/data_manifest.json"))
    p.add_argument("--latent-dir",default=str(PARENT_RUN/"latents"))
    p.add_argument("--init-checkpoint")
    p.add_argument("--microbatch",type=int,default=8)
    p.add_argument("--expected-gpus",type=int,choices=(1,2,4,8),default=2)
    p.add_argument("--workers",type=int,default=4)
    p.add_argument("--global-batch",type=int,default=128)
    p.add_argument("--epochs",type=int,default=10)
    p.add_argument("--save-every",type=int,default=100)
    p.add_argument("--max-updates",type=int)
    p.add_argument("--resume",action="store_true")
    p.add_argument("--no-checkpoint-blocks",action="store_true")
    p.add_argument("--smoke",action="store_true")
    # Speed options (default off; preflight_cl0.py checks each against the eager path bit for bit).
    p.add_argument("--bf16-frozen",action="store_true",
        help="Store the frozen parent's nn.Linear weights in BF16 (the cast BF16 autocast performs on every call)")
    p.add_argument("--teacher-graph",action="store_true",help="CUDA-graph replay of the frozen teacher velocity")
    p.add_argument("--gc-freeze",action="store_true",help="gc.freeze() after setup; collect only at saves")
    p.add_argument("--no-fill-uninitialized",action="store_true",
        help="Skip the NaN fill deterministic mode applies to every new uninitialized buffer (a debugging aid)")
    a=p.parse_args()
    rank=int(os.getenv("RANK","0")); world=int(os.getenv("WORLD_SIZE","1"))
    local=int(os.getenv("LOCAL_RANK","0"))
    robot=ELASTIC.get(a.run_name,{}).get("dataset","libero")=="robotwin50"
    if world!=a.expected_gpus and not a.smoke: p.error("WORLD_SIZE must match --expected-gpus")
    if a.global_batch!=128 and not a.smoke: p.error("Production global batch must be 128")
    if a.epochs!=10 and not a.smoke and not robot: p.error("Production training must cover ten epochs")
    if a.global_batch%(world*a.microbatch): p.error("Invalid accumulation layout")
    torch.use_deterministic_algorithms(True)
    if a.no_fill_uninitialized: torch.utils.deterministic.fill_uninitialized_memory=False
    torch.cuda.set_device(local); torch.set_num_threads(4)
    if world>1: dist.init_process_group("nccl",device_id=torch.device("cuda",local))
    device=torch.device("cuda",local)
    elastic=a.run_name in ELASTIC
    config=copy.deepcopy(ELASTIC[a.run_name] if elastic else EXPERIMENTS[a.run_name])
    if elastic and not a.init_artifact: p.error("Elastic runs need --init-artifact")
    if config.get("verification_only") and a.max_updates is None: p.error("Verification recipes must stop at --max-updates")
    if a.checkpoint_min_blocks is not None and not elastic: p.error("Adaptive checkpointing is an elastic option")
    seed=config["seed"]
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)
    if (out/"latest.pt").exists() and not a.resume:
        raise ValueError("Run already exists; explicitly resume instead of overwriting")
    if config.get("init_run") and not a.init_checkpoint:
        raise ValueError("RT+B2 requires the final RT-B2a checkpoint")
    from fastwam.models.wan22.loopwam_init import sha256_file
    if robot:
        from fastwam.datasets.transport_robotwin import TransportRobotWinDataset,WINDOWS
        from fastwam.models.wan22.loopwam_robot import create_loopwam_robot
        vae_sha=[sha256_file(a.vae_path) if rank==0 else None]
        if world>1: dist.broadcast_object_list(vae_sha,src=0)
        data=TransportRobotWinDataset(a.manifest,a.latent_dir,vae_sha[0])
        if len(data)!=WINDOWS: raise ValueError("Unexpected RoboTwin-50 window count")
        parent,payload=create_loopwam_robot(a.vae_path,checkpoint_path=a.teacher,device=str(device),checkpoint_blocks=False)
        teacher_contract=payload["training_state"]["contract"]
        if (teacher_contract["normalization_sha256"],teacher_contract["vae_sha256"])!=(data.manifest["normalization_sha256"],vae_sha[0]):
            raise ValueError("Teacher was trained with different normalization or VAE")
        del payload
    else:
        data=TransportCachedDataset(a.manifest,a.latent_dir)
        if len(data)!=277713: raise ValueError("Unexpected full LIBERO window count")
        parent=create_loopwam(checkpoint_path=a.teacher,vae_path=a.vae_path,device=str(device))
    parent.requires_grad_(False).eval()
    action_dim=parent.action_expert.action_dim
    if action_dim!=(14 if robot else 7): raise ValueError("Teacher action dimension does not match the dataset")
    model=TransportPolicy(parent,**{k:config[k] for k in ("kind","scope","step_cond","regime","anchor")},
        checkpoint_blocks=not a.no_checkpoint_blocks,loss_weights=config.get("loss_weights"),
        reuse_teacher_prefix=config.get("reuse_teacher_prefix",False),
        collect_diagnostics=config.get("collect_diagnostics",False),teacher_graph=a.teacher_graph,
        end_prefix=config.get("end_prefix",10),gripper_loss=config.get("gripper_loss",True)).to(device)
    identities=[None]
    if rank==0:
        identities[0]=dict(teacher=sha256_file(a.teacher),initial=None if a.init_checkpoint is None else sha256_file(a.init_checkpoint),vae=sha256_file(a.vae_path))
        if elastic: identities[0]["elastic_init"]=sha256_file(a.init_artifact)
    if world>1: dist.broadcast_object_list(identities,src=0)
    if robot and identities[0]["teacher"]!=config["parent"]["sha256"]: raise ValueError("Teacher file is not the recipe's parent")
    if a.init_checkpoint:
        initial=torch.load(a.init_checkpoint,map_location="cpu",weights_only=False)
        validate_stacked_checkpoint(initial)
        initialize_stacked(model,initial,device)
    init_parts=load_elastic_init(model,config,a.init_artifact,identities[0]["teacher"]) if elastic else None
    if a.bf16_frozen:
        # Exports keep the exact FP32 parent tensors; only the in-memory frozen compute copy is BF16.
        model.parent_export_state=dict(mot={k:v.detach().cpu().clone() for k,v in parent.mot.state_dict().items()},
            proprio_encoder={k:v.detach().cpu().clone() for k,v in parent.proprio_encoder.state_dict().items()}) if rank==0 else None
        bf16_frozen(model)
    params=[p for p in model.parameters() if p.requires_grad]
    opt=torch.optim.AdamW(model.optimizer_groups(),betas=(.9,.95),eps=1e-8,fused=True)
    runner=DDP(model,device_ids=[local],broadcast_buffers=False,gradient_as_bucket_view=True,
               find_unused_parameters=config.get("find_unused_parameters",False)) if world>1 else model
    sampler=ExactDistributedBatches(len(data),a.microbatch,rank,world,seed)
    loader=DataLoader(data,batch_sampler=sampler,num_workers=a.workers,pin_memory=True,
        persistent_workers=a.workers>0,generator=torch.Generator().manual_seed(seed+rank))
    total=math.ceil(len(data)/a.global_batch)*a.epochs
    accum=a.global_batch//(world*a.microbatch)
    contract=dict(asset_sha256=identities[0],config=config,windows=len(data),world=world,microbatch=a.microbatch,
        global_batch=a.global_batch,epochs=a.epochs,planned_updates=total,teacher=str(Path(a.teacher).resolve()),
        normalization_sha256=data.manifest["normalization_sha256"],
        checkpoint_blocks=not a.no_checkpoint_blocks,deterministic_algorithms=True)
    if robot:
        if data.data_manifest_sha256!=teacher_contract["data_manifest_sha256"]: raise ValueError("Teacher was trained on other data")
        contract.update(dataset="robotwin50",data_manifest_sha256=data.data_manifest_sha256,action_dim=action_dim,
                        latent_dir=str(Path(a.latent_dir).resolve()))
    speed=dict(bf16_frozen=a.bf16_frozen,teacher_graph=a.teacher_graph,gc_freeze=a.gc_freeze,
               no_fill_uninitialized=a.no_fill_uninitialized)
    if any(speed.values()): contract["speed_options"]=speed
    sequence=None
    if elastic:
        sequence=schedule_sequence(config,total)
        staged=Path(a.latent_dir)/"STAGED.json"
        contract.update(schedule_sequence_sha256=None if sequence is None else sequence_sha256(sequence),
            checkpoint_min_blocks=a.checkpoint_min_blocks,init_parts=init_parts,
            latent_content_digest=json.loads(staged.read_text())["chunk_sha256_digest"] if staged.exists() else None)
        if rank==0 and sequence is not None:
            record=out/"schedule_sequence.json"
            if record.exists() and json.loads(record.read_text())["sha256"]!=contract["schedule_sequence_sha256"]:
                raise ValueError("Persisted schedule sequence differs from the regenerated one")
            if not record.exists():
                record.write_text(json.dumps(dict(sha256=contract["schedule_sequence_sha256"],sampler=config["sampler"],
                    seed=seed,updates=total,sequence=sequence)))
    ema={n:p.detach().clone() for n,p in model.named_parameters() if p.requires_grad}
    update=0; epoch_start=0; micro_start=0; windows_seen=0
    if a.resume:
        state=torch.load(out/"latest.pt",map_location="cpu",weights_only=False)
        if state["contract"]!=contract: raise ValueError("Resume contract changed")
        with torch.no_grad():
            for n,pv in model.named_parameters():
                if pv.requires_grad: pv.copy_(state["weights"][n])
        opt.load_state_dict(state["optimizer"])
        ema={n:v.to(device) for n,v in state["ema"].items()}
        update=state["update"]; epoch_start=state["epoch"]; micro_start=state["next_micro"]
        windows_seen=state["windows_seen"]
        rng=state["rng"][rank]; torch.set_rng_state(rng["cpu"]); torch.cuda.set_rng_state(rng["cuda"])
        random.setstate(rng["python"]); np.random.set_state(rng["numpy"])
    if a.resume and epoch_start in export_epochs(robot,a.epochs) and micro_start==0:
        if rank==0 and not (out/f"epoch_{epoch_start:02d}.pt").exists():
            export_epoch(model,out,epoch_start,config,update,contract)
        if world>1: dist.barrier()
    if a.resume and robot and update==2000:
        # Stopped between the update-2000 recovery save and its export/copy: latest.pt holds exactly those weights.
        # The condition is rank-independent so every rank reaches the barrier; only rank 0 looks at the files.
        if rank==0 and not ((out/"step_00002000.pt").exists() and (out/"step_00002000_recovery.pt").exists()):
            import shutil
            export_epoch(model,out,epoch_start,config,update,contract,early=True)
            shutil.copyfile(out/"latest.pt",out/"step_00002000_recovery.pt.tmp")
            os.replace(out/"step_00002000_recovery.pt.tmp",out/"step_00002000_recovery.pt")
        if world>1: dist.barrier()
    scale=data.transform.normalizer["action"].scale.to(device)
    offset=data.transform.normalizer["action"].offset.to(device)
    if rank==0:
        document=dict(**contract,run=a.run_name,arguments=vars(a),trainable_parameters=sum(p.numel() for p in params),
            slurm_job_id=os.getenv("SLURM_JOB_ID"),git_revision=(ROOT/"REVISION").read_text().strip() if (ROOT/"REVISION").exists() else subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),
            schedules={s:list(SCHEDULES[s]) for s in config["schedules"]},gpu=torch.cuda.get_device_name(),
            torch_version=torch.__version__,hf_folder=a.hf_folder or f"https://huggingface.co/anhdao69/ResidualTrans/tree/main/{a.run_name}")
        (out/"config.json").write_text(json.dumps(document,indent=2))
        # Preserve canonical bytes: normalization hashes bind the original formatting.
        import shutil
        shutil.copyfile(data.manifest["normalization_path"],out/"dataset_stats.json")
        (out/"data").mkdir(exist_ok=True)
        shutil.copyfile(data.manifest["normalization_path"],out/"data/dataset_stats.json")
        shutil.copyfile(a.manifest,out/"data/data_manifest.json")
        print(json.dumps(dict(event="ready",**document)),flush=True)
    stop_requested=[False]
    signal.signal(signal.SIGUSR1,lambda *_: stop_requested.__setitem__(0,True))
    model.train(); opt.zero_grad(set_to_none=True)
    log=(out/"metrics.jsonl").open("a") if rank==0 else None
    if a.gc_freeze:
        gc.collect(); gc.freeze(); gc.disable()
    for epoch in range(epoch_start,a.epochs):
        sampler.epoch=epoch; sampler.start_batch=micro_start if epoch==epoch_start else 0
        started=time.perf_counter(); logs={}; schedule=None
        # Seconds this rank waited for its DataLoader during the update (reported as the max over ranks).
        data_wait=0.; mark=time.perf_counter()
        for micro,sample in enumerate(loader,start=sampler.start_batch):
            data_wait+=time.perf_counter()-mark
            group=micro//accum
            count=min(a.global_batch,len(data)-group*a.global_batch)
            boundary=(micro+1)%accum==0 or micro+1==len(sampler)
            if micro%accum==0:
                # One configuration for the whole global batch, on every rank and microbatch.
                if sequence is not None: schedule_name=sequence[update]
                elif elastic: schedule_name=legacy_choice(seed,update,config["schedules"])
                else: schedule_name=random.Random(seed+update*65537).choice(config["schedules"])
                schedule=SCHEDULES[schedule_name]
                if a.checkpoint_min_blocks is not None:
                    # Recomputation is deterministic: this trades time for memory, not values.
                    model.checkpoint_blocks=block_calls(schedule)>=a.checkpoint_min_blocks
                model.teacher_passes=0; model.student_block_calls=0
                model.student.rt_measurement={"forward":0,"backward":0} if update<20 else None
            noise,anchor_noise,anchor_tau=sample_noise(sample["training_index"].tolist(),epoch,seed,dim=action_dim)
            sample={k:v.to(device,non_blocking=True) if torch.is_tensor(v) else v for k,v in sample.items()}
            sample.update(action_scale=scale,action_offset=offset)
            sync=runner.no_sync() if world>1 and not boundary else contextlib.nullcontext()
            with sync:
                with torch.autocast("cuda",dtype=torch.bfloat16):
                    loss,components=runner(sample,schedule,noise.to(device),anchor_noise.to(device),anchor_tau.to(device))
                if not torch.isfinite(loss): raise FloatingPointError("Nonfinite RT loss")
                (loss*world/count).backward()
            for key,val in components.items(): logs[key]=logs.get(key,0)+val
            if not boundary:
                mark=time.perf_counter(); continue
            grad=torch.nn.utils.clip_grad_norm_(params,1.,error_if_nonfinite=True)
            factor=lr_factor(update,total,math.ceil(.03*total))
            for group_ in opt.param_groups: group_["lr"]=group_["base_lr"]*factor
            opt.step(); opt.zero_grad(set_to_none=True)
            with torch.no_grad():
                for n,pv in model.named_parameters():
                    if pv.requires_grad: ema[n].lerp_(pv,.001)
            update+=1; windows_seen+=count
            torch.cuda.synchronize()
            reduced=torch.stack(list(logs.values()))
            if world>1: dist.all_reduce(reduced)
            seconds=time.perf_counter()-started
            waited=torch.tensor([data_wait],device=device,dtype=torch.float64)
            if world>1: dist.all_reduce(waited,op=dist.ReduceOp.MAX)
            record=dict(update=update,epoch=epoch+1,windows=count,windows_seen=windows_seen,
                schedule=schedule_name,seconds=seconds,data_wait_seconds=float(waited),time=time.time(),grad_norm=float(grad),
                peak_allocated_gb=torch.cuda.max_memory_allocated()/1e9,
                teacher_passes_per_microbatch=model.teacher_passes/max(1,math.ceil(count/(world*a.microbatch))),
                student_forward_blocks_per_microbatch=model.student_block_calls/max(1,math.ceil(count/(world*a.microbatch))),
                measured_action_blocks=model.student.rt_measurement,
                **{k:float(v)/count for k,v in zip(logs,reduced)})
            if elastic:
                record.update(loops=list(schedule),nfe=len(schedule),d=1/len(schedule),
                    checkpoint_blocks=model.checkpoint_blocks,lr=[g["lr"] for g in opt.param_groups])
            if rank==0:
                log.write(json.dumps(record)+"\n"); log.flush()
                if update<=20 or update%20==0: print(json.dumps(record),flush=True)
            epoch_done=micro+1==len(sampler)
            stopping=torch.tensor(int(stop_requested[0]),device=device)
            if world>1: dist.all_reduce(stopping,op=dist.ReduceOp.MAX)
            maxed=a.max_updates is not None and update>=a.max_updates
            if epoch_done or update%a.save_every==0 or maxed or stopping.item():
                state=dict(contract=contract,epoch=epoch+1 if epoch_done else epoch,
                    next_micro=0 if epoch_done else micro+1,update=update,windows_seen=windows_seen,
                    status="complete" if epoch_done and epoch+1==a.epochs else "running",
                    scheduler=dict(step=update,total=total,warmup=math.ceil(.03*total)))
                save_recovery(model,opt,ema,out,state,rank,world)
                if a.gc_freeze: gc.collect()
            if update==2000 and rank==0:
                export_epoch(model,out,epoch,config,update,contract,early=True)
                import shutil
                shutil.copyfile(out/"latest.pt",out/"step_00002000_recovery.pt.tmp")
                os.replace(out/"step_00002000_recovery.pt.tmp",out/"step_00002000_recovery.pt")
            if epoch_done and epoch+1 in export_epochs(robot,a.epochs) and rank==0:
                export_epoch(model,out,epoch+1,config,update,contract)
            if world>1 and epoch_done: dist.barrier()
            if maxed or stopping.item():
                if rank==0: print(json.dumps(dict(event="stopped",update=update,resume_ready=True)),flush=True)
                if world>1: dist.destroy_process_group()
                return
            started=time.perf_counter(); logs={}; data_wait=0.; mark=time.perf_counter()
        micro_start=0
    if rank==0:
        print(json.dumps(dict(event="complete",updates=update,windows_seen=windows_seen)),flush=True)
    if world>1: dist.destroy_process_group()

if __name__=="__main__": main()
