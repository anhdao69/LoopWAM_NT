"""Only audited full E0 schedules release this host to E0 teacher10 five-epoch."""
import hashlib,json
from pathlib import Path
from fastwam.robotwin_pipeline import validate_eval_summary
from fastwam.datasets.chronoloop_robot import ROBOTWIN50_TASKS

def validate_run_contract(base,name,manifest,episodes=100,tasks=None):
    base=Path(base).resolve();config=json.loads((base/'host_config.json').read_text())
    if name not in config['schedules']:raise ValueError('Schedule belongs to another host')
    depths={'flat_k1_n2':[1,1],'flat_k2_n2':[2,2]}[name]
    digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    expected=dict(checkpoint=str(base/'checkpoint/epoch_05.pt'),checkpoint_sha256=config['checkpoint_sha256'],expected_step=237310,tasks=list(ROBOTWIN50_TASKS) if tasks is None else tasks,settings=['demo_clean','demo_randomized'],episodes=episodes,seed=42,instruction_type='unseen',elastic_schedule=name,action_depths=depths,video_loops=4,step_condition=1/len(depths),num_inference_steps=len(depths),action_horizon=32,replan_steps=24,noise_seed='fixed seed for every query, FastWAM default',image_preprocessing='released_fastwam_pil_uint8_bf16',instruction_rng='released_fastwam_no_explicit_python_seed',cuda_graph='1',compile_action_infer=False,renderer_shader='rt',stats_sha256=digest(base/'checkpoint/dataset_stats.json'),policy_sha256=digest(base/'repo/experiments/robotwin/loopwam_policy/deploy_policy.py'),harness_sha256=digest(base/'repo/third_party/RoboTwin/script/eval_policy.py'),vae_sha256='38071ab59bd94681c686fa51d75a1968f64e470262043be31f7a094e442fd981')
    for key,value in expected.items():
        if manifest.get(key)!=value:raise ValueError(f'Wrong E0 teacher10 five-epoch run contract: {key}')
    runtime=base/'runtime_manifest.json'
    if manifest.get('runtime_hashes',{}).get(str(runtime))!=digest(runtime):raise ValueError('Result is not bound to the E0 teacher10 five-epoch runtime')
