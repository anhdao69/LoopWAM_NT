"""Independent memory-gated queue for one assigned new E0 schedule."""
import fcntl,importlib.util,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
from report import B,R,read,write,update
from verify_runtime import W,verify,freeze
from prerequisites import validate_run_contract
from handoff_safety import process_state,assert_adoptable,require_completion
from queue_safety import reuse_completed
OWNED=False
def validate_host_assignment(config):
    expected={'local':['flat_k1_n2'],'137':['flat_k2_n2']}
    if config.get('host') not in expected:raise ValueError('Unknown E0 teacher10 five-epoch host')
    schedules=expected[config['host']]
    if config.get('schedules')!=schedules:raise ValueError('E0 teacher10 five-epoch queue differs from the revised user assignment')
    if config.get('workers')!=4 or config.get('seed')!=42:raise ValueError('E0 teacher10 five-epoch evaluation protocol changed')
    return bool(schedules)
def status(stage,**extra):
    write(B/'queue_status.json',dict(stage=stage,model='E0-teacher10-5ep',host=read(B/'host_config.json')['host'],queue_pid=os.getpid(),updated_unix=time.time(),**extra));update();print(stage,extra,flush=True)
def live_child():
    old=read(B/'active_process.json');state=process_state(old.get('pid',0))
    if old.get('status')=='running' and state and state['state']!='Z' and state['start_ticks']==str(old['start_ticks']):
        assert_adoptable(old);return old
    return None
def gpu_free_after_orphan_cleanup(base,reap):
    base=Path(base).resolve()
    paths=list((base/'runs').glob('*/results/children.json'))+list((base/'smoke').glob('*/children.json'))
    # Check all live identities and campaign paths before signaling any process.
    for p in paths:
        for record in read(p):
            state=process_state(record['pid'])
            if state and state['state']!='Z' and state['start_ticks']==str(record['start_ticks']):
                if not any(arg.startswith(str(base)+'/') for arg in state['command'][1:]):raise ValueError('Recorded child belongs to another campaign')
    for p in paths:reap(p)
    return int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
def run_process(stage,cmd,logfile,**extra):
    status(stage,**extra);active=live_child();proc=None
    if active:
        if active['command']!=cmd:raise ValueError('Another owned child is alive; refusing duplicate work')
    else:
        with Path(logfile).open('a') as log:proc=subprocess.Popen(cmd,cwd=W,env=dict(os.environ),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        active=dict(pid=proc.pid,start_ticks=process_state(proc.pid)['start_ticks'],command=cmd,status='running',started_unix=time.time(),stage=stage)
        write(B/'active_process.json',active)
    try:
        while True:
            state=process_state(active['pid'])
            if state is None or state['state']=='Z' or state['start_ticks']!=str(active['start_ticks']):break
            update();time.sleep(10)
        code=proc.wait() if proc else None
        if code not in (None,0):raise RuntimeError(f'{stage} exited {code}; see {logfile}')
        active.update(status='finished',exit_code=code,finished_unix=time.time());write(B/'active_process.json',active)
    except BaseException:
        state=process_state(active['pid'])
        if state and state['state']!='Z' and state['start_ticks']==str(active['start_ticks']):
            assert_adoptable(active);os.killpg(active['pid'],signal.SIGTERM)
        raise
def command(name,out,episodes,tasks=None):
    cmd=[sys.executable,str(W/'scripts/evaluate_loopwam_robotwin.py'),'--checkpoint',str(B/'checkpoint/epoch_05.pt'),'--output-dir',str(out),'--robotwin-root',str(W/'third_party/RoboTwin'),'--data-dir',str(B/'checkpoint'),'--gpus','0','--per-gpu','4','--episodes',str(episodes),'--seed','42','--expected-step','237310','--elastic-schedule',name,'--max-attempts','3','--no-progress-timeout','1800']
    if tasks:cmd+=['--tasks',','.join(tasks)]
    return cmd
def main():
    global OWNED
    lock=(B/'queue.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);OWNED=True
    signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt()))
    c=read(B/'host_config.json')
    if not validate_host_assignment(c):
        raise ValueError('Host has no assigned schedule')
    for gate in ['cpu_validation','graph_gate','cross_host_gate','review_gate']:assert read(B/(gate+'.json'))['passed'],gate
    spec=importlib.util.spec_from_file_location('native_eval',W/'scripts/evaluate_loopwam_robotwin.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    if not live_child():
        while True:
            free=gpu_free_after_orphan_cleanup(B,m.reap_recorded_children)
            if free>=60000:break
            status('waiting_for_gpu_memory',free_mib=free,required_mib=60000);time.sleep(30)
    status('runtime_verification');freeze()
    os.environ['LOOPWAM_CUDA_GRAPH']='1';os.environ['LOOPWAM_RUNTIME_MANIFEST']=str(B/'runtime_manifest.json')
    from fastwam.robotwin_pipeline import validate_eval_summary
    from finalize import finalize
    for name in c['schedules']:
        run=B/'runs'/name;run.mkdir(parents=True,exist_ok=True)
        if (run/'results/manifest.json').exists():validate_run_contract(B,name,read(run/'results/manifest.json'))
        if reuse_completed(run,validate_eval_summary):status('finalizing',schedule=name);finalize(name);continue
        smoke=B/'smoke'/name
        if not (B/f'smoke_{name}.json').exists():
            run_process('smoke',command(name,smoke,2,['adjust_bottle','open_microwave']),B/f'smoke_{name}.log',schedule=name)
            result=require_completion(smoke,validate_eval_summary)
            validate_run_contract(B,name,read(smoke/'manifest.json'),2,['adjust_bottle','open_microwave'])
            assert len(result['finished'])==4
            for cell in result['finished'].values():assert m.completed_records(Path(cell['directory']),cell['config'],2)==cell['episodes']
            write(B/f'smoke_{name}.json',dict(passed=True,episodes=8,excluded=True,schedule=name,verified_unix=time.time()))
        else:
            assert read(B/f'smoke_{name}.json')['passed']
            validate_run_contract(B,name,read(smoke/'manifest.json'),2,['adjust_bottle','open_microwave'])
            require_completion(smoke,validate_eval_summary)
        verify(read(B/'runtime_manifest.json')['files'])
        cmd=command(name,run/'results',100);launch=read(run/'launch.json');launch.update(status='running',command=cmd,schedule=name,host=c['host'],workers=4,seed=42,planned_episodes=10000)
        launch.setdefault('started_unix',time.time());write(run/'launch.json',launch)
        run_process('evaluation',cmd,run/'evaluation.log',schedule=name)
        validate_run_contract(B,name,read(run/'results/manifest.json'))
        require_completion(run/'results',validate_eval_summary)
        launch.update(status='complete',finished_unix=time.time());write(run/'launch.json',launch)
        status('finalizing',schedule=name);finalize(name)
    status('complete',final_audit_passed=True,scored_episodes=10000*len(c['schedules']))
if __name__=='__main__':
    try:main()
    except BaseException:
        if OWNED:status('error',error=traceback.format_exc())
        raise
