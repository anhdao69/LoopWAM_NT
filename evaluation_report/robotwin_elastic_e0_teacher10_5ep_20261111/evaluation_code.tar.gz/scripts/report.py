"""Small remote progress report; final audit retains full episode artifacts."""
import json,re,time,shutil
from pathlib import Path
B=Path(__file__).resolve().parent.parent;R=B/'report'
EPISODE=re.compile(r'Success rate: (?:\x1b\[\d+m)?(\d+)/(\d+).*?current seed: (?:\x1b\[\d+m)?(\d+)')
def read(p):return json.loads(p.read_text()) if p.exists() else {}
def write(p,d):
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(d,indent=2));tmp.replace(p)
def progress(out):
    d=read(out/'COMPLETE.json') or read(out/'summary.json');cells=d.get('finished',{})
    totals={s:dict(successes=0,episodes=0) for s in ['demo_clean','demo_randomized']}
    rows=[]
    for c in cells.values():
        totals[c['config']]['successes']+=c['successes'];totals[c['config']]['episodes']+=len(c['episodes'])
        rows.append(dict(task=c['task'],setting=c['config'],successes=c['successes'],episodes=len(c['episodes']),complete=True))
    verified=sum(v['episodes'] for v in totals.values())
    for key in d.get('running',{}):
        task,setting=key.split('/');attempts=sorted((out/f'{task}__{setting}').glob('attempt_*'))
        if not attempts:continue
        a=attempts[-1];p=a/'eval.log'
        if not p.exists() or (a/'failure.json').exists():continue
        text=p.read_text(errors='replace')
        if any(m in text.lower() for m in ['oidn error:','cuda out of memory','cudaerrormemoryallocation','cannot create buffer','errordevicelost','vk::devicelosterror']):continue
        matches=EPISODE.findall(text)
        k,n=map(int,matches[-1][:2]) if matches else (0,0)
        totals[setting]['successes']+=k;totals[setting]['episodes']+=n
        rows.append(dict(task=task,setting=setting,successes=k,episodes=n,complete=False))
    totals['combined']=dict(successes=sum(v['successes'] for v in totals.values()),episodes=sum(v['episodes'] for v in totals.values()))
    for v in totals.values():v['sr_percent']=100*v['successes']/v['episodes'] if v['episodes'] else None
    return dict(totals=totals,verified_cells=len(cells),verified_episodes=verified,tasks=rows,failed=d.get('failed',[]))
def update():
    config=read(B/'host_config.json');state=read(B/'queue_status.json');rows=[]
    for name in config['schedules']:
        run=B/'runs'/name;data=progress(run/'results');launch=read(run/'launch.json');audit=read(run/'final_audit.json')
        if audit.get('status')=='passed':stage='complete; audited'
        elif state.get('stage')=='error':stage='error'
        elif state.get('stage')=='finalizing':stage='finalizing'
        elif launch.get('status')=='complete':stage='awaiting final audit'
        else:stage=launch.get('status','queued')
        rows.append(dict(schedule=name,host=config['host'],status=stage,audit=audit,**data))
    record=dict(updated_unix=time.time(),model='E0-teacher10-5ep',host=config['host'],queue=state,runs=rows)
    write(R/'current_results.json',record);write(R/'queue_status.json',state)
    for name in ['source_check.json','source_provenance.json','source_manifest.json','cpu_validation.json','graph_gate.json','cross_host_gate.json','runtime_manifest.json','host_config.json','review_gate.json','download_receipt.json','hf_manifest.json','spec.md','plan.md']:
        p=B/name
        if p.exists() and (not (R/name).exists() or p.stat().st_mtime>(R/name).stat().st_mtime):shutil.copy2(p,R/name)
    for p in B.glob('smoke_flat*.json'):shutil.copy2(p,R/p.name)
    lines=['# Elastic E0 teacher10 five-epoch — '+config['host'],'',f"Stage: {state.get('stage','preparing')}.",'','| Schedule | Status | Successes / episodes | Live SR | Verified cells |','| --- | --- | ---: | ---: | ---: |']
    for row in rows:
        total=row['totals']['combined'];sr=total['sr_percent'];rate=f'{sr:.2f}%' if sr is not None else '—'
        lines.append(f"| {row['schedule']} | {row['status']} | {total['successes']}/{total['episodes']} | {rate} | {row['verified_cells']}/100 |")
    lines += ['','All 50 tasks; clean and randomized; 100 episodes/task/setting; seed42; four workers. Assigned schedule [1,1] or [2,2], NFE2;4video loops;predict32/execute24. Scored work starts after memory and numerical gates. Each assigned schedule requires eight validated smoke episodes, excluded from scores. Live SR is provisional until the final full audit.','']
    (R/'report.md').write_text('\n'.join(lines))
