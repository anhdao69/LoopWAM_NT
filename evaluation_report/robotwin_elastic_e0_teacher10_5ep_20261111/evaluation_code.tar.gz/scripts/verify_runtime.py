"""Bind E0 teacher10 five-epoch to its checked release and the same host's immutable E0 runtime."""
import concurrent.futures,hashlib,json,time
from pathlib import Path
from queue_safety import publish_runtime
B=Path(__file__).resolve().parent.parent;W=B/'repo';R=B/'report'
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def verify(files):
    def check(item):
        p,info=item
        if sha(p)!=info['sha256']:raise ValueError(f'Immutable runtime changed: {p}')
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(check,files.items()))
def freeze():
    config=json.loads((B/'host_config.json').read_text());old=Path(config['predecessor'])
    if (W/'third_party/RoboTwin/policy/loopwam_policy').resolve()!=(W/'experiments/robotwin/loopwam_policy').resolve():raise ValueError('Wrong E0 teacher10 five-epoch deployed policy import target')
    inherited=json.loads((old/'runtime_manifest.json').read_text());verify(inherited['files'])
    source=json.loads((B/'source_manifest.json').read_text());verify({str(W/p):v for p,v in source.items()})
    receipt=json.loads((B/'download_receipt.json').read_text())
    for item in receipt['files']:
        if sha(B/'checkpoint'/Path(item['path']).name)!=item['sha256']:raise ValueError('E0 teacher10 five-epoch release file changed')
    assert sha(B/'checkpoint/epoch_05.pt')==config['checkpoint_sha256']
    assert json.loads((B/'checkpoint/dataset_stats.json').read_text())==json.loads((old/'checkpoint/dataset_stats.json').read_text())
    for name in ['cpu_validation.json','graph_gate.json','cross_host_gate.json','review_gate.json']:
        assert json.loads((B/name).read_text())['passed'],name
    paths=list((B/'scripts').glob('*.py'))+list(B.glob('*.sh'))+list((B/'checkpoint').glob('*'))+list((B/'gate_inputs').glob('*.pt'))
    paths += [B/x for x in ['host_config.json','source_manifest.json','source_provenance.json','download_receipt.json','hf_manifest.json','cpu_validation.json','graph_gate.json','cross_host_gate.json','review_gate.json','spec.md','plan.md','native_training_source.json']]
    files=dict(inherited['files']);files.update({str(W/p):v for p,v in source.items()})
    for p in paths:files[str(p)]=dict(sha256=sha(p),bytes=p.stat().st_size)
    publish_runtime(B/'runtime_manifest.json',dict(created_unix=time.time(),files=files,host=config['host'],model='E0-teacher10-5ep',hf_revision=receipt['revision'],inherited_manifest=str(old/'runtime_manifest.json')))
    evidence=dict(passed=True,verified_unix=time.time(),native_code_files=len(source),inherited_files=len(inherited['files']),e0_adapter_difference='Strict teacher-epoch10/student-epoch5 guard and flat_k2_n2 mapping only',checkpoint_sha256=config['checkpoint_sha256'])
    (B/'source_check.json').write_text(json.dumps(evidence,indent=2));print(json.dumps(evidence),flush=True)
if __name__=='__main__':freeze()
