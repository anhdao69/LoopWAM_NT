"""Check the exact new release and its frozen epoch-10 teacher on CPU."""
import hashlib,json,time
from pathlib import Path
import torch
from experiments.robotwin.loopwam_policy.elastic_inference import validate_elastic_release
B=Path(__file__).resolve().parent.parent
torch.set_num_threads(2)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for c in iter(lambda:f.read(8*1024*1024),b''):h.update(c)
 return h.hexdigest()
config=json.loads((B/'host_config.json').read_text());checkpoint=B/'checkpoint/epoch_05.pt'
assert sha(checkpoint)==config['checkpoint_sha256']
receipt=json.loads((B/'download_receipt.json').read_text())
for item in receipt['files']:
 p=B/'checkpoint'/Path(item['path']).name
 assert p.stat().st_size==item['size'] and sha(p)==item['sha256'],str(p)
b=torch.load(checkpoint,map_location='cpu',mmap=True,weights_only=False);validate_elastic_release(b,237310)
assert b['transport_config']['end_prefix']==24 and b['transport_config']['gripper_loss'] is False
assert b['transport_config']['regime']=='fu' and b['transport_config']['anchor']
assert not b['transport']
stats=json.loads((B/'checkpoint/dataset_stats.json').read_text());canonical=hashlib.sha256(json.dumps(stats,sort_keys=True).encode()).hexdigest()
assert canonical==b['training_state']['contract']['normalization_sha256']=='38ed9c8d466356fb8f4688da470b14a036dbc51e0fc5484cc5959b507adbcd48'
assert stats==json.loads((Path(config['predecessor'])/'checkpoint/dataset_stats.json').read_text())
for key in ['mot','proprio_encoder','student_action','step_condition','transport']:
 assert all(v.dtype==torch.float32 and torch.isfinite(v).all() for v in b[key].values() if v.is_floating_point()),key
for k,v in b['student_action'].items():assert torch.equal(v,b['mot']['mixtures.action.'+k]),k
teacher_sha='70cf5af73db5fe582c50c5f9fb68296d5271a9c0fea51509b3cdb5f9696be1ea';teacher=config.get('teacher_checkpoint')
if teacher:
 assert sha(teacher)==teacher_sha
 a=torch.load(teacher,map_location='cpu',mmap=True,weights_only=False);assert a['step']==474620;frozen=0
 for k,v in a['mot'].items():
  if not k.startswith('mixtures.action.'):
   assert torch.equal(v,b['mot'][k]),k;frozen+=1
 for k,v in a['proprio_encoder'].items():assert torch.equal(v,b['proprio_encoder'][k]),k;frozen+=1
 assert frozen==341
else:
 ref=json.loads((B/'teacher_reference_validation.json').read_text())
 assert ref['passed'] and ref['checkpoint_sha256']==config['checkpoint_sha256'] and ref['teacher_sha256']==teacher_sha
 assert ref['frozen_tensors_equal_teacher']==341;frozen=ref['frozen_tensors_equal_teacher']
r=dict(passed=True,checked_unix=time.time(),checkpoint_sha256=config['checkpoint_sha256'],step=237310,epoch=5,parent_step=474620,teacher_sha256=teacher_sha,transport_kind='T0',frozen_tensors_equal_teacher=frozen,frozen_video_tensors=339,frozen_proprio_tensors=2,normalization_equal=True,normalization_sha256=canonical,fp32_finite_weights=True,student_equals_export_mot=True,teacher_validation='direct tensor comparison' if teacher else 'same-checkpoint SHA256 and local tensor-comparison receipt')
(B/'cpu_validation.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
