"""Native release validation and bit-exact graph gate on actual simulator inputs."""
import gc, hashlib, json, time
from pathlib import Path
import torch
from experiments.robotwin.loopwam_policy.elastic_inference import RobotElasticInference, SCHEDULES
B=Path(__file__).resolve().parent.parent
VAE=B/'repo/checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth'
torch.set_num_threads(2)
paths=sorted((B/'gate_inputs').glob('*.pt'))[:8]
assert len(paths)==8
model=RobotElasticInference(B/'checkpoint/epoch_05.pt',VAE,'flat_k1_n2')
p=model.payload;policy=model.policy
assert p['format_version']=='loopwam-s-robot-rt-v1' and p['step']==237310
assert p['training_state']['epoch']==5 and p['training_state']['parent_step']==474620
assert p['transport_config']['kind']=='T0' and p['transport_config']['step_cond']
assert p['transport_config']['dataset']=='robotwin50' and p['transport_config']['scope']=='pc'
assert policy.parent.proprio_dim==14 and policy.student.mixtures['action'].action_dim==14
stats=json.loads((B/'checkpoint/dataset_stats.json').read_text())
assert hashlib.sha256(json.dumps(stats,sort_keys=True).encode()).hexdigest()==p['training_state']['contract']['normalization_sha256']
for module,state in [(policy.parent.mot,p['mot']),(policy.parent.proprio_encoder,p['proprio_encoder']),
                     (policy.student.mixtures['action'],p['student_action']),(policy.transport,p['transport']),
                     (policy.step_condition,p['step_condition'])]:
    actual=module.state_dict();assert actual.keys()==state.keys()
    for key,value in state.items():assert torch.equal(actual[key].cpu(),value),key
assert all(torch.equal(p['mot']['mixtures.action.'+key],v) for key,v in p['student_action'].items())
assert all(v.dtype==torch.float32 for key in ['mot','proprio_encoder','student_action','step_condition'] for v in p[key].values() if v.is_floating_point())
report=dict(checkpoint_sha256=hashlib.sha256((B/'checkpoint/epoch_05.pt').read_bytes()).hexdigest(),
            strict_load=True,loaded_tensors_bit_equal=True,step=237310,parent_step=474620,
            normalization_verified=True,inputs=[dict(path=str(x),sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in paths],schedules={})
del model.payload,p
inputs=[torch.load(x,map_location='cpu',weights_only=False) for x in paths]
for i,kw in enumerate(inputs):kw.update(seed=42+i%3,compile_action_infer=False)
def predict(kw):
    with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
        return model.infer_action(**kw)['action'].clone()
references={}
for name in ['flat_k1_n2','flat_k2_n2']:
    depths=SCHEDULES[name]
    model.schedule=name;model.graph=None
    for kw in inputs:kw['num_inference_steps']=len(depths)
    predict(inputs[0]);torch.cuda.synchronize();start=time.perf_counter()
    native=[predict(kw) for kw in inputs]
    references[name]=native
    eager_s=(time.perf_counter()-start)/len(inputs)
    # Record the actual native calls, including the trained step conditioning.
    seen=[];original=policy.velocity
    def record(*args,**kw):
        seen.append(dict(loops=kw['loops'],d=kw['d'],t=kw['native_timestep'].detach().cpu().tolist()))
        return original(*args,**kw)
    policy.velocity=record;predict(inputs[0]);policy.velocity=original
    assert [x['loops'] for x in seen]==list(depths)
    assert all(x['d']==1/len(depths) for x in seen)
    model.enable_graph()
    for i in list(range(8))+list(reversed(range(8))):
        torch.testing.assert_close(predict(inputs[i]),native[i],atol=0,rtol=0)
    start=time.perf_counter()
    for kw in inputs:predict(kw)
    result=dict(graph_passed=True,max_abs_difference=0,nfe=len(depths),action_loops=list(depths),
                native_calls=seen,native_query_seconds=eager_s,graph_query_seconds=(time.perf_counter()-start)/8,
                peak_reserved_mib=torch.cuda.max_memory_reserved()/2**20)
    report['schedules'][name]=result
    (B/'graph_gate.json').write_text(json.dumps(report,indent=2))
    print(name,json.dumps(result),flush=True)
    model.graph=None;gc.collect();torch.cuda.empty_cache();torch.cuda.reset_peak_memory_stats()
torch.save(references,B/'native_reference.pt')
report.update(passed=True,verified_unix=time.time())
(B/'graph_gate.json').write_text(json.dumps(report,indent=2))
