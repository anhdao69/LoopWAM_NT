"""Audit every scored video, seed, action trace and bound file before final SR."""
import concurrent.futures, csv, importlib.util, json, shutil, time
from pathlib import Path
from verify_runtime import B,W,R,sha,verify
from prerequisites import validate_run_contract
def excluded_attempts(results,finished):
    from report import EPISODE
    accepted={str(Path(c['directory']).resolve()) for c in finished.values()}
    out=[]
    for directory in sorted(Path(results).glob('*/attempt_*')):
        if not directory.is_dir() or str(directory.resolve()) in accepted:continue
        failure=directory/'failure.json';log=directory/'eval.log'
        record=json.loads(failure.read_text()) if failure.exists() else dict(status='interrupted_or_unaccepted',error='Attempt was not accepted as a complete scored cell')
        count=len(EPISODE.findall(log.read_text(errors='replace'))) if log.exists() else 0
        out.append(dict(record,path=str(directory),episodes=count))
    return out

def finalize(name):
    run=B/'runs'/name;dest=R/name;dest.mkdir(exist_ok=True)
    c=json.loads((run/'results/COMPLETE.json').read_text());p=json.loads((run/'results/manifest.json').read_text())
    validate_run_contract(B,name,p)
    spec=importlib.util.spec_from_file_location('eval_frozen',W/'scripts/evaluate_loopwam_robotwin.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    mod.validate_eval_summary(c,p['checkpoint_sha256'],p['tasks'],100)
    assert len(p['tasks'])==50 and len(c['finished'])==100 and not c.get('failed') and not c.get('running')
    assert p['elastic_schedule']==name and p['seed']==42 and p['episodes']==100
    assert sha(p['checkpoint'])==p['checkpoint_sha256']
    verify(json.loads((B/'runtime_manifest.json').read_text())['files'])
    for path,expected in p['runtime_hashes'].items():assert sha(path)==expected,path
    def check(item):
        key,cell=item;records=mod.completed_records(Path(cell['directory']),cell['config'],100)
        assert records==cell['episodes'],key
        assert cell['successes']==sum(x['success'] for x in records)
        assert json.loads((Path(cell['directory']).parent/'result.json').read_text())==cell
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(check,c['finished'].items()))
    rows=[];episodes=[];totals={}
    for task in p['tasks']:
        for setting in p['settings']:
            cell=c['finished'][f'{task}/{setting}']
            rows.append(dict(task=task,setting=setting,successes=cell['successes'],episodes=100,sr_percent=cell['successes'],seconds=cell['seconds'],accepted_attempt=Path(cell['directory']).name))
            episodes.extend(dict(task=task,setting=setting,episode_index=i,**e) for i,e in enumerate(cell['episodes']))
    for setting in p['settings']:
        success=sum(x['successes'] for x in rows if x['setting']==setting)
        totals[setting]=dict(successes=success,episodes=5000,sr_percent=success/50)
        assert c['success_rates'][setting]==success/5000
    success=sum(x['successes'] for x in rows);totals['combined']=dict(successes=success,episodes=10000,sr_percent=success/100)
    assert len(episodes)==10000
    for filename,data in [('task_results.csv',rows),('episodes.csv',episodes)]:
        with (dest/filename).open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)
    failures=excluded_attempts(run/'results',c['finished'])
    audit=dict(status='passed',verified_pairs=100,verified_videos=10000,renderer_logs_clean=True,
               checkpoint_sha256=p['checkpoint_sha256'],complete_sha256=sha(run/'results/COMPLETE.json'),
               audited_unix=time.time(),failed_attempts=len(failures),excluded_partial_episodes=sum(x['episodes'] for x in failures))
    for folder in [run,dest]:
        (folder/'final_audit.json').write_text(json.dumps(audit,indent=2))
        (folder/'final_results.json').write_text(json.dumps(dict(totals=totals,tasks=rows),indent=2))
    (dest/'failed_attempts.json').write_text(json.dumps(failures,indent=2))
    for filename in ['COMPLETE.json','manifest.json']:shutil.copy2(run/'results'/filename,dest/filename)
    lines=[f'# Elastic E0 teacher epoch10 / student 5ep — {name} — final full RoboTwin results','',
           '| Setting | Successes / episodes | SR |','| --- | ---: | ---: |']
    for setting,t in totals.items():lines.append(f"| {setting} | {t['successes']}/{t['episodes']} | {t['sr_percent']:.2f}% |")
    lines+=['','| Task | Clean / 100 | Randomized / 100 | Combined SR |','| --- | ---: | ---: | ---: |']
    for task in p['tasks']:
        a=c['finished'][f'{task}/demo_clean']['successes'];b=c['finished'][f'{task}/demo_randomized']['successes']
        lines.append(f'| {task} | {a} | {b} | {(a+b)/2:.2f}% |')
    lines+=['',f"Seed42; action depths{p['action_depths']}; NFE{p['num_inference_steps']}; four video loops; predict32/execute24. Smoke episodes excluded. All 10,000 videos, accepted episode records, scene seeds, instructions, action hashes and frozen runtime files verified.",
            '',f"Failed attempts: {len(failures)}. Logged partial episodes excluded: {audit['excluded_partial_episodes']}.",
            '', 'See [campaign protocol](../report.md), [task results](task_results.csv), [episode records](episodes.csv), [audit](final_audit.json), and [manifest](manifest.json). Instruction-template generation is unseeded as in prior runs; these are not guaranteed identical paired rollouts across models.','']
    (dest/'final_report.md').write_text('\n'.join(lines))
    return totals
