"""Mirror both host reports and publish new E0 progress without touching evaluators."""
import datetime,fcntl,json,subprocess,time,traceback
from pathlib import Path
B=Path(__file__).resolve().parent.parent
R=Path('/storage/anhdh35/LoopWAM_NT/evaluation_report/robotwin_elastic_e0_teacher10_5ep_20261111')
E0=Path('/storage/anhdh35/LoopWAM_NT/evaluation_report/robotwin_elastic_e0_20261107')
REMOTE='/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_teacher10_5ep_20261111/report/'
def read(p):
    try:return json.loads(p.read_text())
    except (FileNotFoundError,json.JSONDecodeError):return {}
def write(p,data):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2));tmp.replace(p)
def main():
    lock=(B/'sync.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for name in ['local','remote137']:(R/name).mkdir(parents=True,exist_ok=True)
    while True:
        sync=dict(checked_unix=time.time(),ok=False)
        try:
            subprocess.run(['rsync','-a',str(B/'report')+'/',str(R/'local')+'/'],check=True,timeout=45)
            p=subprocess.run(['rsync','-a','--timeout=30','-e','ssh -S /tmp/loopwam-remote-20261104/control -o BatchMode=yes -o ConnectTimeout=8','anhdh35@10.148.182.137:'+REMOTE,str(R/'remote137')+'/'],capture_output=True,text=True,timeout=45)
            sync.update(ok=p.returncode==0,error=p.stderr[-1200:] if p.returncode else None)
        except Exception:sync['error']=traceback.format_exc()
        hosts={h:read(R/h/'current_results.json') for h in ['local','remote137']};rows=[]
        for name,host in [('flat_k1_n2','local'),('flat_k2_n2','remote137')]:
            data=hosts[host];row=next((x for x in data.get('runs',[]) if x['schedule']==name),dict(schedule=name,status='preparing',totals={},verified_cells=0,audit={}))
            offset=read(B/'sync_config.json').get('remote_clock_offset_seconds',0) if host=='remote137' else 0
            age=max(0,time.time()-data['updated_unix']-offset) if data.get('updated_unix') else None
            baseline=read(E0/name/'final_results.json')
            row.update(host=host,queue=data.get('queue',{}),snapshot_age_seconds=age,stale=not row.get('audit') and (age is None or age>180),e0_final=baseline.get('totals',{}).get('combined'))
            rows.append(row)
        stamp=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).isoformat(timespec='seconds')
        lines=['# Elastic E0 teacher epoch10 / student five epochs — full RoboTwin evaluation','',f'Updated {stamp}.','','| Schedule | Host | Stage | Successes / episodes | Live SR | E0 final SR |','| --- | --- | --- | ---: | ---: | ---: |']
        labels={'flat_k1_n2':'[1,1] / NFE 2','flat_k2_n2':'[2,2] / NFE 2','flat_k4_n5':'[4]×5 / NFE 5'}
        for row in rows:
            t=row['totals'].get('combined',{});sr=t.get('sr_percent');baseline=row.get('e0_final');status=row['status'] if row['status']!='queued' else row['queue'].get('stage','queued')
            if row['stale']:status+='; stale snapshot'
            lines.append(f"| {labels[row['schedule']]} | {row['host']} | {status} | {t.get('successes',0)}/{t.get('episodes',0)} | {f'{sr:.2f}%' if sr is not None else '—'} | {str(round(baseline['sr_percent'],2))+'%' if baseline else 'pending'} |")
        lines += ['','New E0 queue: local RTX PRO6000=[1,1]; server137 RTX PRO6000=[2,2]. Both use NFE2 and four simulator workers, shared T5 and CUDA graphs. Each host waits for at least60000MiB free. Native/graph parity, cross-host parity and a four-worker smoke test must pass before scored evaluation. Other workloads remain untouched.','','Full 50 tasks × clean/randomized × 100 episodes = 10,000 total; seed42. Four video loops, native T0 (no transport), FP32 policy weights/BF16 compute, predict32/execute24, original normalization/cameras/scene admission/horizons and RT32/depth8 rendering.','','Live SR includes completed episodes in active attempts and is provisional. Partial new E0 SR must not be compared directly with the older E0 score until task coverage matches. Final scores require full video/trace/runtime audits. Python instruction selection remains unseeded as in E0, so exact scene/instruction pairing is not promised.','',f"Remote report transfer: {'successful' if sync['ok'] else 'pending/failed'}. Remote snapshot age: {rows[1]['snapshot_age_seconds']} seconds; snapshots older than180seconds are flagged.",'','[Detailed setup and fairness report](setup_report.md) · [Server137](remote137/report.md) · [Machine-readable progress](current_results.json)','']
        (R/'report.md').write_text('\n'.join(lines));write(R/'current_results.json',dict(updated_unix=time.time(),runs=rows,sync=sync));write(B/'sync_status.json',sync)
        if all(row.get('audit',{}).get('status')=='passed' for row in rows) and sync['ok']:break
        time.sleep(60)
if __name__=='__main__':main()
