"""Real-observation native/graph checks and historical K4 compatibility."""
import argparse,json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.v0_ka_common import *

def main(args):
    import numpy as np,torch
    from fastwam.models.wan22.loopwam import create_loopwam
    from scripts.evaluate_loopwam_libero import ObservationAdapter
    torch.set_num_threads(2);torch.cuda.set_device(0)
    old=module('ka_gate_reference',OLD/'scripts/evaluate_matched_full41.py')
    model=create_loopwam(checkpoint_path=str(CHECKPOINT/'policy.pt'),vae_path=str(old.VAE),device='cuda:0',model_dtype=torch.float32).eval()
    ip=BULK/'gate_inputs.pt'
    if not ip.exists():
        if args.legacy:raise ValueError('Prepare inputs using current code first')
        from libero.libero import benchmark
        from experiments.libero.libero_utils import get_libero_env
        adapter=ObservationAdapter(json.loads((CHECKPOINT/'dataset_stats.json').read_text()),OLD/'data/matched_text')
        inputs=[]
        for suite_name in SUITES:
            suite=benchmark.get_benchmark_dict()[suite_name]();task=suite.get_task(0);states=suite.get_task_init_states(0)
            env,_=get_libero_env(task,256,42)
            try:
                for ep in [0,1]:
                    env.reset();obs=env.set_init_state(states[ep])
                    for _ in range(30):obs,_,_,_=env.step([0.,0.,0.,0.,0.,0.,-1.])
                    image,state=adapter.observation(obs);context,mask=adapter.text(task.language)
                    inputs.append(dict(input_image=image,proprio=state,context=context,context_mask=mask,action_horizon=32,num_inference_steps=10,
                        text_cfg_scale=1.,seed=42+len(inputs)%3,rand_device='cpu',compile_action_infer=False))
            finally:env.close()
        torch.save(inputs,ip)
    inputs=torch.load(ip,weights_only=False)
    def predict(kw):
        with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
            result=model.infer_action(**kw)['action'].float().cpu().clone()
        if result.shape!=(32,7) or not torch.isfinite(result).all():raise ValueError('Invalid native action')
        return result
    if args.legacy:
        torch.save([predict(kw) for kw in inputs],BULK/'legacy_k4_actions.pt');return
    model.mot.set_inference_action_loops(args.ka)
    start=time.perf_counter();native=[predict(kw) for kw in inputs];native_s=(time.perf_counter()-start)/len(inputs)
    if args.prepare:
        torch.save(native,BULK/'current_k4_actions.pt');return
    if args.ka==4:
        legacy=torch.load(BULK/'legacy_k4_actions.pt',weights_only=False)
        for x,y in zip(native,legacy):torch.testing.assert_close(x,y,atol=0,rtol=0)
    report=dict(ka=args.ka,video_loops=4,trained_ka=4,nfe=10,checkpoint_sha256=DIGEST,inputs_sha256=sha(ip),
                native_finite=True,native_query_seconds=native_s,graph_passed=False,source=source_hashes())
    try:
        module('ka_gate_graph',OLD/'scripts/matched_cuda_graph.py').enable_graphs(model)
        differences=[]
        for i in list(range(len(inputs)))+list(reversed(range(len(inputs)))):
            actual=predict(inputs[i]);differences.append((actual-native[i]).abs().max().item())
            torch.testing.assert_close(actual,native[i],atol=0,rtol=0)
        start=time.perf_counter()
        for kw in inputs:predict(kw)
        report.update(graph_passed=True,max_abs_difference=max(differences),graph_query_seconds=(time.perf_counter()-start)/len(inputs))
    except Exception as e:report['graph_error']=repr(e)
    report['peak_reserved_mib']=torch.cuda.max_memory_reserved()/2**20
    write(BULK/f'gate_ka{args.ka}.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='source'},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--ka',type=int,required=True,choices=range(1,7));p.add_argument('--legacy',action='store_true');p.add_argument('--prepare',action='store_true')
    main(p.parse_args())
