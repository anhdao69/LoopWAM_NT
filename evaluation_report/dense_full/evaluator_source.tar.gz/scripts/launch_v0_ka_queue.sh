#!/usr/bin/env bash
set -euo pipefail
cd /storage/anhdh35/LoopWAM-v0-ka-eval
exec /storage/anhdh35/miniconda3/envs/loopwam-libero-eval/bin/python - <<'PY'
import os
from scripts.v0_ka_common import environment,PYTHON,ROOT
os.execve(PYTHON,[PYTHON,str(ROOT/'scripts/v0_ka_queue.py')],environment())
PY
