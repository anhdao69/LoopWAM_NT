"""Append two Dense models after the pinned five-condition v0 sweep."""
import fcntl,json,os,signal,subprocess,time,traceback
from pathlib import Path
from scripts.dense_common import CAMPAIGN,ROOT,PYTHON,environment,write,sha
PREDECESSOR=Path('/data14t/anhdh35/loopwam_v0_ka_sweep_20261027')
REPORT=Path('/storage/anhdh35/LoopWAM_NT/evaluation_report/dense_full')
V0_SHA='1c659a7c2f6970c3ea5972a8fba4abd9db35857c83a67a053c0ee35555fb602b'

def predecessor_ready(state):
    jobs=state.get('jobs',[])
    return (bool(state.get('finished_unix')) and not state.get('active') and not state.get('error')
        and [j.get('ka') for j in jobs]==[1,2,3,5,6]
        and all(j.get('status')=='complete' and j.get('summary',{}).get('episodes')==6000
            and j['summary'].get('checkpoint_sha256')==V0_SHA and j['summary'].get('action_loops')==j['ka'] for j in jobs))

def publish(state):
    state['updated_unix']=time.time();write(CAMPAIGN/'chain_status.json',state);write(REPORT/'queue_status.json',state)
    lines=['# Full-suite Dense evaluation queue','',f"Queue status: **{state['status']}**.",'',
        'Order: v0 Ka1 → Ka2 → Ka3 → Ka5 → Ka6 → Dense-S12 → Dense-S30.','',
        'NFE10; seeds42/43/44; Spatial/Object/Goal/Long; 50 episodes/task/seed; 6,000/model (12,000 new episodes).','',
        '| Model | Status | Episodes | Successes | SR |','| --- | --- | --- | --- | --- |']
    for job in state['jobs']:
        detail=job.get('detail',{}).get('jobs',[{}])[0]
        progress=job.get('summary',detail.get('summary',detail.get('progress',{}) if detail.get('stage')=='scored' else {}))
        n=progress.get('episodes',progress.get('completed',0));ok=progress.get('successes',0)
        rate=f'{100*ok/n:.2f}%' if n else 'pending'
        lines.append(f"| {job['model']} | {detail.get('status',job['status'])} | {n}/6000 | {ok} | {rate} |")
    lines+=['','Calibration is excluded. Partial SR is provisional. GPU checks and speed calibration start only after v0 finishes.',
        '[Detailed setup](setup_report.md) · [Live machine-readable status](queue_status.json)',
        '[Dense-S12 report](dense-s12/report.md) · [Dense-S30 report](dense-s30/report.md)']
    target=REPORT/'report.md';tmp=target.with_suffix('.md.tmp');tmp.write_text('\n'.join(lines)+'\n');tmp.replace(target)


def main():
    def terminate(signum,frame):raise SystemExit(128+signum)
    signal.signal(signal.SIGTERM,terminate)
    CAMPAIGN.mkdir(parents=True,exist_ok=True);REPORT.mkdir(parents=True,exist_ok=True)
    lock=(CAMPAIGN/'chain.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    state=dict(status='waiting_for_v0',order=['v0_Ka1','v0_Ka2','v0_Ka3','v0_Ka5','v0_Ka6','dense-s12','dense-s30'],
        started_unix=time.time(),jobs=[dict(model=m,status='pending',episodes=6000) for m in ['dense-s12','dense-s30']])
    publish(state)
    try:
        # Lock remains held until Dense completes, preventing the predecessor from restarting alongside us.
        predecessor_lock=None
        while predecessor_lock is None:
            path=PREDECESSOR/'queue_state.json'
            previous=json.loads(path.read_text()) if path.exists() else {}
            state['predecessor_status']='error' if previous.get('error') else 'running_or_pending'
            if predecessor_ready(previous):
                candidate=(PREDECESSOR/'queue.lock').open('a')
                try:fcntl.flock(candidate,fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError:candidate.close()
                else:
                    if predecessor_ready(json.loads(path.read_text())):
                        predecessor_lock=candidate;break
                    candidate.close()
            publish(state);time.sleep(30)
        # Verify completed predecessor artifacts independently of its queue status.
        expected=json.loads((PREDECESSOR/'frozen.json').read_text())['checkpoint_sha256']
        if expected!=V0_SHA:raise ValueError('Wrong predecessor checkpoint')
        for k in [1,2,3,5,6]:
            summary=json.loads((PREDECESSOR/f'results/ka{k}/summary.json').read_text())
            if summary['episodes']!=6000 or summary['checkpoint_sha256']!=V0_SHA or summary['action_loops']!=k:
                raise ValueError('Predecessor result mismatch')
        state['status']='running';publish(state)
        for job in state['jobs']:
            job.update(status='running',started_unix=time.time());publish(state)
            env=environment();env['DENSE_MODEL']=job['model']
            inherited_locks=(lock.fileno(),predecessor_lock.fileno())
            env['DENSE_LOCK_FDS']=','.join(map(str,inherited_locks))
            with (CAMPAIGN/(job['model']+'_controller.log')).open('a') as log:
                result=subprocess.Popen([PYTHON,'-m','scripts.dense_queue'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,
                    start_new_session=True,pass_fds=inherited_locks)
                state['active_pid']=result.pid;publish(state)
                try:
                    while result.poll() is None:
                        progress_path=CAMPAIGN/job['model']/'queue_state.json'
                        if progress_path.exists():job['detail']=json.loads(progress_path.read_text())
                        publish(state);time.sleep(10)
                except BaseException:
                    if result.poll() is None:
                        os.killpg(result.pid,signal.SIGTERM);result.wait(timeout=120)
                    raise
                finally:state['active_pid']=None
            if result.returncode:raise RuntimeError(f"{job['model']} stopped; inspect controller log")
            summary=json.loads((CAMPAIGN/job['model']/'results/ka1/summary.json').read_text())
            if summary['episodes']!=6000:raise ValueError('Incomplete Dense result')
            job.update(status='complete',summary=summary,finished_unix=time.time());publish(state)
        state.update(status='complete',finished_unix=time.time());publish(state)
    except BaseException:
        state.update(status='error',error=traceback.format_exc());publish(state);raise

if __name__=='__main__':main()
