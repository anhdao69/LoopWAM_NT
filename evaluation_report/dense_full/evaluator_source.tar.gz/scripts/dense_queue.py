"""Detached, locked, serial queue; fail closed on scientific/provenance errors."""
import csv,fcntl,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.dense_common import *

def refresh(state):
    state['model']=MODEL;state['updated_unix']=time.time()
    write(BULK/'queue_state.json',state);write(REPORT/'queue_status.json',state)
    lines=[f'# {MODEL}: full-suite evaluation','',
        'Native Dense architecture (one pass); NFE10; seeds42/43/44; four suites × ten tasks × 50 episodes/seed = 6,000 scored episodes.','',
        '| Status | Stage | Episodes | Successes | SR | Backend/workers |','| --- | --- | --- | --- | --- | --- |']
    for j in state['jobs']:
        progress=j.get('summary',j.get('progress',{}) if j.get('stage')=='scored' else {})
        n=progress.get('episodes',progress.get('completed',0));ok=progress.get('successes',0);chosen=j.get('selected',{})
        rate=f'{100*ok/n:.2f}%' if n else 'pending'
        lines.append(f"| {j['status']} | {j.get('stage','pending')} | {n}/6000 | {ok} | {rate} | {chosen.get('backend','pending')}/{chosen.get('workers','pending')} |")
    lines+=['','Calibration is excluded from SR. Partial SR is provisional. Errors stop this queue.',
        '[Frozen protocol](protocol.json) · [Queue state](queue_status.json)',f'Bulk artifacts: `{BULK}`.',
        'Every scored episode retains a video and hashed action-query trace. Resume replays incomplete task/seed groups to preserve RNG.']
    (REPORT/'report.md').write_text('\n'.join(lines)+'\n')

def execute(command,log,state,job=None,env=None):
    log=Path(log);log.parent.mkdir(parents=True,exist_ok=True)
    with log.open('a') as stream:
        proc=subprocess.Popen(command,env=env or environment(),stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,cwd=ROOT,pass_fds=tuple(int(x) for x in os.environ.get('DENSE_LOCK_FDS','').split(',') if x))
    state['active']=dict(pid=proc.pid,command=command,log=str(log));refresh(state)
    try:
        while proc.poll() is None:
            if job and job.get('current_output'):
                progress=Path(job['current_output'])/'progress.json'
                if progress.exists():job['progress']=json.loads(progress.read_text())
            refresh(state);time.sleep(10)
        if proc.returncode:raise RuntimeError(f'Command failed ({proc.returncode}); see {log}')
    except BaseException:
        try:os.killpg(proc.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        if proc.poll() is None:proc.wait(timeout=60)
        raise
    state['active']=None;refresh(state)

def run_profile(job,backend,workers,state):
    out=BULK/'calibration'/f"ka{job['ka']}"/f'{backend}_w{workers}'
    if (out/'manifest.json').exists() and not (out/'summary.json').exists():
        out.rename(out.with_name(out.name+f'.interrupted_{time.time_ns()}'))
    job.update(stage='calibration',current_output=str(out));refresh(state)
    if not (out/'summary.json').exists():
        execute([PYTHON,'-m','scripts.dense_runner','--ka',str(job['ka']),'--backend',backend,'--workers',str(workers),'--output',str(out),'--calibration'],out/'run.log',state,job)
    result=json.loads((out/'summary.json').read_text())
    if result['episodes']!=16 or result['checkpoint_sha256']!=DIGEST or result['action_loops']!=job['ka']:raise ValueError('Bad calibration identity')
    manifest=json.loads((out/'manifest.json').read_text())
    if (manifest['frozen_sha256']!=sha(BULK/'frozen.json') or manifest['backend']!=backend or manifest['workers']!=workers
        or manifest['action_loops']!=job['ka'] or manifest['mode']!='calibration'):raise ValueError('Cached calibration provenance mismatch')
    from scripts.dense_runner import load_rows
    rows,_=load_rows(out,groups(True),job['ka']);validate_rows(groups(True),rows,DIGEST,job['ka'])
    if trace_signature(rows)!=result['signature']:raise ValueError('Cached calibration signature mismatch')
    return {**result,'output':str(out)}

def main():
    def terminate(signum,frame):raise SystemExit(128+signum)
    signal.signal(signal.SIGTERM,terminate)
    BULK.mkdir(parents=True,exist_ok=True);REPORT.mkdir(parents=True,exist_ok=True)
    lock=(BULK/'queue.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    os.environ['DENSE_LOCK_FDS']=','.join(filter(None,[os.environ.get('DENSE_LOCK_FDS',''),str(lock.fileno())]))
    for p in Path('/proc').iterdir():
        try:
            cmd=(p/'cmdline').read_bytes().split(b'\0')
            if b'scripts.dense_runner' in cmd:raise RuntimeError('Unmanaged existing runner; reconcile before resume')
        except (FileNotFoundError,PermissionError,NotADirectoryError):pass
    state=json.loads((BULK/'queue_state.json').read_text()) if (BULK/'queue_state.json').exists() else dict(started_unix=time.time(),jobs=[dict(ka=k,status='pending') for k in DEPTHS],active=None)
    state.pop('error',None);refresh(state)
    try:
        if not (BULK/'frozen.json').exists():freeze_inputs()
        frozen=json.loads((BULK/'frozen.json').read_text())
        if source_hashes()!=frozen['source']:raise ValueError('Frozen source changed')
        for job in state['jobs']:
            if job['status']=='complete':continue
            scored_output=BULK/'results'/f"ka{job['ka']}"
            if (scored_output/'manifest.json').exists():
                selected=job.get('selected')
                previous=json.loads((scored_output/'manifest.json').read_text())
                if (not selected or previous['backend']!=selected['backend'] or previous['workers']!=selected['workers']
                    or previous['frozen_sha256']!=sha(BULK/'frozen.json')):raise ValueError('Scored resume requires pinned backend/workers/provenance')
                job.update(status='running',stage='scored',current_output=str(scored_output));refresh(state)
                execute([PYTHON,'-m','scripts.dense_runner','--ka',str(job['ka']),'--backend',selected['backend'],'--workers',str(selected['workers']),'--output',str(scored_output)],scored_output/'run.log',state,job)
                summary=json.loads((scored_output/'summary.json').read_text())
                if summary['episodes']!=6000:raise ValueError('Incomplete resumed job')
                job.update(status='complete',summary=summary,finished_unix=time.time());refresh(state);continue
            job.update(status='calibrating',stage='gate',started_unix=job.get('started_unix',time.time()));refresh(state)
            gate_path=BULK/f"gate_ka{job['ka']}.json"
            if not gate_path.exists():execute([PYTHON,str(ROOT/'scripts/dense_gate.py'),'--ka',str(job['ka'])],BULK/f"gate_ka{job['ka']}.log",state,job)
            gate=json.loads(gate_path.read_text())
            validate_gate(gate,frozen)
            free=int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
            if 2*(gate['peak_reserved_mib']+768)*1.15+2048>free:raise RuntimeError('Insufficient VRAM for native two-worker reference; retry when memory is free')
            profiles=[run_profile(job,'eager',2,state)]
            for backend in (['eager','cuda-graph'] if gate['graph_passed'] else ['eager']):
                for workers in ([4,8] if backend=='eager' else [2,4,8]):
                    free=int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
                    if workers*(gate['peak_reserved_mib']+768)*1.15+2048>free:
                        profiles.append(dict(backend=backend,workers=workers,skipped='VRAM headroom'));continue
                    try:profiles.append(run_profile(job,backend,workers,state))
                    except Exception:profiles.append(dict(backend=backend,workers=workers,error=traceback.format_exc()))
            job['profiles']=profiles;selected=choose_profile(profiles);job['selected']=selected
            job.update(status='running',stage='scored',current_output=str(BULK/'results'/f"ka{job['ka']}"));refresh(state)
            execute([PYTHON,'-m','scripts.dense_runner','--ka',str(job['ka']),'--backend',selected['backend'],'--workers',str(selected['workers']),'--output',job['current_output']],Path(job['current_output'])/'run.log',state,job)
            summary=json.loads((Path(job['current_output'])/'summary.json').read_text())
            if summary['episodes']!=6000 or summary['action_loops']!=job['ka'] or summary['checkpoint_sha256']!=DIGEST:raise ValueError('Incomplete/wrong scored condition')
            job.update(status='complete',summary=summary,finished_unix=time.time());refresh(state)
        state['finished_unix']=time.time();refresh(state)
    except BaseException:
        state['error']=traceback.format_exc();state['active']=None
        for j in state['jobs']:
            if j['status'] in ['running','calibrating']:j['status']='error'
        refresh(state);raise

if __name__=='__main__':main()
