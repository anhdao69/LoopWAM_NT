"""Detached, locked, serial queue; fail closed on scientific/provenance errors."""
import csv,fcntl,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.v0_ka_common import *

def refresh(state):
    state['updated_unix']=time.time();write(BULK/'queue_state.json',state);write(REPORT/'queue_status.json',state)
    lines=['# v0 trained-at-four action-depth evaluation','',
        'Same full-suite v0 checkpoint for every condition; Kv=4; NFE=10; seeds 42/43/44; four suites × ten tasks × 50 episodes/seed = 6,000 per condition. Queue order: Ka=1,2,3,5,6. Total: 30,000 new scored episodes.','',
        'Native late alignment maps action core loop r to video core loop max(1,4−Ka+r). Thus Ka=5 uses [1,1,2,3,4] and Ka=6 uses [1,1,1,2,3,4]. Checkpoint weights/trained-depth metadata remain unchanged.','',
        '| Ka | Status | Completed | Successes | SR | Backend/workers |','| --- | --- | --- | --- | --- | --- |']
    for j in state['jobs']:
        summary=j.get('summary',{});progress=j.get('progress',{}) if j.get('stage')=='scored' else {}
        n=summary.get('episodes',progress.get('completed',0));ok=summary.get('successes',progress.get('successes',0))
        rate=f'{100*ok/n:.2f}%' if n else '—';selected=j.get('selected',{})
        lines.append(f"| {j['ka']} | {j['status']} | {n}/6000 | {ok} | {rate} | {selected.get('backend','—')}/{selected.get('workers','—')} |")
    lines+=['','Calibration/smoke episodes are excluded. Partial SR is not a final estimate.','',
        'Previous K4 is a historical reference (5,695/6,000 = 94.9167%); native K4 real-observation compatibility must pass before this queue starts. K4 is not a sixth scored job.','',
        '[Protocol and frozen provenance](protocol.json) · [Queue state](queue_status.json) · [Preflight](preflight.json)','',
        f"Bulk logs, episodes, query traces and videos: `{BULK}`.",
        'Only completed task/seed groups are resumed; partial groups replay from episode 0 to preserve the RNG sequence. Model and environment processes are isolated; group seed set once, query seed fixed to that group seed. Settling30, predict32/execute10, caps400 (Long700). FP32 model/BF16 compute, original trained normalization and text cache, native gripper conversion.']
    (REPORT/'report.md').write_text('\n'.join(lines)+'\n')

def execute(command,log,state,job=None,env=None):
    log=Path(log);log.parent.mkdir(parents=True,exist_ok=True)
    with log.open('a') as stream:
        proc=subprocess.Popen(command,env=env or environment(),stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,cwd=ROOT)
    state['active']=dict(pid=proc.pid,command=command,log=str(log));refresh(state)
    try:
        while proc.poll() is None:
            if job and job.get('current_output'):
                progress=Path(job['current_output'])/'progress.json'
                if progress.exists():job['progress']=json.loads(progress.read_text())
            refresh(state);time.sleep(10)
        if proc.returncode:raise RuntimeError(f'Command failed ({proc.returncode}); see {log}')
    except BaseException:
        try:os.killpg(proc.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        if proc.poll() is None:proc.wait(timeout=60)
        raise
    state['active']=None;refresh(state)

def run_profile(job,backend,workers,state):
    out=BULK/'calibration'/f"ka{job['ka']}"/f'{backend}_w{workers}'
    if (out/'manifest.json').exists() and not (out/'summary.json').exists():
        out.rename(out.with_name(out.name+f'.interrupted_{time.time_ns()}'))
    job.update(stage='calibration',current_output=str(out));refresh(state)
    if not (out/'summary.json').exists():
        execute([PYTHON,'-m','scripts.v0_ka_runner','--ka',str(job['ka']),'--backend',backend,'--workers',str(workers),'--output',str(out),'--calibration'],out/'run.log',state,job)
    result=json.loads((out/'summary.json').read_text())
    if result['episodes']!=16 or result['checkpoint_sha256']!=DIGEST or result['action_loops']!=job['ka']:raise ValueError('Bad calibration identity')
    manifest=json.loads((out/'manifest.json').read_text())
    if (manifest['frozen_sha256']!=sha(BULK/'frozen.json') or manifest['backend']!=backend or manifest['workers']!=workers
        or manifest['action_loops']!=job['ka'] or manifest['mode']!='calibration'):raise ValueError('Cached calibration provenance mismatch')
    from scripts.v0_ka_runner import load_rows
    rows,_=load_rows(out,groups(True),job['ka']);validate_rows(groups(True),rows,DIGEST,job['ka'])
    if trace_signature(rows)!=result['signature']:raise ValueError('Cached calibration signature mismatch')
    return {**result,'output':str(out)}

def main():
    BULK.mkdir(parents=True,exist_ok=True);REPORT.mkdir(parents=True,exist_ok=True)
    lock=(BULK/'queue.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for p in Path('/proc').iterdir():
        try:
            cmd=(p/'cmdline').read_bytes().split(b'\0')
            if b'scripts.v0_ka_runner' in cmd:raise RuntimeError('Unmanaged existing runner; reconcile before resume')
        except (FileNotFoundError,PermissionError,NotADirectoryError):pass
    state=json.loads((BULK/'queue_state.json').read_text()) if (BULK/'queue_state.json').exists() else dict(started_unix=time.time(),jobs=[dict(ka=k,status='pending') for k in DEPTHS],active=None)
    state.pop('error',None);refresh(state)
    try:
        if not (BULK/'frozen.json').exists():freeze_inputs()
        frozen=json.loads((BULK/'frozen.json').read_text())
        if source_hashes()!=frozen['source']:raise ValueError('Frozen source changed')
        if not (BULK/'gate_ka4.json').exists():
            execute([PYTHON,str(ROOT/'scripts/v0_ka_gate.py'),'--ka','4','--prepare'],BULK/'prepare_inputs.log',state)
            env=environment();env['PYTHONPATH']=f'{OLD}/src:{OLD}:{LIGHT}/src:{LIGHT}:{LIGHT}/third_party/LIBERO'
            execute([PYTHON,str(ROOT/'scripts/v0_ka_gate.py'),'--ka','4','--legacy'],BULK/'legacy_k4.log',state,env=env)
            execute([PYTHON,str(ROOT/'scripts/v0_ka_gate.py'),'--ka','4'],BULK/'gate_ka4.log',state)
        gate=json.loads((BULK/'gate_ka4.json').read_text())
        if not gate['native_finite'] or gate['source']!=frozen['source']:raise ValueError('Invalid K4 gate')
        write(REPORT/'preflight.json',dict(k4_compatibility_passed=True,k4_gate=gate,checkpoint_sha256=DIGEST))
        for job in state['jobs']:
            if job['status']=='complete':continue
            scored_output=BULK/'results'/f"ka{job['ka']}"
            if (scored_output/'manifest.json').exists():
                selected=job.get('selected')
                previous=json.loads((scored_output/'manifest.json').read_text())
                if (not selected or previous['backend']!=selected['backend'] or previous['workers']!=selected['workers']
                    or previous['frozen_sha256']!=sha(BULK/'frozen.json')):raise ValueError('Scored resume requires pinned backend/workers/provenance')
                job.update(status='running',stage='scored',current_output=str(scored_output));refresh(state)
                execute([PYTHON,'-m','scripts.v0_ka_runner','--ka',str(job['ka']),'--backend',selected['backend'],'--workers',str(selected['workers']),'--output',str(scored_output)],scored_output/'run.log',state,job)
                summary=json.loads((scored_output/'summary.json').read_text())
                if summary['episodes']!=6000:raise ValueError('Incomplete resumed job')
                job.update(status='complete',summary=summary,finished_unix=time.time());refresh(state);continue
            job.update(status='calibrating',stage='gate',started_unix=job.get('started_unix',time.time()));refresh(state)
            gate_path=BULK/f"gate_ka{job['ka']}.json"
            if not gate_path.exists():execute([PYTHON,str(ROOT/'scripts/v0_ka_gate.py'),'--ka',str(job['ka'])],BULK/f"gate_ka{job['ka']}.log",state,job)
            gate=json.loads(gate_path.read_text())
            if gate['source']!=frozen['source'] or not gate['native_finite']:raise ValueError('Invalid depth gate')
            profiles=[run_profile(job,'eager',4,state)]
            if gate['graph_passed']:
                for workers in [4,8]:
                    free=int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
                    if workers*(gate['peak_reserved_mib']+768)*1.15+2048>free:
                        profiles.append(dict(backend='cuda-graph',workers=workers,skipped='VRAM headroom'));continue
                    try:profiles.append(run_profile(job,'cuda-graph',workers,state))
                    except Exception:profiles.append(dict(backend='cuda-graph',workers=workers,error=traceback.format_exc()))
            job['profiles']=profiles;selected=choose_profile(profiles);job['selected']=selected
            job.update(status='running',stage='scored',current_output=str(BULK/'results'/f"ka{job['ka']}"));refresh(state)
            execute([PYTHON,'-m','scripts.v0_ka_runner','--ka',str(job['ka']),'--backend',selected['backend'],'--workers',str(selected['workers']),'--output',job['current_output']],Path(job['current_output'])/'run.log',state,job)
            summary=json.loads((Path(job['current_output'])/'summary.json').read_text())
            if summary['episodes']!=6000 or summary['action_loops']!=job['ka'] or summary['checkpoint_sha256']!=DIGEST:raise ValueError('Incomplete/wrong scored condition')
            job.update(status='complete',summary=summary,finished_unix=time.time());refresh(state)
        state['finished_unix']=time.time();refresh(state)
    except BaseException:
        state['error']=traceback.format_exc();state['active']=None
        for j in state['jobs']:
            if j['status'] in ['running','calibrating']:j['status']='error'
        refresh(state);raise

if __name__=='__main__':main()
