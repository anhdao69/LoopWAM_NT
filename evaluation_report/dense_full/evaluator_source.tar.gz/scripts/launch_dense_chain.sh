#!/usr/bin/env bash
set -euo pipefail
cd /storage/anhdh35/LoopWAM-dense-eval
exec /storage/anhdh35/miniconda3/envs/loopwam-libero-eval/bin/python - <<'PY'
import os
from scripts.dense_common import environment,PYTHON
os.execve(PYTHON,[PYTHON,'-m','scripts.dense_chain'],environment())
PY
