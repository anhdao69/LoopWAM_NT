"""Frozen inputs and strict accounting for the trained-at-four v0 sweep."""
import hashlib, importlib.util, json, math, os
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OLD=Path('/storage/anhdh35/LoopWAM_NT-eval')
LIGHT=Path('/storage/anhdh35/Light-WAM')
BULK=Path('/data14t/anhdh35/loopwam_v0_ka_sweep_20261027')
REPORT=Path('/storage/anhdh35/LoopWAM_NT/evaluation_report/v0_ka_sweep')
CHECKPOINT=OLD/'checkpoints/release/libero-all-suites/v0-video4-action4'
DIGEST='1c659a7c2f6970c3ea5972a8fba4abd9db35857c83a67a053c0ee35555fb602b'
PYTHON='/storage/anhdh35/miniconda3/envs/loopwam-libero-eval/bin/python'
SUITES=['libero_10','libero_spatial','libero_object','libero_goal']
DEPTHS=[1,2,3,5,6]

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def write(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+f'.{os.getpid()}.tmp')
    tmp.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n');tmp.replace(path)

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj

def video_writer():
    return module('ka_historical_video',OLD/'experiments/libero/libero_utils.py').save_rollout_video

def trace_signature(rows):
    traces=[]
    for r in sorted(rows,key=lambda r:(r['id'],r['episode'])):
        if sha(r['query_log'])!=r['query_sha256']:raise ValueError('Query trace hash mismatch')
        qq=json.loads(Path(r['query_log']).read_text())
        if len(qq)!=r['queries'] or [q['query'] for q in qq]!=list(range(r['queries'])):raise ValueError('Query sequence mismatch')
        traces.append((r['id'],r['episode'],r['success'],r['policy_steps'],[q['action_sha256'] for q in qq]))
    return hashlib.sha256(json.dumps(traces).encode()).hexdigest()

def environment():
    env=os.environ.copy()
    env.update(PYTHONPATH=f'{ROOT}/src:{ROOT}:{LIGHT}/src:{LIGHT}:{LIGHT}/third_party/LIBERO',
        LIBERO_CONFIG_PATH=str(LIGHT/'.libero'),DIFFSYNTH_MODEL_BASE_PATH=str(LIGHT/'checkpoints'),
        MUJOCO_GL='egl',PYOPENGL_PLATFORM='egl',CUDA_VISIBLE_DEVICES='0',OMP_NUM_THREADS='2',
        MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',NUMBA_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false',
        PYTHONNOUSERSITE='1',PYTHONUNBUFFERED='1',TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD='1',TQDM_DISABLE='1')
    return env

def groups(calibration=False):
    return [dict(id=f'{s}_seed{seed}_task{t}',suite=s,seed=seed,task=t,episodes=2 if calibration else 50)
        for s in SUITES for t in ([0,8] if calibration else range(10)) for seed in ([42] if calibration else [42,43,44])]

def validate_rows(gg,rr,digest,k):
    expected={(g['id'],e):g for g in gg for e in range(g['episodes'])};seen=set()
    for r in rr:
        key=(r['id'],r['episode']);g=expected.get(key)
        if g is None or key in seen:raise ValueError('Unexpected/duplicate episode')
        seen.add(key)
        if (r['checkpoint_sha256']!=digest or r['action_loops']!=k or r['initial_state_index']!=r['episode']
            or any(r[x]!=g[x] for x in ['suite','seed','task'])):raise ValueError('Condition/episode identity mismatch')
        if (type(r['success']) is not bool or not 1<=r['policy_steps']<=(700 if g['suite']=='libero_10' else 400)
            or r['queries']!=math.ceil(r['policy_steps']/10)):raise ValueError('Invalid result/horizon/query count')
    if seen!=set(expected):raise ValueError('Incomplete group')
    return dict(episodes=len(rr),successes=sum(r['success'] for r in rr),success_rate=sum(r['success'] for r in rr)/len(rr))

def choose_profile(profiles):
    base=next((p for p in profiles if p.get('backend')=='eager' and p.get('workers')==4 and p.get('signature') and not p.get('recovered_episodes',0)),None)
    if base is None:raise ValueError('Missing native reference')
    eligible=[p for p in profiles if p.get('signature')==base['signature'] and p.get('seconds',0)>0 and not p.get('recovered_episodes',0)]
    return min(eligible,key=lambda p:p['seconds'])

def source_hashes():
    files=list((ROOT/'src/fastwam').rglob('*.py'))+list((ROOT/'scripts').glob('v0_ka_*.py'))
    files += [ROOT/'scripts/evaluate_loopwam_libero.py',OLD/'scripts/evaluate_matched_full41.py',OLD/'scripts/matched_cuda_graph.py',
              LIGHT/'experiments/libero/eval_libero_single.py',ROOT/'experiments/libero/libero_utils.py',OLD/'experiments/libero/libero_utils.py']
    files += list((LIGHT/'third_party/LIBERO/libero/libero').rglob('*.py'))
    files += list((OLD/'src/fastwam').rglob('*.py'))
    return {str(p):sha(p) for p in files}

def freeze_inputs():
    import numpy as np
    from libero.libero import benchmark,get_libero_path
    old=module('ka_release_validator',OLD/'scripts/evaluate_matched_full41.py')
    verified=old.validate_release(CHECKPOINT,SUITES)
    if verified['checkpoint_sha256']!=DIGEST or verified['video_loops']!=4 or verified['action_loops']!=4 or verified['training_scope']!='full_libero':
        raise ValueError('Expected original full-suite v0 trained4/4')
    tasks={};assets={str(old.VAE):verified['vae_sha256'],str(CHECKPOINT/'dataset_stats.json'):verified['normalization_sha256']}
    for p in CHECKPOINT.glob('*.json'):assets[str(p)]=sha(p)
    assets[str(OLD/'data/matched_text/provenance.json')]=sha(OLD/'data/matched_text/provenance.json')
    for name,item in verified['text_provenance']['files'].items():assets[str(OLD/'data/matched_text'/name)]=item['sha256']
    for s in SUITES:
        suite=benchmark.get_benchmark_dict()[s]()
        for t in range(10):
            task=suite.get_task(t);states=suite.get_task_init_states(t)
            if len(states)<50:raise ValueError('Missing states')
            bddl=Path(get_libero_path('bddl_files'))/task.problem_folder/task.bddl_file
            initial=Path(get_libero_path('init_states'))/task.problem_folder/task.init_states_file
            tasks[f'{s}:{t}']=dict(name=task.name,description=task.language,states=[hashlib.sha256(np.asarray(x).tobytes()).hexdigest() for x in states[:50]])
            assets[str(bddl)]=sha(bddl);assets[str(initial)]=sha(initial)
    old_manifest=json.loads((OLD/'evaluate_results/matched_lightwam/01_full_4_4/manifest.json').read_text())
    if old_manifest['verified']['checkpoint_sha256']!=DIGEST or old_manifest['reference_episode_loop_sha256']!=sha(LIGHT/'experiments/libero/eval_libero_single.py'):
        raise ValueError('Previous K4 checkpoint/reference mismatch')
    frozen=dict(verified=verified,tasks=tasks,assets=assets,source=source_hashes(),
                checkpoint=str(CHECKPOINT),checkpoint_sha256=DIGEST,video_loops=4,trained_action_loops=4,
                nfe=10,depths=DEPTHS,seeds=[42,43,44],groups=groups(),
                old_k4_summary=json.loads((OLD/'evaluate_results/matched_lightwam/01_full_4_4/summary.json').read_text()))
    write(BULK/'frozen.json',frozen);write(REPORT/'protocol.json',frozen)
    return frozen
