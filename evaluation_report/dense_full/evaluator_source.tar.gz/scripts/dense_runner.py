"""Resumable Light-WAM-matched rollouts with native full-suite Dense weights."""
import argparse,hashlib,json,multiprocessing as mp,os,queue,time,traceback,fcntl
from pathlib import Path
from scripts.dense_common import *

def load_rows(out,gg,k):
    rows=[];complete=set()
    for g in gg:
        p=out/'groups'/f"{g['id']}.json"
        if p.exists():
            rr=json.loads(p.read_text());validate_rows([g],rr,DIGEST,k)
            for r in rr:
                if sha(r['video'])!=r['video_sha256'] or sha(r['query_log'])!=r['query_sha256']:raise ValueError('Corrupt resumed artifacts')
            rows+=rr;complete.add(g['id'])
    return rows,complete

def worker(index,args,jobs,events,barrier,frozen):
    try:
        import numpy as np,torch
        from omegaconf import OmegaConf
        from fastwam.models.wan22.loopwam import create_loopwam
        from scripts.evaluate_loopwam_libero import ObservationAdapter
        from libero.libero import benchmark
        from experiments.libero.libero_utils import get_libero_env,get_libero_image
        save_rollout_video=video_writer()
        torch.set_num_threads(2);torch.cuda.set_device(0)
        old=module('ka_reference_loader',OLD/'scripts/evaluate_matched_full41.py');ref=old.load_reference()
        model=create_loopwam(checkpoint_path=str(CHECKPOINT/'policy.pt'),vae_path=str(old.VAE),device='cuda:0',model_dtype=torch.float32).eval()
        if args.ka!=1 or model.mot.version!=MODEL.replace('-','_'):raise ValueError('Wrong dense architecture')
        adapter=ObservationAdapter(json.loads((CHECKPOINT/'dataset_stats.json').read_text()),OLD/'data/matched_text',text_files=frozen['verified']['text_provenance']['files'])
        if args.backend=='cuda-graph':module('ka_graph',OLD/'scripts/matched_cuda_graph.py').enable_graphs(model)
        qlog=[]
        def predict(**kw):
            image,state=adapter.observation(kw['obs']);start=time.perf_counter()
            with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
                action=model.infer_action(input_image=image,proprio=state,context=kw['cached_prompt_context'],context_mask=kw['cached_prompt_context_mask'],
                    action_horizon=32,num_inference_steps=10,text_cfg_scale=1.,seed=int(kw['cfg'].seed),rand_device='cpu',compile_action_infer=False)['action']
            action=adapter.dataset.denormalize_action(action.float().cpu()).numpy().copy()
            if action.shape!=(32,7) or not np.isfinite(action).all():raise ValueError('Invalid action')
            action[:,-1]=np.sign(-(2*action[:,-1]-1))
            qlog.append(dict(query=len(qlog),seconds=time.perf_counter()-start,action_sha256=hashlib.sha256(action.tobytes()).hexdigest()))
            return action,get_libero_image(kw['obs']),None
        ref._predict_action_chunk=predict
        events.put(dict(event='ready',worker=index));barrier.wait()
        while True:
            g=jobs.get()
            if g is None:break
            ref.set_global_seed(g['seed'],get_worker_init_fn=False)
            suite=benchmark.get_benchmark_dict()[g['suite']]();task=suite.get_task(g['task']);states=suite.get_task_init_states(g['task'])
            spec=frozen['tasks'][f"{g['suite']}:{g['task']}"]
            if task.name!=spec['name'] or task.language!=spec['description']:raise ValueError('Task changed')
            for ep in range(g['episodes']):
                if hashlib.sha256(np.asarray(states[ep]).tobytes()).hexdigest()!=spec['states'][ep]:raise ValueError('Initial state changed')
            context,mask=adapter.text(task.language);context=context.to('cuda',dtype=torch.float32);mask=mask.to('cuda')
            cfg=OmegaConf.create(dict(seed=g['seed'],data=dict(train=dict(num_frames=33,action_video_freq_ratio=4)),
                EVALUATION=dict(task_suite_name=g['suite'],task_id=g['task'],num_steps_wait=30,replan_steps=10,visualize_future_video=False)))
            env,description=get_libero_env(task,256,g['seed']);rr=[];out=Path(args.output)
            try:
                for ep in range(g['episodes']):
                    qlog.clear();start=time.perf_counter()
                    success,frames,_,_=ref.run_single_episode(env,states[ep],description,model,None,cfg,ep,action_horizon=32,input_w=448,input_h=224,
                        model_device='cuda:0',cached_prompt_context=context,cached_prompt_context_mask=mask)
                    rollout=time.perf_counter()-start
                    vdir=out/'videos'/g['id'];vdir.mkdir(parents=True,exist_ok=True)
                    video=save_rollout_video(vdir,frames,f'trial{ep}',success,description,encoding_threads=1)
                    qp=out/'queries'/f"{g['id']}_{ep}.json";write(qp,qlog)
                    row=dict(**g,episode=ep,initial_state_index=ep,initial_state_sha256=spec['states'][ep],success=bool(success),worker=index,
                        checkpoint_sha256=DIGEST,action_loops=args.ka,model=MODEL,video_loops=1,nfe=10,backend=args.backend,description=description,
                        policy_steps=len(frames),queries=len(qlog),query_seconds=sum(q['seconds'] for q in qlog),rollout_seconds=rollout,total_seconds=time.perf_counter()-start,
                        video=str(video),video_sha256=sha(video),query_log=str(qp),query_sha256=sha(qp))
                    write(out/'episodes'/f"{g['id']}_{ep}.json",row);rr.append(row);events.put(dict(event='episode',row=row))
                validate_rows([g],rr,DIGEST,args.ka);write(out/'groups'/f"{g['id']}.json",rr)
            finally:env.close()
        events.put(dict(event='done',worker=index))
    except BaseException:events.put(dict(event='error',error=traceback.format_exc()));raise

def run(args):
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    lock=(out/'run.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    frozen=json.loads((BULK/'frozen.json').read_text())
    if source_hashes()!=frozen['source']:raise ValueError('Source drift')
    for p,h in frozen['assets'].items():
        if sha(p)!=h:raise ValueError('Asset drift')
    if sha(CHECKPOINT/'policy.pt')!=DIGEST:raise ValueError('Checkpoint drift')
    gg=groups(args.calibration);manifest=dict(action_loops=args.ka,model=MODEL,video_loops=1,nfe=10,checkpoint_sha256=DIGEST,backend=args.backend,workers=args.workers,
        groups=gg,frozen_sha256=sha(BULK/'frozen.json'),mode='calibration' if args.calibration else 'scored')
    if (out/'manifest.json').exists() and json.loads((out/'manifest.json').read_text())!=manifest:raise ValueError('Resume condition mismatch')
    write(out/'manifest.json',manifest);rr,complete=load_rows(out,gg,args.ka);pending=[g for g in gg if g['id'] not in complete]
    recovered_episodes=len(rr)
    ctx=mp.get_context('spawn');jobs=ctx.Queue();events=ctx.Queue();barrier=ctx.Event();children=[];ready=set();done=set();start=time.perf_counter();scored=None
    workers=min(args.workers,len(pending))
    for g in pending:jobs.put(g)
    for _ in range(workers):jobs.put(None)
    try:
        for i in range(workers):
            p=ctx.Process(target=worker,args=(i,args,jobs,events,barrier,frozen));p.start();children.append(p)
        while len(done)<workers:
            try:m=events.get(timeout=10)
            except queue.Empty:
                if any(p.exitcode not in (None,0) for p in children) or all(p.exitcode is not None for p in children):raise RuntimeError('Worker exited without completion')
                continue
            if m['event']=='error':raise RuntimeError(m['error'])
            if m['event']=='ready':
                ready.add(m['worker'])
                if len(ready)==workers:scored=time.perf_counter();barrier.set()
            if m['event']=='done':done.add(m['worker'])
            if m['event']=='episode':rr.append(m['row'])
            write(out/'progress.json',dict(completed=len(rr),planned=sum(g['episodes'] for g in gg),successes=sum(r['success'] for r in rr),
                ready_workers=len(ready),workers=workers,elapsed_seconds=time.perf_counter()-start))
        for p in children:
            p.join(30)
            if p.exitcode!=0:raise RuntimeError('Bad worker shutdown')
        rr,_=load_rows(out,gg,args.ka);summary=validate_rows(gg,rr,DIGEST,args.ka)
        summary.update(action_loops=args.ka,workers=args.workers,backend=args.backend,mode=manifest['mode'],checkpoint_sha256=DIGEST,
            seconds=time.perf_counter()-scored if scored else 0,elapsed_seconds=time.perf_counter()-start,finished_unix=time.time(),
            signature=trace_signature(rr),queries=sum(r['queries'] for r in rr),recovered_episodes=recovered_episodes)
        summary.update(model=MODEL,per_suite={})
        for suite in SUITES:
            suite_rows=[r for r in rr if r['suite']==suite]
            summary['per_suite'][suite]=dict(episodes=len(suite_rows),successes=sum(r['success'] for r in suite_rows),seeds={})
            for seed in sorted({r['seed'] for r in suite_rows}):
                seed_rows=[r for r in suite_rows if r['seed']==seed]
                summary['per_suite'][suite]['seeds'][str(seed)]=dict(episodes=len(seed_rows),successes=sum(r['success'] for r in seed_rows),success_rate=sum(r['success'] for r in seed_rows)/len(seed_rows))
            summary['per_suite'][suite]['success_rate']=sum(r['success'] for r in suite_rows)/len(suite_rows)
        write(out/'summary.json',summary)
        write(REPORT/('calibration_latest_summary.json' if args.calibration else 'summary.json'),summary)
    except BaseException:write(out/'error.json',dict(error=traceback.format_exc(),completed=len(rr)));raise
    finally:
        for p in children:
            if p.is_alive():p.terminate()
        for p in children:p.join(30)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--ka',required=True,type=int,choices=[1]);p.add_argument('--output',required=True)
    p.add_argument('--workers',type=int,choices=range(1,9),default=4);p.add_argument('--backend',choices=['eager','cuda-graph'],default='eager');p.add_argument('--calibration',action='store_true')
    run(p.parse_args())
