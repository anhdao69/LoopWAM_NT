"""CPU-only release/strict weight validation; freezes inputs before queue launch."""
import json,time
from scripts.dense_common import *

def main():
    import torch
    from fastwam.models.wan22.loopwam import create_loopwam
    torch.set_num_threads(2)
    receipt=json.loads((CAMPAIGN/'download_receipt.json').read_text())
    if not receipt.get('finished_unix'):raise ValueError('Download incomplete')
    for entry in receipt['files']:
        if Path(entry['path']).parent==CHECKPOINT:
            if Path(entry['path']).stat().st_size!=entry['size'] or sha(entry['path'])!=entry['sha256']:raise ValueError('Downloaded artifact mismatch')
    old=module('dense_cpu_validator',OLD/'scripts/evaluate_matched_full41.py')
    verified=old.validate_release(CHECKPOINT,SUITES)
    model=create_loopwam(checkpoint_path=str(CHECKPOINT/'policy.pt'),vae_path=str(old.VAE),device='cpu',model_dtype=torch.float32).eval()
    payload=torch.load(CHECKPOINT/'policy.pt',map_location='cpu',mmap=True,weights_only=False)
    export=json.loads((CHECKPOINT/'export.json').read_text())
    count=sum(p.numel() for p in model.mot.parameters())+sum(p.numel() for p in model.proprio_encoder.parameters())
    if model.version!=MODEL.replace('-','_') or model.mot.loops!=1 or model.mot.action_loops!=1:raise ValueError('Wrong native architecture')
    if count!=export['parameters']:raise ValueError('Parameter count mismatch')
    for section in ['mot','proprio_encoder']:
        if any(not torch.isfinite(t).all() for t in payload[section].values() if t.is_floating_point()):raise ValueError('Nonfinite trained weights')
    audit=dict(model=MODEL,revision=receipt['revision'],checkpoint_sha256=DIGEST,strict_load_passed=True,weights_finite=True,
        version=payload['version'],parameters=count,architecture=payload['architecture'],step=payload['step'],training_state={k:v for k,v in payload['training_state'].items() if k!='rng'},
        verified=verified,device='cpu',gpu_inference_test='pending_after_v0',validated_unix=time.time())
    write(BULK/'cpu_validation.json',audit);write(REPORT/'cpu_validation.json',audit)
    freeze_inputs();print(json.dumps({k:audit[k] for k in ['model','parameters','step','strict_load_passed','revision']}))

if __name__=='__main__':main()
