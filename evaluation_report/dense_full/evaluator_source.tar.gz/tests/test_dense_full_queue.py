import pytest
from scripts.dense_chain import predecessor_ready
from scripts.dense_common import groups, choose_profile, MODEL, DIGEST

def state():
 return dict(finished_unix=1,active=None,jobs=[dict(ka=k,status='complete',summary={'episodes':6000,'action_loops':k,'checkpoint_sha256':'1c659a7c2f6970c3ea5972a8fba4abd9db35857c83a67a053c0ee35555fb602b'}) for k in [1,2,3,5,6]])
def test_predecessor_requires_all_five():
 s=state(); assert predecessor_ready(s)
 for key,value in [('finished_unix',None),('active',{'pid':1}),('error','failed')]:
  bad={**s,key:value}; assert not predecessor_ready(bad)
 s['jobs'].pop();assert not predecessor_ready(s)
def test_predecessor_rejects_wrong_counts_and_identity():
 for field,value in [('episodes',5999),('checkpoint_sha256','wrong'),('action_loops',2)]:
  s=state();s['jobs'][0]['summary'][field]=value;assert not predecessor_ready(s)
 s=state();s['jobs'][0]['status']='error';assert not predecessor_ready(s)
def test_dense_protocol():
 assert MODEL in ('dense-s12','dense-s30') and len(DIGEST)==64
 gg=groups();assert len(gg)==120 and sum(g['episodes'] for g in gg)==6000
 assert {g['seed'] for g in gg}=={42,43,44}
def test_profile_requires_native_parity():
 base=dict(backend='eager',workers=2,signature='a',seconds=20)
 fast=dict(backend='cuda-graph',workers=4,signature='a',seconds=10)
 bad=dict(backend='cuda-graph',workers=8,signature='b',seconds=1)
 assert choose_profile([base,fast,bad])==fast
 with pytest.raises(ValueError):choose_profile([fast])

def test_gate_rejects_cross_model_and_frozen_input_drift(tmp_path,monkeypatch):
 from scripts import dense_common as c
 monkeypatch.setattr(c,'BULK',tmp_path)
 (tmp_path/'gate_inputs.pt').write_bytes(b'inputs');(tmp_path/'frozen.json').write_text('{}')
 gate=dict(model=c.MODEL,checkpoint_sha256=c.DIGEST,ka=1,video_loops=1,trained_ka=1,nfe=10,native_finite=True,source={'x':'y'},
   frozen_sha256=c.sha(tmp_path/'frozen.json'),inputs_sha256=c.sha(tmp_path/'gate_inputs.pt'))
 assert c.validate_gate(gate,{'source':{'x':'y'}}) is None
 for field,value in [('model','wrong'),('checkpoint_sha256','wrong'),('ka',4),('nfe',5),('frozen_sha256','wrong'),('inputs_sha256','wrong')]:
  with pytest.raises(ValueError):c.validate_gate({**gate,field:value},{'source':{'x':'y'}})
