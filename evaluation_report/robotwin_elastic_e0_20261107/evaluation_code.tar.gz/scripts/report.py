"""Read-only live SR: completed cells plus explicitly provisional active attempts."""
import csv, datetime, json, re, shutil, time
from pathlib import Path
B=Path(__file__).resolve().parent.parent
R=Path('/storage/anhdh35/LoopWAM_NT/evaluation_report/robotwin_elastic_e0_20261107')
ORDER=['flat_k1_n2','flat_k4_n2','flat_k4_n5']
LABELS=['[1,1]','[4,4]','[4] × 5']
EPISODE=re.compile(r'Success rate: (?:\x1b\[\d+m)?(\d+)/(\d+).*?current seed: (?:\x1b\[\d+m)?(\d+)')
def read(p,default=None):
    return json.loads(p.read_text()) if p.exists() else ({} if default is None else default)
def write(p,d):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(d,indent=2));t.replace(p)
def update():
    R.mkdir(exist_ok=True)
    state=read(B/'queue_status.json');rows=[]
    lines=['# Elastic E0 — full RoboTwin evaluation','',
           'Updated '+datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).isoformat(timespec='seconds')+'.',
           '',f"Queue stage: **{state.get('stage','preparing')}**. Sequential order is fixed below.",'',
           '| Schedule | NFE | Status | Verified cells / 100 | Verified successes / episodes | Verified SR | Active attempt episodes |',
           '| --- | ---: | --- | ---: | ---: | ---: | ---: |']
    for name,label in zip(ORDER,LABELS):
        run=B/'runs'/name;summary=read(run/'results/summary.json');audit=read(run/'final_audit.json');launch=read(run/'launch.json')
        if audit.get('status')=='passed':summary=read(run/'results/COMPLETE.json')
        cells=summary.get('finished',{});success=sum(x['successes'] for x in cells.values());episodes=sum(len(x['episodes']) for x in cells.values())
        active=sum(x['episodes'] for x in summary.get('running',{}).values())
        sr=100*success/episodes if episodes else None
        status='complete; audited' if audit.get('status')=='passed' else launch.get('status','queued')
        row=dict(schedule=name,nfe=5 if name.endswith('n5') else 2,status=status,verified_cells=len(cells),successes=success,episodes=episodes,sr_percent=sr,active_attempt_episodes=active)
        rows.append(row);lines.append(f"| {label} | {row['nfe']} | {status} | {len(cells)} | {success}/{episodes} | {f'{sr:.2f}%' if sr is not None else '—'} | {active} |")
    lines+=['','Full coverage per schedule: **50 tasks × 2 settings × 100 accepted episodes = 10,000**. Total queue: **30,000 episodes**, seed **42**.',
            '', 'SR uses only validated complete task/setting cells. Active attempts and smoke tests are excluded from verified SR. Until all cells complete, task difficulty is uneven and partial SR is not a final benchmark score.',
            '', 'Checkpoint: `robotwin/Elastic/E0/epoch_01.pt`, update 47,462; native `loopwam-s-robot-rt-v1`; trained from original epoch-5 v0 teacher (237,310 updates).',
            '', 'Each schedule keeps four video loops. Action loops follow the listed depths at each flow step; trained step condition is 1/NFE. All runs use the same checkpoint and normalization.',
            '', 'Protocol: original FastWAM PIL uint8 camera resize/packing, BF16 normalization, FP32 policy parameters with BF16 autocast; 14-D absolute joint positions; predict32/execute24; fixed CPU action-noise seed42 at each query; unseen instruction pool; expert-planning scene admission; original horizons; clean and randomized settings. Python instruction-template RNG remains unseeded to preserve the historical protocol, so exact episode pairing across runs is not claimed.',
            '', 'Speed: four concurrent simulator workers, one shared T5 server and prompt cache, unchanged replanning observation shortcut, and bit-exact CUDA graph replay. Renderer remains RT32/depth8 with the previously validated OIDN compatibility runtime. Renderer/resource errors reject a whole attempt; at most three attempts per cell, 1,800-second no-progress timeout.',
            '', 'Preflight includes upstream and adapter tests, exact loaded tensor checks, native/graph parity on eight real simulator inputs with seeds42/43/44, schedule/timestep instrumentation, and four excluded smoke episodes for each schedule.',
            '', 'Reproducibility: [source validation](source_check.json), [graph gate](graph_gate.json), [runtime manifest](runtime_manifest.json), [setup and execution plan](plan.md), [live machine-readable status](current_results.json). Each schedule subdirectory receives task/episode CSVs, final audit and final report automatically.',
            '', 'Baseline epoch-5 full RoboTwin: clean91.60%, randomized91.86%, combined91.73% (9,173/10,000). E0 changes both learned action weights/step conditioning and NFE; this is an Elastic deployment comparison, not a same-NFE checkpoint comparison.','']
    (R/'report.md').write_text('\n'.join(lines));write(R/'current_results.json',dict(updated_unix=time.time(),queue=state,runs=rows))
    for name in ['queue_status.json','graph_gate.json','source_check.json','runtime_manifest.json','download_receipt.json','hf_manifest.json','plan.md','tests_green.log','review.md','preflight.json']:
        p=B/name
        if p.exists() and (not (R/name).exists() or p.stat().st_mtime>(R/name).stat().st_mtime):shutil.copy2(p,R/name)
if __name__=='__main__':update()
