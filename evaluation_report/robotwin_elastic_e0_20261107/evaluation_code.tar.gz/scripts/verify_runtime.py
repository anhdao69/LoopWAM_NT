"""Freeze and revalidate inherited assets plus Elastic source and launchers."""
import concurrent.futures, hashlib, json, subprocess, time
from pathlib import Path
from queue_safety import publish_runtime
B=Path(__file__).resolve().parent.parent
W=B/'repo'
OLD=Path('/data14t/anhdh35/loopwam_robotwin_v0_20261030')
R=Path('/storage/anhdh35/LoopWAM_NT/evaluation_report/robotwin_elastic_e0_20261107')
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def verify(files):
    def check(item):
        p,info=item
        assert sha(p)==info['sha256'],f'Runtime drift: {p}'
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(check,files.items()))
def main():
    R.mkdir(exist_ok=True)
    old=json.loads((OLD/'runtime_manifest.json').read_text());verify(old['files'])
    receipt=json.loads((B/'download_receipt.json').read_text())
    for item in receipt['files']:assert sha(item['path'])==item['sha256'],item['path']
    assert sha(B/'checkpoint/epoch_01.pt')=='abc3c0075a6e1f3ce380be8d6c7b6b9d8bb697ac21cf3f2d40a93efb821b539a'
    # All upstream native model files must equal the source used to train this release.
    native=[]
    for p in (W/'src/fastwam/models/wan22').rglob('*.py'):
        rel=str(p.relative_to(W));expected=subprocess.check_output(['git','show','2c78ff6:'+rel],cwd=W)
        assert p.read_bytes()==expected,f'Native model source differs from trained release: {rel}'
        native.append(rel)
    baseline=json.loads((OLD/'results/manifest.json').read_text())
    original=Path('/storage/anhdh35/LoopWAM-robotwin-eval')
    matched=[]
    for p,h in baseline['runtime_hashes'].items():
        oldpath=Path(p)
        try:rel=oldpath.relative_to(original)
        except ValueError:continue
        if str(rel).startswith(('third_party/RoboTwin/','experiments/robotwin/chronoloop_policy/')):
            assert sha(W/rel)==h,str(rel)
            matched.append(str(rel))
    stats=json.loads((B/'checkpoint/dataset_stats.json').read_text())
    assert stats==json.loads((OLD/'checkpoints/v0-video4-action4/dataset_stats.json').read_text())
    paths=list((B/'scripts').glob('*.py'))+list(B.glob('*.sh'))+[B/'plan.md',B/'hf_manifest.json',B/'download_receipt.json',B/'graph_gate.json',B/'review_gate.json']
    paths+=list((B/'checkpoint').glob('*'))
    for root in [W/'src',W/'experiments/robotwin',W/'scripts',W/'third_party/RoboTwin']:
        paths.extend(p for p in root.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.yml','.yaml','.sh'))
    files=dict(old['files'])
    for p in paths:
        if p.is_file():files[str(p)]=dict(sha256=sha(p),bytes=p.stat().st_size)
    runtime=dict(created_unix=time.time(),files=files,hf_revision=receipt['revision'],
                 elastic_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),
                 source_training_commit='2c78ff6f186c1d9073068b8eee5b328d19dba826',
                 renderer='rt32/depth8/OIDN2.3.3',inherited_manifest=str(OLD/'runtime_manifest.json'))
    publish_runtime(B/'runtime_manifest.json',runtime)
    evidence=dict(passed=True,native_model_files_equal_training_revision=len(native),
                  simulator_and_text_files_equal_epoch5=len(matched),normalization_json_equal=True,
                  inherited_runtime_files=len(old['files']),total_bound_files=len(files),verified_unix=time.time())
    for p in [B/'source_check.json',R/'source_check.json']:p.write_text(json.dumps(evidence,indent=2))
    print(json.dumps(evidence),flush=True)
if __name__=='__main__':main()
