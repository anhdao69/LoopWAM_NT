"""Locked, resumable, ordered full50 Elastic evaluation with fail-closed gates."""
import fcntl, json, os, shutil, signal, subprocess, sys, time, traceback
from pathlib import Path
from report import B,R,ORDER,read,write,update
from verify_runtime import W,verify

def status(stage,**extra):
    write(B/'queue_status.json',dict(stage=stage,updated_unix=time.time(),queue_pid=os.getpid(),**extra));update()
    print(stage,extra,flush=True)

def run_process(stage,cmd,logfile,**extra):
    status(stage,**extra)
    old=read(B/'active_process.json')
    if old.get('status')=='running':
        stat=Path(f"/proc/{old['pid']}/stat")
        if stat.exists() and stat.read_text().split()[21]==old.get('start_ticks'):
            raise RuntimeError('Previous queue child remains alive; refusing duplicate process')
    with Path(logfile).open('a') as log:
        proc=subprocess.Popen(cmd,cwd=W,env=dict(os.environ),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    state=dict(stage=stage,pid=proc.pid,command=cmd,status='running',started_unix=time.time(),start_ticks=Path(f'/proc/{proc.pid}/stat').read_text().split()[21])
    write(B/'active_process.json',state)
    try:
        while proc.poll() is None:
            update();time.sleep(10)
        if proc.returncode:raise RuntimeError(f'{stage} failed (exit {proc.returncode}); see {logfile}')
    finally:
        if proc.poll() is None:
            os.killpg(proc.pid,signal.SIGTERM)
            try:proc.wait(125)
            except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
        state.update(status='finished',exit_code=proc.returncode,finished_unix=time.time());write(B/'active_process.json',state)

def eval_command(name,out,episodes,tasks=None):
    cmd=[sys.executable,str(W/'scripts/evaluate_loopwam_robotwin.py'),'--checkpoint',str(B/'checkpoint/epoch_01.pt'),
         '--output-dir',str(out),'--robotwin-root',str(W/'third_party/RoboTwin'),'--data-dir',str(B/'checkpoint'),
         '--gpus','0','--per-gpu','4','--episodes',str(episodes),'--seed','42','--expected-step','47462',
         '--elastic-schedule',name,'--max-attempts','3','--no-progress-timeout','1800']
    if tasks:cmd+=['--tasks',','.join(tasks)]
    return cmd

def main():
    lock=(B/'queue.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt()))
    assert read(B/'graph_gate.json')['passed']
    assert read(B/'review_gate.json')['passed']
    run_process('runtime_verification',[sys.executable,str(B/'scripts/verify_runtime.py')],B/'runtime_verification.log')
    os.environ['LOOPWAM_CUDA_GRAPH']='1';os.environ['LOOPWAM_RUNTIME_MANIFEST']=str(B/'runtime_manifest.json')
    from fastwam.robotwin_pipeline import validate_eval_summary
    sha=read(B/'graph_gate.json')['checkpoint_sha256']
    # Smoke all three schedules before any scored evaluation. Each uses four simultaneous workers.
    for name in ORDER:
        smoke=B/'smoke'/name
        run_process('smoke',eval_command(name,smoke,1,['adjust_bottle','open_microwave']),B/f'smoke_{name}.log',schedule=name)
        c=read(smoke/'COMPLETE.json');validate_eval_summary(c,sha,['adjust_bottle','open_microwave'],1)
        assert not c.get('failed') and len(c['finished'])==4
    write(B/'preflight.json',dict(passed=True,schedules=ORDER,smoke_episodes=12,smoke_excluded=True,workers=4,
                                seed=42,planned_episodes=30000,verified_unix=time.time()))
    from finalize import finalize
    from queue_safety import reuse_completed
    for name in ORDER:
        run=B/'runs'/name;run.mkdir(parents=True,exist_ok=True)
        old=read(run/'launch.json')
        if reuse_completed(run,validate_eval_summary):
            status('finalizing',schedule=name);finalize(name);continue
        verify(read(B/'runtime_manifest.json')['files'])
        command=eval_command(name,run/'results',100)
        launch=dict(old,status='running',schedule=name,workers=4,seed=42,planned_episodes=10000,command=command)
        launch.setdefault('started_unix',time.time());launch.setdefault('segments',[])
        launch['segments'].append(dict(started_unix=time.time()));write(run/'launch.json',launch)
        try:
            run_process('evaluation',command,run/'evaluation.log',schedule=name)
            assert (run/'results/COMPLETE.json').exists()
            launch.update(status='complete',finished_unix=time.time());launch['segments'][-1]['finished_unix']=time.time();write(run/'launch.json',launch)
            status('finalizing',schedule=name);finalize(name)
        except BaseException:
            launch.update(status='error',error=traceback.format_exc());write(run/'launch.json',launch);raise
    status('complete',final_audit_passed=True,scored_episodes=30000)

if __name__=='__main__':
    try:main()
    except BaseException:
        status('error',error=traceback.format_exc());raise
