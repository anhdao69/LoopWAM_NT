#!/usr/bin/env bash
set -euo pipefail
source /data14t/anhdh35/loopwam_robotwin_elastic_e0_20261107/environment.sh
cd /data14t/anhdh35/loopwam_robotwin_elastic_e0_20261107/repo
exec python /data14t/anhdh35/loopwam_robotwin_elastic_e0_20261107/scripts/queue_pipeline.py
