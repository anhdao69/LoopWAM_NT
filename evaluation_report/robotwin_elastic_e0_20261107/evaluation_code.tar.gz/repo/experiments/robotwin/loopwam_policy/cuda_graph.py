"""Replay unchanged eager CUDA kernels; no Inductor or arithmetic transformation.

Fixed-shape inputs are copied on every call. Graph outputs are reused, matching
this evaluator's strictly sequential per-worker action inference.
"""
import torch
from torch.utils._pytree import tree_flatten,tree_unflatten

class GraphedCall:
 def __init__(self,fn):
  self.fn=fn;self.graph=None
 def __call__(self,*args,**kwargs):
  leaves,spec=tree_flatten((args,kwargs))
  if self.graph is None:
   if any(torch.is_tensor(t) and not t.is_cuda for t in leaves):raise ValueError('CUDA Graph inputs must be CUDA tensors')
   self.spec=spec
   self.static=[t.detach().clone() if torch.is_tensor(t) else t for t in leaves]
   a,k=tree_unflatten(self.static,spec)
   stream=torch.cuda.Stream();stream.wait_stream(torch.cuda.current_stream())
   with torch.cuda.stream(stream),torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16,cache_enabled=False):
    for _ in range(3):self.fn(*a,**k)
   torch.cuda.current_stream().wait_stream(stream)
   self.graph=torch.cuda.CUDAGraph()
   with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16,cache_enabled=False):
    with torch.cuda.graph(self.graph):self.output=self.fn(*a,**k)
  else:
   if spec!=self.spec:raise ValueError('CUDA Graph argument structure changed')
   for dst,src in zip(self.static,leaves):
    if torch.is_tensor(dst):
     if not torch.is_tensor(src) or dst.shape!=src.shape or dst.dtype!=src.dtype or dst.device!=src.device:raise ValueError('CUDA Graph tensor signature changed')
     dst.copy_(src)
    elif dst!=src:raise ValueError('CUDA Graph constant changed')
  self.graph.replay()
  return self.output

def enable_graphs(model):
 model.mot.prefill_video_cache_tensor=GraphedCall(model.mot.prefill_video_cache_tensor)
 model._denoise_action_with_video_cache=GraphedCall(model._denoise_action_with_video_cache)
