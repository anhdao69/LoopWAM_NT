"""RoboTwin 14-D inputs to the release's unchanged native Elastic rollout."""
import torch

SCHEDULES = {'flat_k1_n2': (1, 1), 'flat_k4_n2': (4, 4), 'flat_k4_n5': (4, 4, 4, 4, 4)}

def schedule_depths(name):
    if name not in SCHEDULES:
        raise ValueError(f'Unsupported requested Elastic schedule: {name}')
    return SCHEDULES[name]

class RobotElasticInference:
    def __init__(self, checkpoint, vae_path, schedule, device='cuda', use_graph=False):
        from fastwam.models.wan22.transport_inference_robot import load_robot_transport
        schedule_depths(schedule)
        self.policy, self.payload = load_robot_transport(checkpoint, vae_path, device=device)
        self.device = torch.device(device)
        self.schedule = schedule
        self.graph = None
        if use_graph:
            self.enable_graph()

    def enable_graph(self):
        from .cuda_graph import GraphedCall
        # No torch.compile, precision conversion or changes to native rollout math.
        self.graph = GraphedCall(self.policy.rollout)

    def eval(self):
        self.policy.eval()
        return self

    @torch.inference_mode()
    def infer_action(self, *, input_image, proprio, context, context_mask, seed=42,
                     rand_device='cpu', action_horizon=32, num_inference_steps=None,
                     text_cfg_scale=1., compile_action_infer=False):
        depths = schedule_depths(self.schedule)
        if num_inference_steps != len(depths):
            raise ValueError('NFE must equal the selected Elastic schedule length')
        if action_horizon != 32:
            raise ValueError('RoboTwin requires a 32-action prediction horizon')
        if proprio.shape not in ((14,), (1, 14)):
            raise ValueError('RoboTwin requires 14-D proprioception')
        if text_cfg_scale != 1. or compile_action_infer:
            raise ValueError('CFG must be 1; this adapter uses native kernels only')
        image = input_image.unsqueeze(0) if input_image.ndim == 3 else input_image
        if image.shape != (1, 3, 384, 320):
            raise ValueError('Expected packed RoboTwin image [1,3,384,320]')
        context = context.unsqueeze(0) if context.ndim == 2 else context
        mask = context_mask.unsqueeze(0) if context_mask.ndim == 1 else context_mask
        if context.ndim != 3 or context.shape[0] != 1 or context.shape[2] != 4096 or mask.shape != context.shape[:2]:
            raise ValueError('Invalid cached T5 context/mask')
        # Same CPU generator, FP32 noise and image conversion as original FastWAM.
        generator = None if seed is None else torch.Generator(device=rand_device).manual_seed(seed)
        noise = torch.randn((1, 32, 14), generator=generator, device=rand_device, dtype=torch.float32).to(self.device)
        with torch.autocast(self.device.type, dtype=torch.bfloat16, enabled=self.device.type == 'cuda'):
            latents = self.policy.parent._encode_input_image_latents_tensor(image.to(self.device, dtype=torch.float32))
            sample = dict(first_frame_latents=latents,
                          context=context.to(self.device, dtype=torch.float32),
                          context_mask=mask.to(self.device, dtype=torch.bool),
                          proprio=proprio.reshape(1, 1, 14).to(self.device, dtype=torch.float32))
            action = (self.graph or self.policy.rollout)(sample, depths, noise)
        if action.shape != (1, 32, 14) or not torch.isfinite(action).all():
            raise ValueError('Invalid Elastic action output')
        return {'action': action[0].float().cpu().clone()}
