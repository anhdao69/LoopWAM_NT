"""Native Elastic E0 policy using the original full RoboTwin observation/action protocol."""
import hashlib
import json
import os
import sys
import time
from collections import deque
from pathlib import Path

import numpy as np
import torch

CODE_ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(CODE_ROOT));sys.path.insert(0,str(CODE_ROOT/'src'))
os.environ.setdefault('DIFFSYNTH_MODEL_BASE_PATH',str(CODE_ROOT/'checkpoints'))
from fastwam.datasets.chronoloop_robot import preprocess_frames,robot_spec
from fastwam.datasets.loopwam_long import DEFAULT_PROMPT
from fastwam.datasets.lerobot.utils.normalizer import SingleFieldLinearNormalizer
from fastwam.robotwin_pipeline import verify_file_hash
# Only the validated T5 transport/cache helper is shared; no ChronoLoop model is constructed.
from experiments.robotwin.chronoloop_policy.deploy_policy import TextEncoder,CAMERAS


def fastwam_image(observation,device='cuda'):
    """Released FastWAM PIL uint8 resize and BF16 normalization, unchanged arithmetic."""
    from PIL import Image
    obs=observation['observation']
    def resize(camera,size):
        return np.asarray(Image.fromarray(obs[camera]['rgb'].astype(np.uint8),mode='RGB').resize(size,resample=Image.BILINEAR),dtype=np.uint8)
    head=resize('head_camera',(320,256));left=resize('left_camera',(160,128));right=resize('right_camera',(160,128))
    packed=np.concatenate([head,np.concatenate([left,right],axis=1)],axis=0)
    return torch.from_numpy(packed).permute(2,0,1).unsqueeze(0).to(device=device,dtype=torch.bfloat16)*(2.0/255.0)-1.0

class LoopWAMRoboTwinPolicy:
    def __init__(self,checkpoint,data_dir,vae_path,seed=42,t5_server=None,expected_step=47462,compile_action_infer=False,schedule=None):
        from .elastic_inference import RobotElasticInference, schedule_depths
        self.schedule=schedule;self.nfe=len(schedule_depths(schedule))
        torch.set_num_threads(2)
        header=torch.load(checkpoint,map_location='cpu',mmap=True,weights_only=False)
        contract=header['training_state']['contract']
        verify_file_hash(vae_path,contract['asset_sha256']['vae']);del header
        self.model=RobotElasticInference(checkpoint,vae_path,schedule,use_graph=os.environ.get('LOOPWAM_CUDA_GRAPH')=='1')
        payload=self.model.payload
        config=payload['transport_config']
        if payload['step']!=int(expected_step) or config['kind']!='T0' or config['dataset']!='robotwin50' or config['scope']!='pc' or not config['step_cond']:
            raise ValueError('Wrong Elastic E0 checkpoint/configuration')
        if payload['training_state']['parent_step']!=237310:raise ValueError('Wrong E0 teacher')
        stats=json.loads((Path(data_dir)/'dataset_stats.json').read_text())
        if hashlib.sha256(json.dumps(stats,sort_keys=True).encode()).hexdigest()!=payload['training_state']['contract']['normalization_sha256']:
            raise ValueError('Evaluation normalization differs from training')
        self.normalizer={kind:SingleFieldLinearNormalizer({k.removeprefix('global_'):torch.tensor(v,dtype=torch.float32) for k,v in stats[kind]['default'].items() if k.startswith('global_')},mode='z-score') for kind in ('action','state')}
        self.model.eval();del payload;del self.model.payload
        spec=robot_spec('robotwin50');self.text=TextEncoder(spec.text_cache_dir,spec.text_suffix,'cuda',server=t5_server)
        self.seed=int(seed);self.compile_action_infer=bool(compile_action_infer)
        self.pending=deque();self.episode=-1;self.queries=0;self.latency=[]

    def reset(self):
        self.pending.clear();self.queries=0;self.episode+=1

    def should_request_observation(self):return not self.pending

    def _query(self,observation,instruction):
        image=fastwam_image(observation)[0]
        joint=torch.as_tensor(np.asarray(observation['joint_action']['vector'],dtype=np.float32))
        if joint.shape!=(14,):raise ValueError('Expected14D joint state')
        proprio=self.normalizer['state'].forward(joint[None])[0]
        context,mask=self.text(DEFAULT_PROMPT.format(task=instruction))
        if self.queries==0:print(json.dumps(dict(loopwam_episode=self.episode,instruction=instruction,noise_seed=self.seed,elastic_schedule=self.schedule,nfe=self.nfe)),flush=True)
        kw=dict(input_image=image,proprio=proprio,context=context,context_mask=mask,
            action_horizon=32,num_inference_steps=self.nfe,text_cfg_scale=1.,seed=self.seed,rand_device='cpu',compile_action_infer=self.compile_action_infer)
        capture=os.environ.get('LOOPWAM_CAPTURE_INPUTS')
        if capture and self.episode==0 and self.queries<2:
            directory=Path(capture);directory.mkdir(parents=True,exist_ok=True)
            torch.save({k:v.detach().cpu() if torch.is_tensor(v) else v for k,v in kw.items()},directory/f'{os.getpid()}_q{self.queries}.pt')
        start=time.perf_counter()
        with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
            result=self.model.infer_action(**kw)
        torch.cuda.synchronize();self.latency.append(time.perf_counter()-start);self.queries+=1
        action=result['action'].detach().float().cpu()
        if action.shape!=(32,14) or not torch.isfinite(action).all():raise ValueError('Invalid action output')
        denormalized=self.normalizer['action'].backward(action[None])[0].numpy()
        if not np.isfinite(denormalized).all():raise ValueError('Nonfinite denormalized action')
        print(json.dumps(dict(policy_query=self.queries-1,episode=self.episode,seconds=self.latency[-1],action_sha256=hashlib.sha256(denormalized.tobytes()).hexdigest())),flush=True)
        return denormalized

    def step(self,task_env,observation):
        if not self.pending:
            if observation is None:raise ValueError('Missing replanning observation')
            chunk=self._query(observation,task_env.get_instruction())
            self.pending.extend(np.asarray(a,dtype=np.float32) for a in chunk[:24])
        task_env.take_action(self.pending.popleft(),action_type='qpos')

def get_model(args):
    from .elastic_inference import schedule_depths
    schedule=args['elastic_schedule']
    if int(args.get('replan_steps',24))!=24 or int(args['num_inference_steps'])!=len(schedule_depths(schedule)):raise ValueError('Protocol requires 24 replan and schedule-matched NFE')
    return LoopWAMRoboTwinPolicy(args['ckpt_setting'],args['data_dir'],
        args.get('vae_path') or str(CODE_ROOT/'checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth'),
        seed=args.get('seed',42),t5_server=args.get('t5_server'),expected_step=args.get('expected_step',47462),
        compile_action_infer=args.get('compile_action_infer',False),schedule=schedule)

def eval(TASK_ENV,model,observation):model.step(TASK_ENV,observation)
def reset_model(model):model.reset()
