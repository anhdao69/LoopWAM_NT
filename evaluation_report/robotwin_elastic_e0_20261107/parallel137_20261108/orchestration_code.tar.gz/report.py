"""Small remote progress report; final audit retains full episode artifacts."""
import json,re,time,shutil
from pathlib import Path
B=Path(__file__).resolve().parent.parent;R=B/'report'
EPISODE=re.compile(r'Success rate: (?:\x1b\[\d+m)?(\d+)/(\d+).*?current seed: (?:\x1b\[\d+m)?(\d+)')
def read(p):return json.loads(p.read_text()) if p.exists() else {}
def write(p,d):
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(d,indent=2));tmp.replace(p)
def progress(out):
    d=read(out/'COMPLETE.json') or read(out/'summary.json');cells=d.get('finished',{})
    totals={s:dict(successes=0,episodes=0) for s in ['demo_clean','demo_randomized']}
    rows=[]
    for c in cells.values():
        totals[c['config']]['successes']+=c['successes'];totals[c['config']]['episodes']+=len(c['episodes'])
        rows.append(dict(task=c['task'],setting=c['config'],successes=c['successes'],episodes=len(c['episodes']),complete=True))
    verified=sum(v['episodes'] for v in totals.values())
    for key in d.get('running',{}):
        task,setting=key.split('/');attempts=sorted((out/f'{task}__{setting}').glob('attempt_*'))
        if not attempts:continue
        a=attempts[-1];p=a/'eval.log'
        if not p.exists() or (a/'failure.json').exists():continue
        text=p.read_text(errors='replace')
        if any(m in text.lower() for m in ['oidn error:','cuda out of memory','cudaerrormemoryallocation','cannot create buffer','errordevicelost','vk::devicelosterror']):continue
        matches=EPISODE.findall(text)
        k,n=map(int,matches[-1][:2]) if matches else (0,0)
        totals[setting]['successes']+=k;totals[setting]['episodes']+=n
        rows.append(dict(task=task,setting=setting,successes=k,episodes=n,complete=False))
    totals['combined']=dict(successes=sum(v['successes'] for v in totals.values()),episodes=sum(v['episodes'] for v in totals.values()))
    for v in totals.values():v['sr_percent']=100*v['successes']/v['episodes'] if v['episodes'] else None
    return dict(totals=totals,verified_cells=len(cells),verified_episodes=verified,tasks=rows,failed=d.get('failed',[]))
def update():
    run=B/'runs/flat_k4_n2';state=read(B/'queue_status.json');data=progress(run/'results')
    data.update(updated_unix=time.time(),host='10.148.182.137',schedule='flat_k4_n2',queue=state,audit=read(run/'final_audit.json'))
    write(R/'current_results.json',data);write(R/'queue_status.json',state)
    for name in ['source_check.json','graph_gate.json','cross_host_gate.json','diagnosis.json','smoke_validation.json','runtime_manifest.json','settings.json','assignments.json','user_authorization.json','review_gate.json']:
        p=B/name
        if p.exists() and (not (R/name).exists() or p.stat().st_mtime>(R/name).stat().st_mtime):shutil.copy2(p,R/name)
    t=data['totals']['combined'];rate=f"{t['sr_percent']:.2f}%" if t['sr_percent'] is not None else 'pending'
    (R/'report.md').write_text(f"# Elastic E0 [4,4], NFE2 — server137\n\nStage: {state.get('stage','preparing')}. Live SR: {rate}, {t['successes']}/{t['episodes']} episodes. Verified cells: {data['verified_cells']}/100.\n\nFull50, clean/randomized,100episodes/task/setting,seed42,10,000episodes. Four workers; RT32/depth8; predict32/execute24; FP32 parameters/BF16 compute. Native/graph outputs match exactly on this host. Cross-host inference agreement is recorded in cross_host_gate.json. Partial SR includes active attempts and remains provisional until final audit.\n")
