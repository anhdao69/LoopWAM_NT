import gc,json,hashlib,time
from pathlib import Path
import torch
from experiments.robotwin.loopwam_policy.elastic_inference import RobotElasticInference
from experiments.robotwin.chronoloop_policy.deploy_policy import TextEncoder
B=Path(__file__).resolve().parent.parent;torch.set_num_threads(2)
refs=torch.load(B/'local_reference.pt',weights_only=False);middle=torch.load(B/'local_intermediates.pt',weights_only=False)
m=RobotElasticInference(B/'checkpoint/epoch_01.pt',B/'repo/checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth','flat_k4_n2');del m.payload
record=dict(outputs=[],cudnn_version=torch.backends.cudnn.version(),matmul_tf32=torch.backends.cuda.matmul.allow_tf32,cudnn_tf32=torch.backends.cudnn.allow_tf32,cudnn_deterministic=torch.backends.cudnn.deterministic)
def compare(a,b):return dict(bit_equal=torch.equal(a,b),max_abs_difference=float((a.float()-b.float()).abs().max()),mean_abs_difference=float((a.float()-b.float()).abs().mean()))
for item in refs:
    kw=torch.load(B/'gate_inputs'/item['file'],weights_only=False);kw.update(seed=item['seed'],num_inference_steps=2,compile_action_infer=False)
    with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):a=m.infer_action(**kw)['action']
    record['outputs'].append(dict(file=item['file'],**compare(a,item['action'])))
kw=torch.load(B/'gate_inputs'/refs[0]['file'],weights_only=False);kw.update(seed=42,num_inference_steps=2,compile_action_infer=False)
with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
    lat=m.policy.parent._encode_input_image_latents_tensor(kw['input_image'][None].to('cuda',dtype=torch.float32)).cpu()
record['vae_boundary']=compare(lat,middle['latents'])
original=m.policy.parent._encode_input_image_latents_tensor
m.policy.parent._encode_input_image_latents_tensor=lambda image:middle['latents'].to('cuda')
with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):a=m.infer_action(**kw)['action']
record['action_with_identical_latents']=compare(a,middle['action'])
m.policy.parent._encode_input_image_latents_tensor=original
with torch.backends.cudnn.flags(deterministic=True),torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
    a=m.infer_action(**kw)['action'];lat=m.policy.parent._encode_input_image_latents_tensor(kw['input_image'][None].to('cuda',dtype=torch.float32)).cpu()
record['deterministic_cudnn']=dict(action=compare(a,middle['action']),latents=compare(lat,middle['latents']))
del m;gc.collect();torch.cuda.empty_cache()
record['text_outputs']=[];text=TextEncoder('/nonexistent','none','cuda')
for item in torch.load(B/'local_t5_reference.pt',weights_only=False):
    c,mask=text(item['prompt']);record['text_outputs'].append(dict(prompt=item['prompt'],mask_equal=torch.equal(mask,item['mask']),**compare(c,item['context'])))
(B/'diagnosis.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
