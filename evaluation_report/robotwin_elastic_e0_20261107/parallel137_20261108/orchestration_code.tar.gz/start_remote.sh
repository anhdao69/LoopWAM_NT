#!/usr/bin/env bash
set -euo pipefail
source /media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/environment.sh
cd /media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/repo
exec python /media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/scripts/remote_queue.py
