import json,time,threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
import parallel_report as r

def test_concurrent_atomic_writes_use_distinct_tempfiles(tmp_path):
    target=tmp_path/'state.json';barrier=threading.Barrier(2);original=Path.replace
    def overlap(self,dest):
        barrier.wait(timeout=5)
        return original(self,dest)
    with patch.object(Path,'replace',overlap):
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures=[pool.submit(r.write,target,dict(writer=i,payload='x'*1000)) for i in range(2)]
            for f in futures:f.result()
    assert json.loads(target.read_text())['writer'] in (0,1)

def test_fresh_rsync_does_not_hide_stale_remote_snapshot(tmp_path):
    d=tmp_path/'dispatch';b=tmp_path/'bulk';out=tmp_path/'report'
    (d/'remote_mirror').mkdir(parents=True);b.mkdir();out.mkdir()
    (d/'sync_status.json').write_text(json.dumps(dict(ok=True,checked_unix=time.time())))
    (d/'remote_mirror/current_results.json').write_text(json.dumps(dict(updated_unix=time.time()-1000,queue=dict(stage='evaluation'),totals={})))
    with patch.object(r,'D',d),patch.object(r,'B',b),patch.object(r,'R',out):r.update()
    state=json.loads((out/'current_results.json').read_text())
    assert state['sync']['ok'] and state['runs'][1]['snapshot_stale']
    assert state['runs'][1]['snapshot_age_seconds']>900
    assert 'stale' in (out/'report.md').read_text().lower()
