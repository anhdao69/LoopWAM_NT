"""Persistent mirror of server137 evidence and combined progress."""
import fcntl,json,subprocess,time,traceback
from pathlib import Path
from parallel_report import D,B,R,read,write,update
REMOTE='/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/report/'
def main():
    lock=(D/'sync.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    (D/'remote_mirror').mkdir(exist_ok=True);dest=R/'parallel137_20261108/remote_mirror';dest.mkdir(exist_ok=True)
    while True:
        result=dict(checked_unix=time.time(),ok=False)
        try:
            p=subprocess.run(['rsync','-a','--timeout=30','-e','ssh -S /tmp/loopwam-remote-20261104/control -o BatchMode=yes -o ConnectTimeout=8',
                              'anhdh35@10.148.182.137:'+REMOTE,str(D/'remote_mirror')+'/'],capture_output=True,text=True,timeout=45)
            result.update(ok=p.returncode==0,error=p.stderr[-1200:] if p.returncode else None)
            if p.returncode==0:subprocess.run(['rsync','-a',str(D/'remote_mirror')+'/',str(dest)+'/'],check=True)
        except Exception:result.update(error=traceback.format_exc())
        write(D/'sync_status.json',result);write(R/'parallel137_20261108/sync_status.json',result);update()
        local=read(D/'coordinator_status.json');remote=read(D/'remote_mirror/queue_status.json')
        if local.get('stage')=='local_complete' and remote.get('stage')=='complete' and result['ok']:
            write(B/'queue_status.json',dict(stage='complete',mode='parallel',scored_episodes=30000,updated_unix=time.time(),all_hosts_complete=True))
            update();break
        time.sleep(60)
if __name__=='__main__':main()
