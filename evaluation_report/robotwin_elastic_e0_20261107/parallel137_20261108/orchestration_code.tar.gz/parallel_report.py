"""Combined host-aware overview; remote entries always identify sync freshness."""
import datetime,importlib.util,json,time,fcntl,tempfile,os
from pathlib import Path
D=Path(__file__).resolve().parent;B=D.parent
R=Path('/storage/anhdh35/LoopWAM_NT/evaluation_report/robotwin_elastic_e0_20261107')
# Keep the remote progress reader separate from the frozen local report module.
spec=importlib.util.spec_from_file_location('portable_progress',D/'report.py');portable=importlib.util.module_from_spec(spec);spec.loader.exec_module(portable)
def read(p):
    try:return json.loads(p.read_text())
    except (FileNotFoundError,json.JSONDecodeError):return {}
def write(p,data):
    p.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix=p.name+'.',suffix='.tmp',dir=p.parent)
    tmp=Path(name)
    try:
        with os.fdopen(fd,'w') as stream:json.dump(data,stream,indent=2)
        tmp.replace(p)
    finally:
        if tmp.exists():tmp.unlink()
def update():
    R.mkdir(parents=True,exist_ok=True)
    with (R/'parallel_report.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX);_update()
def _update():
    state=read(B/'queue_status.json');sync=read(D/'sync_status.json');remote=read(D/'remote_mirror/current_results.json')
    rows=[]
    for name,host in [('flat_k1_n2','local'),('flat_k4_n2','137'),('flat_k4_n5','local')]:
        snapshot_age=None;snapshot_stale=False
        if host=='137':
            data=remote;stage=data.get('queue',{}).get('stage','assigned; awaiting launch')
            audit=data.get('audit',{});started=data.get('updated_unix')
            offset=read(D/'settings.json').get('remote_clock_offset_seconds',0)
            snapshot_age=max(0,time.time()-started-offset) if started else None
            snapshot_stale=stage not in ('complete','complete; audited') and (snapshot_age is None or snapshot_age>180)
            if snapshot_stale:stage+='; snapshot stale'
        else:
            run=B/'runs'/name;data=portable.progress(run/'results');launch=read(run/'launch.json');stage=launch.get('status','queued');audit=read(run/'final_audit.json');started=None
        if audit.get('status')=='passed':stage='complete; audited'
        totals=data.get('totals',{});combined=totals.get('combined',dict(successes=0,episodes=0,sr_percent=None))
        rows.append(dict(schedule=name,host=host,status=stage,totals=totals,**combined,verified_cells=data.get('verified_cells',0),audit_passed=audit.get('status')=='passed',snapshot_age_seconds=snapshot_age,snapshot_stale=snapshot_stale))
    stamp=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).isoformat(timespec='seconds')
    lines=['# Elastic E0 — full RoboTwin parallel evaluation','',f'Updated {stamp}.','',
           '| Schedule | Host / workers | Status | Successes / episodes | Live SR | Verified cells / 100 |',
           '| --- | --- | --- | ---: | ---: | ---: |']
    labels={'flat_k1_n2':'[1,1] · NFE2','flat_k4_n2':'[4,4] · NFE2','flat_k4_n5':'[4]×5 · NFE5'}
    for row in rows:
        rate=f"{row['sr_percent']:.2f}%" if row['sr_percent'] is not None else '—'
        lines.append(f"| {labels[row['schedule']]} | {'Local6000 / 4' if row['host']=='local' else '137:6000 / 4'} | {row['status']} | {row['successes']}/{row['episodes']} | {rate} | {row['verified_cells']} |")
    last=sync.get('checked_unix');age=f'{time.time()-last:.0f}s' if last else 'unknown'
    remote_age=rows[1]['snapshot_age_seconds'];snapshot_label=f'{remote_age:.0f}s' if remote_age is not None else 'unknown'
    lines+=['',f"Remote sync: {'successful' if sync.get('ok') else 'pending/failed; remote rows may be stale'}; last transfer-attempt age {age}; remote progress-snapshot age {snapshot_label}. Snapshots older than180seconds are explicitly marked stale.",
            '', '**Protocol:** all50tasks, clean + randomized,100episodes/task/setting,seed42,10,000episodes per schedule;30,000total. Four video loops; action depths/NFE as listed; FP32weights/BF16compute; predict32/execute24; original normalization, camera packing, scene admission, unseen instructions and RT32/depth8 renderer. Smoke and interrupted attempts are excluded.',
            '', 'Live SR includes completed episodes in active attempts and remains provisional. Final scores require100 complete task/setting cells and a successful video/trace/runtime audit. Historical Python instruction-template randomness remains unseeded, so exact trajectory pairing is not claimed.',
            '', '**Parallel execution:** [4,4] is assigned exclusively to server137; the local server finishes[1,1], then runs[4]×5. The original evaluator/code/runtime remains frozen. Only its scheduling supervisor was replaced; per-cell results are not mixed across hosts.',
            '', '**Host validation:** server137 and local both use RTXPRO6000/driver580.178.04. Checkpoint, source, assets, checked package versions and protocol are checked before launch. Native/graph and cross-host action/T5 parity results are recorded in [remote verification](parallel137_20261108/report.md). Server189 is not used for scored evaluation.',
            '', '[Original detailed setup](setup_report.md) · [handoff receipt](parallel137_20261108/handoff.json) · [schedule ownership](parallel137_20261108/assignments.json) · [remote report](parallel137_20261108/remote_mirror/report.md) · [machine-readable progress](current_results.json)','']
    (R/'report.md').write_text('\n'.join(lines));write(R/'current_results.json',dict(updated_unix=time.time(),queue=state,sync=sync,runs=rows))

if __name__=='__main__':update()
