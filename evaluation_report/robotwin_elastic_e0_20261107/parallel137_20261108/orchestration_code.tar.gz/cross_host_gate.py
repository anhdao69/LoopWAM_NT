"""Require exact E0 and T5 outputs across local6000 and remote5000 GPUs."""
import hashlib,importlib.metadata as im,json,platform,subprocess,time,gc
from pathlib import Path
import torch
from experiments.robotwin.loopwam_policy.elastic_inference import RobotElasticInference
from experiments.robotwin.chronoloop_policy.deploy_policy import TextEncoder
B=Path(__file__).resolve().parent.parent;torch.set_num_threads(2)
local=json.loads((B/'local_environment.json').read_text());versions={}
for name in local['packages']:
    try:versions[name]=im.version(name)
    except im.PackageNotFoundError:versions[name]=None
assert versions==local['packages'],dict(local=local['packages'],remote=versions)
assert torch.version.cuda==local['torch_cuda'] and platform.python_version()==local['python']
assert hashlib.sha256((B/'local_reference.pt').read_bytes()).hexdigest()==local['reference_sha256']
record=dict(passed=False,checked_unix=time.time(),packages_identical=True,local=local,
            remote=dict(host=platform.node(),gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],text=True).strip()),model_outputs=[],text_outputs=[])
def save(): (B/'cross_host_gate.json').write_text(json.dumps(record,indent=2))
save()
model=RobotElasticInference(B/'checkpoint/epoch_01.pt',B/'repo/checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth','flat_k4_n2');del model.payload
for item in torch.load(B/'local_reference.pt',map_location='cpu',weights_only=False):
    p=B/'gate_inputs'/item['file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==item['input_sha256']
    kw=torch.load(p,map_location='cpu',weights_only=False);kw.update(seed=item['seed'],num_inference_steps=2,compile_action_infer=False)
    with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):action=model.infer_action(**kw)['action']
    equal=torch.equal(action,item['action']);difference=float((action-item['action']).abs().max())
    record['model_outputs'].append(dict(file=p.name,bit_equal=equal,max_abs_difference=difference));save()
    assert equal,f'Cross-host model output differs: {p.name}, {difference}'
del model;gc.collect();torch.cuda.empty_cache()
encoder=TextEncoder('/nonexistent','none','cuda')
for item in torch.load(B/'local_t5_reference.pt',map_location='cpu',weights_only=False):
    context,mask=encoder(item['prompt']);equal=torch.equal(context,item['context']) and torch.equal(mask,item['mask'])
    record['text_outputs'].append(dict(prompt=item['prompt'],bit_equal=equal,max_abs_difference=float((context.float()-item['context'].float()).abs().max())));save()
    assert equal,'Cross-host T5 context differs'
record.update(passed=True,finished_unix=time.time());save();print(json.dumps(record,indent=2))
