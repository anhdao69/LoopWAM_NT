import json,os,subprocess,sys,time
from pathlib import Path
import pytest
from handoff_safety import process_state,assert_adoptable,write_assignment,assert_owned

def test_adopt_live_evaluator_and_reject_pid_reuse(tmp_path):
    child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],start_new_session=True)
    try:
        identity=process_state(child.pid)
        record=dict(pid=child.pid,start_ticks=identity['start_ticks'],command=[sys.executable,'-c','import time;time.sleep(60)'])
        assert_adoptable(record)
        with pytest.raises(ValueError):assert_adoptable({**record,'start_ticks':'wrong'})
        assert child.poll() is None
    finally:child.terminate();child.wait()

def test_schedule_has_one_immutable_owner(tmp_path):
    p=tmp_path/'assignments.json'
    owners={'flat_k1_n2':'local','flat_k4_n2':'137','flat_k4_n5':'local'}
    write_assignment(p,owners)
    assert_owned(p,'flat_k4_n2','137')
    with pytest.raises(ValueError):assert_owned(p,'flat_k4_n2','local')
    with pytest.raises(ValueError):write_assignment(p,{**owners,'flat_k4_n2':'local'})
    assert json.loads(p.read_text())['owners']==owners

def test_supervisor_handoff_preserves_live_evaluator(tmp_path):
    from handoff_safety import retire_supervisor
    supervisor=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],start_new_session=True)
    evaluator=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],start_new_session=True)
    def record(p):return dict(pid=p.pid,**process_state(p.pid))
    try:
        retire_supervisor(record(supervisor),record(evaluator),tmp_path/'handoff.json')
        supervisor.wait(timeout=2)
        assert evaluator.poll() is None
        assert json.loads((tmp_path/'handoff.json').read_text())['evaluator_preserved']
    finally:
        for p in [supervisor,evaluator]:
            if p.poll() is None:p.kill();p.wait()

def test_wrong_evaluator_identity_leaves_supervisor_running(tmp_path):
    from handoff_safety import retire_supervisor
    supervisor=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],start_new_session=True)
    try:
        record=dict(pid=supervisor.pid,**process_state(supervisor.pid))
        with pytest.raises(ValueError):retire_supervisor(record,{**record,'start_ticks':'wrong'},tmp_path/'handoff.json')
        assert supervisor.poll() is None and process_state(supervisor.pid)['state']!='T'
    finally:supervisor.kill();supervisor.wait()

def test_adopted_failure_cannot_advance_schedule(tmp_path):
    from handoff_safety import require_completion
    with pytest.raises(ValueError):require_completion(tmp_path,lambda *a:None)
    (tmp_path/'manifest.json').write_text(json.dumps(dict(checkpoint_sha256='abc',tasks=['task'],episodes=100)))
    (tmp_path/'COMPLETE.json').write_text(json.dumps(dict(failed=['task'],running={},success_rates={'demo_clean':1.,'demo_randomized':1.})))
    with pytest.raises(ValueError):require_completion(tmp_path,lambda *a:None)
