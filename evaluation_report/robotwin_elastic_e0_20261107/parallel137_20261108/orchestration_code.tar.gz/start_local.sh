#!/usr/bin/env bash
set -euo pipefail
source /data14t/anhdh35/loopwam_robotwin_elastic_e0_20261107/environment.sh
exec python /data14t/anhdh35/loopwam_robotwin_elastic_e0_20261107/parallel137_20261108/coordinator.py
