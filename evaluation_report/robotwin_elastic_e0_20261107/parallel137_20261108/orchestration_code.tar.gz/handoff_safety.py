"""Host ownership and PID identity checks for an evaluator-preserving handoff."""
import json,time,os,signal
from pathlib import Path
SCHEDULES={'flat_k1_n2','flat_k4_n2','flat_k4_n5'}
def process_state(pid):
    try:
        fields=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
        args=Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
        return dict(state=fields[0],start_ticks=fields[19],command=[x.decode() for x in args if x])
    except (FileNotFoundError,ProcessLookupError):return None
def assert_adoptable(record):
    actual=process_state(record['pid'])
    if not actual or actual['state']=='Z' or actual['start_ticks']!=str(record['start_ticks']):
        raise ValueError('Evaluator PID is absent or has a different start identity')
    if actual['command'][1:]!=record['command'][1:]:raise ValueError('Evaluator command differs from the recorded job')
    return actual
def write_assignment(path,owners):
    path=Path(path)
    if set(owners)!=SCHEDULES or set(owners.values())-{'local','137'}:raise ValueError('Invalid schedule ownership')
    if path.exists():
        if json.loads(path.read_text())['owners']!=owners:raise ValueError('Existing schedule ownership differs')
        return
    data=dict(owners=owners,created_unix=time.time(),checkpoint_sha256='abc3c0075a6e1f3ce380be8d6c7b6b9d8bb697ac21cf3f2d40a93efb821b539a')
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2));tmp.replace(path)
def assert_owned(path,schedule,host):
    if json.loads(Path(path).read_text())['owners'].get(schedule)!=host:raise ValueError('Schedule is assigned to another host')

def retire_supervisor(supervisor,evaluator,receipt):
    """Retire only the old scheduling PID; its separately sessioned evaluator continues."""
    if supervisor['pid']==evaluator['pid']:raise ValueError('Supervisor and evaluator must differ')
    assert_adoptable(supervisor);assert_adoptable(evaluator)
    pid=supervisor['pid'];stopped=False;killed=False
    try:
        os.kill(pid,signal.SIGSTOP);stopped=True
        deadline=time.monotonic()+5
        while process_state(pid)['state']!='T':
            if time.monotonic()>deadline:raise RuntimeError('Supervisor did not stop')
            time.sleep(.01)
        assert_adoptable(evaluator)
        data=dict(supervisor=supervisor,evaluator=evaluator,stage='stopped',created_unix=time.time())
        Path(receipt).write_text(json.dumps(data,indent=2))
        os.kill(pid,signal.SIGKILL);killed=True
        deadline=time.monotonic()+5
        while True:
            state=process_state(pid)
            if state is None or state['state']=='Z':break
            if time.monotonic()>deadline:raise RuntimeError('Supervisor did not exit')
            time.sleep(.01)
        assert_adoptable(evaluator)
        data.update(stage='retired',evaluator_preserved=True,finished_unix=time.time())
        Path(receipt).write_text(json.dumps(data,indent=2))
    finally:
        if stopped and not killed:os.kill(pid,signal.SIGCONT)

def require_completion(directory,validate):
    directory=Path(directory)
    if not (directory/'COMPLETE.json').exists():raise ValueError('Evaluator stopped without successful completion')
    c=json.loads((directory/'COMPLETE.json').read_text());p=json.loads((directory/'manifest.json').read_text())
    if c.get('failed') or c.get('running') or set(c.get('success_rates',{}))!={'demo_clean','demo_randomized'}:
        raise ValueError('Completion contains failures or lacks final totals')
    validate(c,p['checkpoint_sha256'],p['tasks'],p['episodes'])
    return c
