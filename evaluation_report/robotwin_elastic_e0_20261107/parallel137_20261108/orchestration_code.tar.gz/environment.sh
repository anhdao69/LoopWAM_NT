export PYTHONPATH=/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/repo/src:/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/repo:/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/repo/scripts
export DIFFSYNTH_MODEL_BASE_PATH=/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin10_v0_4x4_20261104/checkpoints
export DIFFSYNTH_SKIP_DOWNLOAD=true
export PYTHONUNBUFFERED=1
export PYTHONNOUSERSITE=1
export OMP_NUM_THREADS=2
export MKL_NUM_THREADS=2
export OPENBLAS_NUM_THREADS=1
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES=0
export CUDA_HOME=/usr/local/cuda-12.8
export TORCH_CUDA_ARCH_LIST=12.0
export MAX_JOBS=8
export LOOPWAM_ROBOTWIN_SHADER=rt
export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/nvidia_icd.json
export PATH=/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin10_v0_4x4_20261104/env/bin:/usr/local/cuda-12.8/bin:$PATH

export TMPDIR=/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/tmp
export XDG_CACHE_HOME=/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/cache
export CUDA_CACHE_PATH=/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/cache/cuda
export TRITON_CACHE_DIR=/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/cache/triton
export TORCHINDUCTOR_CACHE_DIR=/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/cache/inductor
export __GL_SHADER_DISK_CACHE_PATH=/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin_elastic_e0_20261108/cache/shader

export TORCH_EXTENSIONS_DIR=/media/vmo-perception/disk_2/anhdh35/loopwam_robotwin10_v0_4x4_20261104/torch_extensions
