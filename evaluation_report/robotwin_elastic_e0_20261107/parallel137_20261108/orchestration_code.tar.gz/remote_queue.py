"""Single-owner E0 [4,4] evaluation on server137 with full final audit."""
import fcntl,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
from report import B,R,read,write,update
from verify_runtime import W,verify,freeze
from handoff_safety import assert_owned,assert_adoptable,process_state,require_completion
from queue_safety import reuse_completed
OWNS_QUEUE=False
def status(stage,**extra):
    write(B/'queue_status.json',dict(stage=stage,schedule='flat_k4_n2',host='137',queue_pid=os.getpid(),updated_unix=time.time(),**extra));update();print(stage,extra,flush=True)
def main():
    global OWNS_QUEUE
    lock=(B/'queue.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    OWNS_QUEUE=True
    signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt()))
    assert_owned(B/'assignments.json','flat_k4_n2','137')
    assert read(B/'user_authorization.json')['approved'] and read(B/'review_gate.json')['passed']
    dispatch=read(B/'dispatch_authorization.json')
    assert dispatch['local_supervisor_retired'] and dispatch['owner']=='137' and dispatch['schedule']=='flat_k4_n2'
    assert read(B/'graph_gate.json')['passed'] and read(B/'smoke_validation.json')['passed']
    assert read(B/'cross_host_gate.json')['passed'],'Server137 must match the local inference references'
    status('runtime_verification');freeze()
    from fastwam.robotwin_pipeline import validate_eval_summary
    from finalize import finalize
    run=B/'runs/flat_k4_n2';run.mkdir(parents=True,exist_ok=True)
    if reuse_completed(run,validate_eval_summary):
        status('finalizing');finalize('flat_k4_n2');status('complete',final_audit_passed=True);return
    env={**os.environ,'LOOPWAM_CUDA_GRAPH':'1','LOOPWAM_RUNTIME_MANIFEST':str(B/'runtime_manifest.json')}
    cmd=[sys.executable,str(W/'scripts/evaluate_loopwam_robotwin.py'),'--checkpoint',str(B/'checkpoint/epoch_01.pt'),
         '--output-dir',str(run/'results'),'--robotwin-root',str(W/'third_party/RoboTwin'),'--data-dir',str(B/'checkpoint'),
         '--gpus','0','--per-gpu','4','--episodes','100','--seed','42','--expected-step','47462',
         '--elastic-schedule','flat_k4_n2','--max-attempts','3','--no-progress-timeout','1800']
    old=read(B/'active_process.json');live=process_state(old.get('pid',0));proc=None
    if old.get('status')=='running' and live and live['state']!='Z':
        assert_adoptable(old)
        if old['command']!=cmd:raise ValueError('Existing remote evaluator command differs')
        active=old
    else:
        while True:
            free=int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
            if free>=60000:break
            status('waiting_for_gpu_memory',free_mib=free,required_mib=60000);time.sleep(30)
        launch=read(run/'launch.json');launch.update(status='running',command=cmd,workers=4,seed=42,planned_episodes=10000,host='137')
        launch.setdefault('started_unix',time.time());write(run/'launch.json',launch)
        with (run/'evaluation.log').open('a') as log:proc=subprocess.Popen(cmd,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        active=dict(pid=proc.pid,start_ticks=process_state(proc.pid)['start_ticks'],command=cmd,status='running',started_unix=time.time());write(B/'active_process.json',active)
    status('evaluation',evaluator_pid=active['pid'])
    try:
        while True:
            live=process_state(active['pid'])
            if live is None or live['state']=='Z' or live['start_ticks']!=active['start_ticks']:break
            update();time.sleep(10)
        if proc is not None and proc.wait()!=0:raise RuntimeError('Remote evaluator exited unsuccessfully')
        require_completion(run/'results',validate_eval_summary)
        active.update(status='finished',finished_unix=time.time());write(B/'active_process.json',active)
        launch=read(run/'launch.json');launch.update(status='complete',finished_unix=time.time());write(run/'launch.json',launch)
        status('finalizing');finalize('flat_k4_n2');status('complete',final_audit_passed=True)
    except BaseException:
        # On orderly stop terminate only this campaign's verified evaluator group.
        live=process_state(active['pid'])
        if live and live['state']!='Z' and live['start_ticks']==active['start_ticks']:
            assert_adoptable(active);os.killpg(active['pid'],signal.SIGTERM)
        raise
if __name__=='__main__':
    try:main()
    except BaseException:
        if OWNS_QUEUE:status('error',error=traceback.format_exc())
        raise
