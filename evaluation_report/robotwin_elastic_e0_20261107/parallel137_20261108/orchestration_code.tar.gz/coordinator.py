"""Adopt the current local evaluation; exclusively run the local1/1 and4x5 jobs."""
import fcntl,json,os,signal,sys,time,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;B=D.parent
# Frozen local helpers remain byte-for-byte unchanged and keep their original imports.
sys.path.insert(0,str(B/'scripts'))
import queue_pipeline as q
from finalize import finalize
from queue_safety import reuse_completed
from fastwam.robotwin_pipeline import validate_eval_summary
from handoff_safety import assert_adoptable,assert_owned,process_state,retire_supervisor,require_completion
from parallel_report import update,R
OWNS_QUEUE=False

def status(stage,**extra):
    record=dict(stage=stage,queue_pid=os.getpid(),updated_unix=time.time(),mode='parallel',**extra)
    q.write(B/'queue_status.json',record);q.write(D/'coordinator_status.json',record);update();print(record,flush=True)

def main():
    global OWNS_QUEUE
    own_lock=(D/'coordinator.lock').open('a');fcntl.flock(own_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert q.read(D/'review_gate.json')['passed'] and q.read(D/'user_authorization.json')['approved']
    (R/'parallel137_20261108').mkdir(parents=True,exist_ok=True)
    for name in ['flat_k1_n2','flat_k4_n5']:assert_owned(D/'assignments.json',name,'local')
    assert_owned(D/'assignments.json','flat_k4_n2','137')
    old=q.read(B/'queue_status.json');active=q.read(B/'active_process.json')
    supervisor=process_state(old.get('queue_pid',0))
    if supervisor and supervisor['state']!='Z':
        expected=str(B/'scripts/queue_pipeline.py')
        if len(supervisor['command'])<2 or supervisor['command'][1]!=expected:
            raise ValueError('Another local supervisor is alive; refusing takeover')
        if active['command'][active['command'].index('--elastic-schedule')+1]!='flat_k1_n2':
            raise ValueError('Original queue advanced; replan ownership before handoff')
        assert not (B/'runs/flat_k4_n2').exists(),'Local4/4 was already created'
        if not (D/'previous_queue_launch.json').exists():q.write(D/'previous_queue_launch.json',q.read(B/'queue_launch.json'))
        retire_supervisor(dict(pid=old['queue_pid'],**supervisor),active,D/'handoff.json')
    lock=(B/'queue.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    OWNS_QUEUE=True
    if not (D/'handoff.json').exists():raise ValueError('Missing handoff evidence')
    q.update=update;q.status=status
    q.write(B/'queue_launch.json',dict(pid=os.getpid(),launched_unix=time.time(),mode='parallel',command=['bash',str(D/'start_local.sh')]))
    os.environ['LOOPWAM_CUDA_GRAPH']='1';os.environ['LOOPWAM_RUNTIME_MANIFEST']=str(B/'runtime_manifest.json')
    q.write(D/'dispatch_authorization.json',dict(local_supervisor_retired=True,new_supervisor_pid=os.getpid(),
            schedule='flat_k4_n2',owner='137',created_unix=time.time()))
    (R/'parallel137_20261108/handoff.json').write_bytes((D/'handoff.json').read_bytes())
    def stop(*_):raise KeyboardInterrupt()
    signal.signal(signal.SIGTERM,stop)
    for name in ['flat_k1_n2','flat_k4_n5']:
        run=B/'runs'/name;run.mkdir(parents=True,exist_ok=True)
        assert_owned(D/'assignments.json',name,'local')
        if not reuse_completed(run,validate_eval_summary):
            active=q.read(B/'active_process.json');state=process_state(active.get('pid',0))
            if active.get('status')=='running' and state and state['state']!='Z':
                assert_adoptable(active)
                if active['command'][active['command'].index('--elastic-schedule')+1]!=name:raise ValueError('Unexpected live local schedule')
                status('evaluation',schedule=name,evaluator_pid=active['pid'],adopted=True)
                while True:
                    state=process_state(active['pid'])
                    if not state or state['state']=='Z' or state['start_ticks']!=active['start_ticks']:break
                    update();time.sleep(10)
                require_completion(run/'results',validate_eval_summary)
                active.update(status='finished',finished_unix=time.time(),adopted_exit_code_unavailable=True);q.write(B/'active_process.json',active)
                assert reuse_completed(run,validate_eval_summary)
            else:
                if name=='flat_k1_n2':raise ValueError('Original evaluation disappeared without completion')
                q.verify(q.read(B/'runtime_manifest.json')['files'])
                command=q.eval_command(name,run/'results',100)
                launch=q.read(run/'launch.json');launch.update(status='running',schedule=name,workers=4,seed=42,planned_episodes=10000,command=command)
                launch.setdefault('started_unix',time.time());q.write(run/'launch.json',launch)
                q.run_process('evaluation',command,run/'evaluation.log',schedule=name)
                require_completion(run/'results',validate_eval_summary)
                launch.update(status='complete',finished_unix=time.time());q.write(run/'launch.json',launch)
        status('finalizing',schedule=name);finalize(name)
    status('local_complete',local_schedules_complete=True,remote_schedule='flat_k4_n2; tracked separately')

if __name__=='__main__':
    try:main()
    except BaseException:
        if OWNS_QUEUE:status('error',error=traceback.format_exc())
        raise
