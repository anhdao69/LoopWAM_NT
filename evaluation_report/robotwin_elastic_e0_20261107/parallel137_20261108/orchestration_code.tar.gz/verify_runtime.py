"""Portable E0 runtime verification against the local immutable campaign."""
import concurrent.futures,hashlib,json,time
from pathlib import Path
from queue_safety import publish_runtime
B=Path(__file__).resolve().parent.parent;W=B/'repo';R=B/'report'
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def verify(files):
    def check(item):
        p,info=item
        if sha(p)!=info['sha256']:raise ValueError(f'Runtime hash mismatch: {p}')
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(check,files.items()))
def check_inputs():
    portable=json.loads((B/'portable_runtime.json').read_text());verify(portable['files'])
    source=json.loads((B/'code_manifest.json').read_text())
    verify({str(W/p):v for p,v in source.items()})
    receipt=json.loads((B/'local_download_receipt.json').read_text())
    for item in receipt['files']:
        assert sha(B/'checkpoint'/Path(item['path']).name)==item['sha256'],item['path']
    for item in json.loads((B/'local_graph_gate.json').read_text())['inputs']:
        assert sha(B/'gate_inputs'/Path(item['path']).name)==item['sha256']
    record=dict(passed=True,verified_unix=time.time(),portable_runtime_files=len(portable['files']),
                identical_code_files=len(source),checkpoint_sha256=sha(B/'checkpoint/epoch_01.pt'),
                path_relocations=portable['path_relocations'])
    (B/'source_check.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='path_relocations'}),flush=True)
    return portable,source
def freeze():
    portable,source=check_inputs();files={str(W/p):v for p,v in source.items()};files.update(portable['files'])
    paths=list((B/'scripts').glob('*.py'))+list(B.glob('*.sh'))+list((B/'checkpoint').glob('*'))
    paths += [B/x for x in ['portable_runtime.json','code_manifest.json','local_environment.json','local_reference.pt','local_t5_reference.pt','cross_host_gate.json','graph_gate.json','review_gate.json','settings.json','assignments.json','user_authorization.json','dispatch_authorization.json','smoke_validation.json','local_download_receipt.json']]
    for p in paths:files[str(p)]=dict(sha256=sha(p),bytes=p.stat().st_size)
    publish_runtime(B/'runtime_manifest.json',dict(created_unix=time.time(),files=files,host='10.148.182.137',
            protocol='same as local E0; paths, GPU and worker count recorded separately',schedule='flat_k4_n2',workers=4))
if __name__=='__main__':
    import sys
    freeze() if '--freeze' in sys.argv else check_inputs()
