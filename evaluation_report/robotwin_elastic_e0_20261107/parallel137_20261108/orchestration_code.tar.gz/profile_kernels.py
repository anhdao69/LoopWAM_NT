from pathlib import Path
import os,json,torch
from experiments.robotwin.loopwam_policy.elastic_inference import RobotElasticInference
b=Path(os.environ['E0_BULK']);torch.set_num_threads(2)
m=RobotElasticInference(b/'checkpoint/epoch_01.pt',b/'repo/checkpoints/Wan-AI/Wan2.1-T2V-1.3B/Wan2.1_VAE.pth','flat_k4_n2')
kw=torch.load(sorted((b/'gate_inputs').glob('*.pt'))[0],weights_only=False);kw.update(seed=42,num_inference_steps=2,compile_action_infer=False)
with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
 m.infer_action(**kw)
 with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as p:m.infer_action(**kw)
keys=sorted(set(x.key for x in p.key_averages() if any(k in x.key.lower() for k in ['attention','gemm','bmm','cutlass','fmha'])))
print(json.dumps(keys,indent=2))
